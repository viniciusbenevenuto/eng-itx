"""Tabelas dos inventários (criadas por db.init_db).

Cada tabela guarda a planilha como ela é: mesmas linhas, mesmos valores (tudo
como texto, sem conferência), mais a linha do Excel de onde veio cada registro
(linha_planilha). Nada é obrigatório nem único: linhas repetidas, células
vazias e valores fora do padrão entram como estão.
"""
from __future__ import annotations

import logging
import sqlite3

logger = logging.getLogger(__name__)

VERSAO = 3          # 3: inv_rotngin_alocados (labels alocados pelo sistema)

ESQUEMA_SQL = """
CREATE TABLE IF NOT EXISTS inv_meta (
    chave  TEXT PRIMARY KEY,
    valor  TEXT
);

-- Operadoras com CSP
CREATE TABLE IF NOT EXISTS inv_operadoras_csp (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    linha_planilha  INTEGER,
    rn1             TEXT,
    nome_fantasia   TEXT,
    csp             TEXT
);

-- Áreas locais da Anatel
CREATE TABLE IF NOT EXISTS inv_al_anatel (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    linha_planilha  INTEGER,
    sigla_al        TEXT,
    area_local      TEXT,
    localidade      TEXT,
    sigla_cnl       TEXT,
    cod_cnl         TEXT,
    cn              TEXT
);

-- Repositório de RN1
CREATE TABLE IF NOT EXISTS inv_rn1 (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    linha_planilha    INTEGER,
    data_modificacao  TEXT,      -- DATA MODIFICAÇÃO
    idp               TEXT,
    nome              TEXT,      -- NOM
    tipo              TEXT,      -- TTE
    rn1_yy            TEXT,      -- RN1 (YY) (CSP SAS)
    acao              TEXT,      -- AÇÃO (TIPO DE MODIFICAÇÃO)
    csp_operadora     TEXT,      -- CSP (OPERADORA)
    ecr               TEXT,
    rn1               TEXT,
    resp              TEXT,
    existe_anexo5     TEXT       -- existe anexo 5?
);

-- ROTNGIN em uso na fixa (rotngin_fixa_asitx_vivo1_reg3)
CREATE TABLE IF NOT EXISTS inv_rotngin (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    linha_planilha  INTEGER,
    operadora       TEXT,
    cn              TEXT,
    localidade      TEXT,
    tipo_rota       TEXT,        -- TIPO DE ROTA
    rotngin         TEXT,
    rn1             TEXT
);

-- Labels de SAS resumido em uso
CREATE TABLE IF NOT EXISTS inv_sas_resumido (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    linha_planilha  INTEGER,
    cn              TEXT,
    operadora       TEXT,
    label           TEXT,        -- LABEL (SAS)
    rota            TEXT,
    rn1             TEXT
);

-- Planilha livres_sas_resumido_rotngin como ela é: uma coluna por CN, a de
-- ROTNGIN e o texto das colunas sem cabeçalho (anotações). As faixas livres
-- são lidas daqui (inventarios/faixas.py).
CREATE TABLE IF NOT EXISTS inv_livres (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    linha_planilha  INTEGER,
    cn_11 TEXT, cn_12 TEXT, cn_13 TEXT, cn_14 TEXT, cn_15 TEXT,
    cn_16 TEXT, cn_17 TEXT, cn_18 TEXT, cn_19 TEXT,
    rotngin         TEXT,        -- ROTNGIN cn 11 ao 19
    anotacoes       TEXT         -- colunas sem cabeçalho (ex.: "spo")
);

-- Labels ROTNGIN alocados pelo sistema para os PTIs (inventarios/alocacao.py).
-- Ficam fora de inv_rotngin, que é trocada inteira a cada carga da planilha;
-- o próximo código segue o maior das duas tabelas. As versões de um PTI
-- compartilham os labels (pti_raiz); form_id é a versão que alocou.
CREATE TABLE IF NOT EXISTS inv_rotngin_alocados (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    rotngin         TEXT NOT NULL UNIQUE,
    pti_raiz        INTEGER NOT NULL,
    form_id         INTEGER NOT NULL,
    operadora       TEXT,
    cn              TEXT NOT NULL,
    localidade      TEXT NOT NULL,
    tipo_rota       TEXT NOT NULL,   -- tipo de tráfego escolhido no formulário
    rn1             TEXT,
    alocado_em      TEXT NOT NULL,
    alocado_por     TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_inv_rotngin_alocados_uso
    ON inv_rotngin_alocados (pti_raiz, cn, localidade, tipo_rota);

-- Cada tentativa de carga: arquivo, hash (o mesmo arquivo não é lido de novo),
-- situação, linhas, quando e quem
CREATE TABLE IF NOT EXISTS inv_cargas (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    base          TEXT NOT NULL,
    arquivo       TEXT,
    hash          TEXT,
    situacao      TEXT NOT NULL DEFAULT 'ok',
    linhas        INTEGER NOT NULL DEFAULT 0,
    mensagem      TEXT,
    carregado_em  TEXT NOT NULL,
    carregado_por TEXT
);

CREATE INDEX IF NOT EXISTS ix_inv_operadoras_csp_rn1 ON inv_operadoras_csp (rn1);
CREATE INDEX IF NOT EXISTS ix_inv_al_anatel_cn ON inv_al_anatel (cn);
CREATE INDEX IF NOT EXISTS ix_inv_al_anatel_cnl ON inv_al_anatel (cod_cnl);
CREATE INDEX IF NOT EXISTS ix_inv_rn1_rn1 ON inv_rn1 (rn1);
CREATE INDEX IF NOT EXISTS ix_inv_rn1_idp ON inv_rn1 (idp);
CREATE INDEX IF NOT EXISTS ix_inv_rotngin_rn1_cn ON inv_rotngin (rn1, cn);
CREATE INDEX IF NOT EXISTS ix_inv_rotngin_codigo ON inv_rotngin (rotngin);
CREATE INDEX IF NOT EXISTS ix_inv_sas_cn_rn1 ON inv_sas_resumido (cn, rn1);
CREATE INDEX IF NOT EXISTS ix_inv_cargas_base ON inv_cargas (base, carregado_em);
"""

# Versão 1 (com campos obrigatórios e chaves únicas): recriadas na versão 2
TABELAS_V1: tuple[str, ...] = ("inv_operadoras_csp", "inv_al_anatel", "inv_rn1", "inv_rotngin",
                               "inv_sas_resumido", "inv_faixas_codigos")

# Primeiro rascunho, criado direto no db.py (vazias): removidas
TABELAS_ANTIGAS: tuple[str, ...] = (
    "operadoras_com_csp", "al_anatel", "rn1", "rotngin_fixa_asitx_vivo1_reg3",
    "sas_resumido_em_uso_zz", "livres_sas_resumido_rotngin",
)


def _tabelas(db) -> set[str]:
    return {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}


def criar_esquema(db: sqlite3.Connection) -> None:
    db.execute("CREATE TABLE IF NOT EXISTS inv_meta (chave TEXT PRIMARY KEY, valor TEXT)")
    row = db.execute("SELECT valor FROM inv_meta WHERE chave = 'versao'").fetchone()
    versao = int(row[0]) if row else 0
    if versao < 2:
        _migrar_para_v2(db)
    db.executescript(ESQUEMA_SQL)
    existentes = {r[1] for r in db.execute("PRAGMA table_info(inv_cargas)")}
    for coluna, definicao in (("hash", "TEXT"), ("situacao", "TEXT NOT NULL DEFAULT 'ok'"), ("mensagem", "TEXT")):
        if coluna not in existentes:
            db.execute(f"ALTER TABLE inv_cargas ADD COLUMN {coluna} {definicao}")
    db.execute("INSERT INTO inv_meta (chave, valor) VALUES ('versao', ?) "
               "ON CONFLICT(chave) DO UPDATE SET valor = excluded.valor", (str(VERSAO),))
    _remover_tabelas_antigas(db)


def _migrar_para_v2(db: sqlite3.Connection) -> None:
    """Versão 1 → 2: tira obrigatórios e chaves únicas, sem perder o que já foi
    carregado; as planilhas da pasta são relidas para ficarem exatamente como no Excel."""
    existentes = _tabelas(db)
    guardado: dict[str, tuple[list[str], list[tuple]]] = {}
    for tabela in TABELAS_V1:
        if tabela in existentes:
            colunas = [r[1] for r in db.execute(f"PRAGMA table_info({tabela})") if r[1] != "id"]
            guardado[tabela] = (colunas, db.execute(f"SELECT {','.join(colunas)} FROM {tabela}").fetchall())
            db.execute(f"DROP TABLE {tabela}")
    db.executescript(ESQUEMA_SQL)
    for tabela, (colunas, linhas) in guardado.items():
        if tabela == "inv_faixas_codigos" or not linhas:
            continue  # a versão 2 guarda a planilha de livres como ela é (inv_livres)
        novas = {r[1] for r in db.execute(f"PRAGMA table_info({tabela})")}
        comuns = [c for c in colunas if c in novas]
        idx = [colunas.index(c) for c in comuns]
        db.executemany(f"INSERT INTO {tabela} ({','.join(comuns)}) VALUES ({','.join('?' * len(comuns))})",
                       [[linha[i] for i in idx] for linha in linhas])
    if "inv_cargas" in existentes:
        db.execute("UPDATE inv_cargas SET hash = NULL")   # força reler as planilhas da pasta
    if guardado:
        logger.info("Inventários: tabelas atualizadas para guardar as planilhas como estão.")


def _remover_tabelas_antigas(db: sqlite3.Connection) -> None:
    existentes = _tabelas(db)
    for tabela in TABELAS_ANTIGAS:
        if tabela not in existentes:
            continue
        if db.execute(f"SELECT COUNT(*) FROM {tabela}").fetchone()[0]:
            logger.warning("Inventários: tabela antiga %s mantida (tem dados).", tabela)
            continue
        db.execute(f"DROP TABLE {tabela}")
