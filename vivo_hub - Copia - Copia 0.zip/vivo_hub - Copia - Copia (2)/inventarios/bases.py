"""Definição de cada inventário: arquivo, tabela e de que coluna do Excel vem cada campo.

Os nomes de cabeçalho são os das planilhas das equipes. Os valores entram como
estão na planilha (planilha.exato), sem conferência. Para incluir uma coluna
nova, acrescente uma Coluna aqui e o campo em esquema.py.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Coluna:
    campo: str        # coluna na tabela inv_*
    cabecalho: str    # nome na planilha


@dataclass(frozen=True)
class Base:
    chave: str
    nome: str
    arquivo: str      # nome do arquivo em data/inventarios/ (sem extensão)
    tabela: str
    colunas: tuple[Coluna, ...] = field(default_factory=tuple)


BASES: dict[str, Base] = {b.chave: b for b in (
    Base("operadoras_csp", "Operadoras com CSP", "operadoras_com_csp", "inv_operadoras_csp", (
        Coluna("rn1", "RN1"),
        Coluna("nome_fantasia", "Nome Fantasia"),
        Coluna("csp", "CSP"),
    )),
    Base("al_anatel", "Áreas locais Anatel", "al_anatel", "inv_al_anatel", (
        Coluna("sigla_al", "SIGLA_AL"),
        Coluna("area_local", "AREA_LOCAL"),
        Coluna("localidade", "LOCALIDADE"),
        Coluna("sigla_cnl", "SIGLA_CNL"),
        Coluna("cod_cnl", "COD_CNL"),
        Coluna("cn", "CN"),
    )),
    Base("rn1", "Repositório de RN1", "rn1", "inv_rn1", (
        Coluna("data_modificacao", "DATA MODIFICAÇÃO"),
        Coluna("idp", "IDP"),
        Coluna("nome", "NOM"),
        Coluna("tipo", "TTE"),
        Coluna("rn1_yy", "RN1 (YY) (CSP SAS)"),
        Coluna("acao", "AÇÃO (TIPO DE MODIFICAÇÃO)"),
        Coluna("csp_operadora", "CSP (OPERADORA)"),
        Coluna("ecr", "ECR"),
        Coluna("rn1", "RN1"),
        Coluna("resp", "RESP"),
        Coluna("existe_anexo5", "existe anexo 5?"),
    )),
    Base("rotngin", "ROTNGIN em uso (fixa ASITX VIVO1 reg. 3)", "rotngin_fixa_asitx_vivo1_reg3", "inv_rotngin", (
        Coluna("operadora", "OPERADORA"),
        Coluna("cn", "CN"),
        Coluna("localidade", "LOCALIDADE"),
        Coluna("tipo_rota", "TIPO DE ROTA"),
        Coluna("rotngin", "ROTNGIN"),
        Coluna("rn1", "rn1"),
    )),
    Base("sas_resumido", "SAS resumido em uso", "sas_resumido_em_uso", "inv_sas_resumido", (
        Coluna("cn", "CN"),
        Coluna("operadora", "OPERADORA"),
        Coluna("label", "LABEL (SAS)"),
        Coluna("rota", "ROTA"),
        Coluna("rn1", "rn1"),
    )),
    # Uma coluna por CN (cabeçalho 11 a 19) e a de ROTNGIN: leitura própria (carga.py)
    Base("livres", "Faixas livres de SAS resumido e ROTNGIN", "livres_sas_resumido_rotngin", "inv_livres"),
)}

# Ordem de carga e de exibição
ORDEM: tuple[str, ...] = ("operadoras_csp", "al_anatel", "rn1", "rotngin", "sas_resumido", "livres")

# Colunas da tabela inv_livres, na ordem da planilha
CNS_LIVRES: tuple[str, ...] = ("11", "12", "13", "14", "15", "16", "17", "18", "19")
