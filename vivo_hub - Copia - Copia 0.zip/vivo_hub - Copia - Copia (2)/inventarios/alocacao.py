"""Labels ROTNGIN dos PTIs.

Cada tipo de tráfego dos quatro primeiros grupos (traffic_types.TIPOS_COM_LABEL)
recebe um label por localidade da operadora (CN + Localidade de Dados
Operadora). O label segue a sequência da coluna ROTNGIN: o maior código já
usado (planilha rotngin_fixa_asitx_vivo1_reg3 + labels alocados pelo sistema)
mais um. Ex.: o último é C8791572, o próximo é C8791573.

Alocar é um passo da Engenharia (botão no formulário de validação), não um
efeito de gerar documentos. As versões de um PTI compartilham os labels; uma
versão só libera o que ela mesma alocou. Nada aqui faz commit.
"""
from __future__ import annotations

import json
import re
import sqlite3
import unicodedata

from fluxo.tempo import agora, gravar
from traffic_types import TIPO_LD15, TIPOS_COM_LABEL

_CODIGO = re.compile(r"^([A-Z])(\d{7})$")


class AlocacaoErro(Exception):
    """Não foi possível alocar (mensagem pronta para o usuário)."""


def pti_raiz(form) -> int:
    return form["parent_id"] or form["id"]


def _json_lista(texto) -> list:
    try:
        v = json.loads(texto or "[]")
    except (json.JSONDecodeError, TypeError):
        return []
    return v if isinstance(v, list) else []


def tipos_com_label(form) -> list[str]:
    escolhidos = set(_json_lista(form["escopo_flags_json"]))
    return [t for t in TIPOS_COM_LABEL if t in escolhidos]


def localidades(form) -> tuple[list[dict], list[str]]:
    """Localidades distintas (CN + Localidade) de Dados Operadora, na ordem do formulário."""
    vistas: dict[tuple[str, str], dict] = {}
    avisos = []
    for i, linha in enumerate(_json_lista(form["dados_operadora_json"]), start=1):
        if not isinstance(linha, dict):
            continue
        cn = str(linha.get("cn") or "").strip()
        loc = str(linha.get("localidade") or "").strip().upper()
        if not cn or not loc:
            avisos.append(f"Dados Operadora, linha {i}: sem CN ou sem localidade; não recebe label.")
            continue
        vistas.setdefault((cn, loc), {"cn": cn, "localidade": loc,
                                      "cidade": str(linha.get("cidade") or "").strip()})
    return list(vistas.values()), avisos


def ultimo_codigo(db: sqlite3.Connection) -> str | None:
    """Maior ROTNGIN em uso (planilha + sistema), no formato letra + 7 dígitos."""
    melhor = None
    for (valor,) in db.execute("SELECT rotngin FROM inv_rotngin UNION ALL SELECT rotngin FROM inv_rotngin_alocados"):
        m = _CODIGO.match(str(valor or "").strip().upper())
        if m and (melhor is None or int(m.group(2)) > melhor[1]):
            melhor = (m.group(1), int(m.group(2)))
    return f"{melhor[0]}{melhor[1]:07d}" if melhor else None


def proximo_codigo(db: sqlite3.Connection) -> str:
    ultimo = ultimo_codigo(db)
    if not ultimo:
        raise AlocacaoErro("O inventário de ROTNGIN está vazio. Coloque a planilha "
                           "rotngin_fixa_asitx_vivo1_reg3 na pasta de inventários antes de alocar.")
    numero = int(ultimo[1:]) + 1
    if numero > 9_999_999:
        raise AlocacaoErro("A sequência de ROTNGIN chegou ao fim (" + ultimo + ").")
    return f"{ultimo[0]}{numero:07d}"


def situacao(db: sqlite3.Connection, form) -> dict:
    """O que o formulário pede e o que já está alocado (para a tela e para alocar)."""
    tipos = tipos_com_label(form)
    locs, avisos = localidades(form)
    existentes = {(r["cn"], r["localidade"], r["tipo_rota"]): r for r in db.execute(
        "SELECT * FROM inv_rotngin_alocados WHERE pti_raiz = ? ORDER BY id", (pti_raiz(form),))}
    itens = []
    for loc in locs:
        for tipo in tipos:
            r = existentes.get((loc["cn"], loc["localidade"], tipo))
            itens.append({**loc, "tipo": tipo, "rotngin": r["rotngin"] if r else None})
    pedidos = {(i["cn"], i["localidade"], i["tipo"]) for i in itens}
    a_liberar = [dict(r) for k, r in existentes.items() if k not in pedidos and r["form_id"] == form["id"]]
    if tipos and not locs:
        avisos.append("Preencha CN e Localidade em Dados Operadora para alocar os labels.")
    return {"itens": itens, "a_liberar": a_liberar, "avisos": avisos,
            "pendentes": sum(1 for i in itens if not i["rotngin"]), "tem_tipos": bool(tipos)}


def alocar(db: sqlite3.Connection, form, autor: str | None) -> dict:
    """Aloca o que falta e libera o que esta versão alocou e saiu do formulário."""
    s = situacao(db, form)
    liberados = []
    for r in s["a_liberar"]:
        db.execute("DELETE FROM inv_rotngin_alocados WHERE id = ?", (r["id"],))
        liberados.append(r)
    alocados = []
    quando = gravar(agora())
    for item in s["itens"]:
        if item["rotngin"]:
            continue
        codigo = proximo_codigo(db)
        db.execute(
            "INSERT INTO inv_rotngin_alocados (rotngin, pti_raiz, form_id, operadora, cn, localidade, "
            "tipo_rota, rn1, alocado_em, alocado_por) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (codigo, pti_raiz(form), form["id"], (form["nome_operadora"] or "").strip(), item["cn"],
             item["localidade"], item["tipo"], (form["rn1"] or "").strip(), quando, autor))
        item["rotngin"] = codigo
        alocados.append(item)
    return {"alocados": alocados, "liberados": liberados, "itens": s["itens"]}


def liberar_da_versao(db: sqlite3.Connection, form_id: int) -> list[dict]:
    """Libera os labels que esta versão alocou (ex.: processo cancelado)."""
    linhas = [dict(r) for r in db.execute(
        "SELECT * FROM inv_rotngin_alocados WHERE form_id = ? ORDER BY id", (form_id,))]
    db.execute("DELETE FROM inv_rotngin_alocados WHERE form_id = ?", (form_id,))
    return linhas


def descrever(itens) -> str:
    """Texto curto para a linha do tempo: 'C8791573 · LD15 + CNG · SJC (CN 12)'."""
    return "; ".join(f"{i['rotngin']} · {i.get('tipo') or i.get('tipo_rota')} · {i['localidade']} (CN {i['cn']})"
                     for i in itens)


# ---------------------------------------------------------------------------- consultas para o ECR
def _normalizar(texto) -> str:
    t = unicodedata.normalize("NFKD", str(texto or "")).encode("ascii", "ignore").decode()
    return " ".join(t.upper().split())


def cnl(db: sqlite3.Connection, cn: str, localidade: str, cidade: str = "") -> str:
    """Código CNL (inventário al_anatel) da localidade: pela sigla CNL ou pelo nome."""
    loc, cid = _normalizar(localidade), _normalizar(cidade)
    candidatos = [r for r in db.execute(
        "SELECT sigla_cnl, localidade, cod_cnl FROM inv_al_anatel WHERE TRIM(cn) = ? ORDER BY linha_planilha",
        (str(cn).strip(),)) if (r["cod_cnl"] or "").strip()]
    for teste in (lambda r: loc and _normalizar(r["sigla_cnl"]) == loc,
                  lambda r: loc and _normalizar(r["localidade"]) == loc,
                  lambda r: cid and _normalizar(r["localidade"]) == cid):
        achado = next((r for r in candidatos if teste(r)), None)
        if achado:
            return achado["cod_cnl"].strip()
    return ""


def idp(db: sqlite3.Connection, rn1: str) -> str:
    """IDP da operadora no repositório de RN1 (linha mais recente com IDP)."""
    r = db.execute(
        "SELECT idp FROM inv_rn1 WHERE TRIM(rn1) = ? AND TRIM(COALESCE(idp, '')) <> '' "
        "ORDER BY linha_planilha DESC LIMIT 1", (str(rn1 or "").strip(),)).fetchone()
    return r["idp"].strip() if r else ""


def labels_ld15(db: sqlite3.Connection, form) -> dict[tuple[str, str], str]:
    return {(r["cn"], r["localidade"]): r["rotngin"] for r in db.execute(
        "SELECT cn, localidade, rotngin FROM inv_rotngin_alocados WHERE pti_raiz = ? AND tipo_rota = ?",
        (pti_raiz(form), TIPO_LD15))}
