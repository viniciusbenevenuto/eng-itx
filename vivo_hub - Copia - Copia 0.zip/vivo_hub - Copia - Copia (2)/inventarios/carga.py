"""Carga dos inventários a partir das planilhas em data/inventarios/.

As planilhas entram como estão: mesmas linhas e mesmos valores, sem
conferência. Linhas repetidas, células vazias e valores fora do padrão são
gravados do jeito que vieram; só as linhas totalmente vazias ficam de fora.
A carga só não acontece se não der para abrir o arquivo ou se faltar uma
coluna do cabeçalho (sem ela não há como saber o que é cada coluna).

O mesmo arquivo (mesmo hash) não é lido duas vezes; trocar o arquivo na pasta
basta para atualizar. Mensagens e relatórios nunca mostram valores das
planilhas, só aba, linha, coluna e contagens.
"""
from __future__ import annotations

import hashlib
import logging
import os
import sqlite3
import time
from pathlib import Path

from fluxo.tempo import agora, gravar
from inventarios import faixas
from inventarios.bases import BASES, CNS_LIVRES, ORDEM, Base
from inventarios.planilha import (
    achar_cabecalho, cabecalhos_encontrados, exato, ler_abas, normalizar_cabecalho, texto,
)

logger = logging.getLogger(__name__)

EXTENSOES = (".xlsx", ".xlsm")
ESTAVEL_S = 10          # arquivo modificado há menos tempo pode estar sendo copiado
CAMPOS_LIVRES = ["linha_planilha"] + [f"cn_{cn}" for cn in CNS_LIVRES] + ["rotngin", "anotacoes"]


def arquivo_da_base(pasta, base: Base) -> Path | None:
    for ext in EXTENSOES:
        p = Path(pasta) / f"{base.arquivo}{ext}"
        if p.is_file():
            return p
    return None


def hash_arquivo(caminho) -> str:
    h = hashlib.sha256()
    with open(caminho, "rb") as f:
        for bloco in iter(lambda: f.read(1 << 20), b""):
            h.update(bloco)
    return h.hexdigest()


def _vazio(v) -> bool:
    return v is None or (isinstance(v, str) and not v.strip())


def _analisar_livres(abas) -> dict:
    for nome, linhas in abas:
        cab = next((i for i, l in enumerate(linhas[:30]) if l and normalizar_cabecalho(l[0]) == "CN"), None)
        if cab is None:
            continue
        destino: dict[int, str] = {}
        for j, celula in enumerate(linhas[cab]):
            t = texto(celula)
            if t in CNS_LIVRES:
                destino[j] = f"cn_{t}"
            elif "ROTNGIN" in normalizar_cabecalho(t):
                destino[j] = "rotngin"
        if not destino:
            continue
        registros = []
        for i in range(cab + 1, len(linhas)):
            linha = linhas[i]
            if all(_vazio(v) for v in linha):
                continue
            reg = {c: None for c in CAMPOS_LIVRES}
            reg["linha_planilha"] = i + 1
            anotacoes = []
            for j, v in enumerate(linha):
                if _vazio(v):
                    continue
                if j in destino:
                    reg[destino[j]] = exato(v)
                else:
                    anotacoes.append(exato(v))
            reg["anotacoes"] = " | ".join(anotacoes) or None
            registros.append(reg)
        # Faixas mal formadas não impedem a carga: só deixam de gerar códigos livres
        _, problemas, _ = faixas.ler(linhas)
        colunas = [("CN " + destino[j][3:]) if destino[j].startswith("cn_") else "ROTNGIN" for j in sorted(destino)]
        return {"registros": registros, "erros": [], "avisos": problemas,
                "estrutura": {"aba": nome, "linha_cabecalho": cab + 1, "colunas": colunas}}
    return {"registros": [], "avisos": [], "estrutura": {},
            "erros": ["não achei a linha de cabeçalho (primeira célula \"cn\" seguida dos CNs 11 a 19)"]}


def analisar(chave: str, caminho) -> dict:
    """Lê a planilha sem gravar nada.

    {"registros": [...], "erros": [...], "avisos": [...], "estrutura": {...}}
    Erros só de estrutura (arquivo ou cabeçalho); valores não são conferidos.
    """
    base = BASES[chave]
    try:
        abas = ler_abas(caminho)
    except Exception as exc:  # arquivo corrompido, protegido ou ainda sendo copiado
        return {"registros": [], "erros": [f"não foi possível abrir o arquivo ({exc.__class__.__name__})"],
                "avisos": [], "estrutura": {}}
    if chave == "livres":
        return _analisar_livres(abas)

    obrigatorios = [c.cabecalho for c in base.colunas]
    for nome, linhas in abas:
        achado = achar_cabecalho(linhas, obrigatorios)
        if achado:
            break
    else:
        encontrados = cabecalhos_encontrados(abas[0][1]) if abas else []
        presentes = {normalizar_cabecalho(e) for e in encontrados}
        faltando = sorted(c.cabecalho for c in base.colunas if normalizar_cabecalho(c.cabecalho) not in presentes)
        return {"registros": [], "avisos": [], "estrutura": {"abas": [a for a, _ in abas]},
                "erros": [f"não achei as colunas: {', '.join(faltando) or ', '.join(obrigatorios)}. "
                          f"Colunas encontradas: {', '.join(encontrados) or 'nenhuma'}"]}

    indice_cab, mapa = achado
    posicao = {c.campo: mapa[normalizar_cabecalho(c.cabecalho)] for c in base.colunas}
    registros, vazias = [], 0
    for i in range(indice_cab + 1, len(linhas)):
        linha = linhas[i]
        brutos = {campo: (linha[j] if j < len(linha) else None) for campo, j in posicao.items()}
        if all(_vazio(v) for v in brutos.values()):
            vazias += 1
            continue
        registros.append({"linha_planilha": i + 1, **{campo: exato(v) for campo, v in brutos.items()}})
    return {"registros": registros, "erros": [], "avisos": [],
            "estrutura": {"aba": nome, "linha_cabecalho": indice_cab + 1,
                          "colunas": [c.cabecalho for c in base.colunas], "linhas_em_branco": vazias}}


def _registrar(db, chave, caminho, hash_, situacao, linhas, mensagens, autor) -> None:
    db.execute(
        "INSERT INTO inv_cargas (base, arquivo, hash, situacao, linhas, mensagem, carregado_em, carregado_por) "
        "VALUES (?,?,?,?,?,?,?,?)",
        (chave, Path(caminho).name, hash_, situacao, linhas, "\n".join(mensagens) or None, gravar(agora()), autor))


def carregar(db: sqlite3.Connection, chave: str, caminho, autor: str = "sistema", hash_: str | None = None) -> dict:
    """Troca a base inteira pelo conteúdo da planilha (uma transação). Faz commit."""
    base = BASES[chave]
    hash_ = hash_ or hash_arquivo(caminho)
    r = analisar(chave, caminho)
    if not db.in_transaction:
        db.execute("BEGIN IMMEDIATE")
    try:
        if r["erros"]:
            _registrar(db, chave, caminho, hash_, "erro", 0, r["erros"], autor)
        else:
            campos = CAMPOS_LIVRES if chave == "livres" else ["linha_planilha"] + [c.campo for c in base.colunas]
            db.execute(f"DELETE FROM {base.tabela}")
            db.executemany(
                f"INSERT INTO {base.tabela} ({','.join(campos)}) VALUES ({','.join('?' * len(campos))})",
                [[reg[c] for c in campos] for reg in r["registros"]])
            _registrar(db, chave, caminho, hash_, "ok", len(r["registros"]), [], autor)
        db.commit()
    except Exception:
        db.rollback()
        raise
    r["ok"] = not r["erros"]
    r["linhas"] = len(r["registros"]) if r["ok"] else 0
    r["base"], r["arquivo"] = chave, Path(caminho).name
    if r["ok"]:
        logger.info("Inventário %s (%s): %d linha(s) carregada(s)", base.nome, Path(caminho).name, r["linhas"])
    else:
        logger.warning("Inventário %s (%s): não carregado — %s", base.nome, Path(caminho).name, r["erros"][0])
    return r


def ultima_carga(db: sqlite3.Connection, chave: str):
    return db.execute("SELECT * FROM inv_cargas WHERE base = ? ORDER BY id DESC LIMIT 1", (chave,)).fetchone()


def ultima_carga_ok(db: sqlite3.Connection, chave: str):
    return db.execute("SELECT * FROM inv_cargas WHERE base = ? AND situacao = 'ok' ORDER BY id DESC LIMIT 1",
                      (chave,)).fetchone()


def carregar_alterados(db: sqlite3.Connection, pasta, autor: str = "sistema") -> list[dict]:
    """Carrega os arquivos novos ou trocados na pasta (o mesmo arquivo não é relido)."""
    resultados = []
    for chave in ORDEM:
        caminho = arquivo_da_base(pasta, BASES[chave])
        if not caminho:
            continue
        if time.time() - os.path.getmtime(caminho) < ESTAVEL_S:
            continue  # ainda pode estar sendo copiado; fica para a próxima verificação
        hash_ = hash_arquivo(caminho)
        anterior = ultima_carga(db, chave)
        if anterior and anterior["hash"] == hash_:
            continue
        resultados.append(carregar(db, chave, caminho, autor, hash_))
    return resultados


def relatorio(db: sqlite3.Connection, pasta) -> list[dict]:
    """Situação de cada base para o comando de conferência (sem valores)."""
    saida = []
    for chave in ORDEM:
        base = BASES[chave]
        caminho = arquivo_da_base(pasta, base)
        item = {"base": chave, "nome": base.nome, "arquivo_esperado": f"{base.arquivo}.xlsx",
                "presente": bool(caminho), "ultima": ultima_carga(db, chave), "ultima_ok": ultima_carga_ok(db, chave)}
        if caminho:
            r = analisar(chave, caminho)
            item.update(estrutura=r["estrutura"], erros=r["erros"], avisos=r["avisos"], linhas=len(r["registros"]))
        saida.append(item)
    return saida
