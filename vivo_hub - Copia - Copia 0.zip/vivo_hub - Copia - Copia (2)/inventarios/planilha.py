"""Leitura das planilhas dos inventários: cabeçalho, colunas e valores.

Os cabeçalhos são comparados sem acento, sem diferença de maiúsculas e com os
espaços normalizados ("RN1 (YY)    (CSP SAS)" = "rn1 (yy) (csp sas)"). Coluna
repetida (ex.: SIGLA_CNL de apoio no fim da planilha) usa a primeira.

Nenhuma mensagem daqui mostra valores das células, só linha e coluna: os
inventários têm dados sensíveis e os erros podem ser compartilhados.
"""
from __future__ import annotations

import re
import unicodedata
from datetime import date, datetime

LINHAS_PROCURA_CABECALHO = 30


def normalizar_cabecalho(texto) -> str:
    t = unicodedata.normalize("NFKD", str(texto or "")).encode("ascii", "ignore").decode("ascii")
    return re.sub(r"\s+", " ", t).strip().upper()


def texto(valor) -> str:
    """Célula → texto limpo (número inteiro sem ".0"; datas em aaaa-mm-dd)."""
    if valor is None:
        return ""
    if isinstance(valor, bool):
        return str(valor)
    if isinstance(valor, float) and valor.is_integer():
        return str(int(valor))
    if isinstance(valor, (datetime, date)):
        return valor.strftime("%Y-%m-%d")
    return str(valor).strip()


def exato(valor) -> str | None:
    """Célula → texto como aparece no Excel, sem conferir nem corrigir nada.

    Só o necessário para virar texto: vazio → NULL; número inteiro sem ".0"
    (55121.0 → "55121"); data do Excel → aaaa-mm-dd (com hora, se houver);
    VERDADEIRO/FALSO como no Excel em português. O texto fica como está.
    """
    if valor is None:
        return None
    if isinstance(valor, bool):
        return "VERDADEIRO" if valor else "FALSO"
    if isinstance(valor, float):
        return str(int(valor)) if valor.is_integer() else repr(valor)
    if isinstance(valor, datetime):
        return valor.strftime("%Y-%m-%d") if (valor.hour, valor.minute, valor.second) == (0, 0, 0)             else valor.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(valor, date):
        return valor.strftime("%Y-%m-%d")
    t = str(valor)
    return t if t != "" else None


def achar_cabecalho(linhas: list[tuple], obrigatorios: list[str]) -> tuple[int, dict[str, int]] | None:
    """(índice da linha, {cabeçalho normalizado: coluna}) da primeira linha que
    tem todos os cabeçalhos obrigatórios."""
    alvo = {normalizar_cabecalho(c) for c in obrigatorios}
    for i, linha in enumerate(linhas[:LINHAS_PROCURA_CABECALHO]):
        mapa: dict[str, int] = {}
        for j, celula in enumerate(linha):
            nome = normalizar_cabecalho(celula)
            if nome and nome not in mapa:
                mapa[nome] = j
        if alvo <= set(mapa):
            return i, mapa
    return None


def cabecalhos_encontrados(linhas: list[tuple]) -> list[str]:
    """Textos da linha mais parecida com um cabeçalho (para a mensagem de erro).

    São nomes de coluna, não dados."""
    melhor: list[str] = []
    for linha in linhas[:LINHAS_PROCURA_CABECALHO]:
        nomes = [texto(c) for c in linha if texto(c) and not texto(c).replace(".", "").isdigit()]
        if len(nomes) > len(melhor):
            melhor = nomes
    return melhor


def ler_abas(caminho) -> list[tuple[str, list[tuple]]]:
    """[(nome da aba, linhas)] de todas as abas (somente leitura, valores)."""
    from openpyxl import load_workbook

    wb = load_workbook(caminho, read_only=True, data_only=True)
    try:
        return [(ws.title, list(ws.iter_rows(values_only=True))) for ws in wb.worksheets]
    finally:
        wb.close()


def data_br(valor) -> str | None:
    """Data da planilha → aaaa-mm-dd. Texto em dia/mês/ano; célula de data direto."""
    if valor is None or valor == "":
        return None
    if isinstance(valor, (datetime, date)):
        return valor.strftime("%Y-%m-%d")
    t = str(valor).strip()
    for formato in ("%d/%m/%Y", "%d/%m/%y", "%Y-%m-%d"):
        try:
            return datetime.strptime(t, formato).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return None
