"""Inventários usados para gerar o PTI e os documentos de configuração.

Cada inventário vem de uma planilha Excel mantida pelas equipes e fica numa
tabela própria com prefixo inv_ (esquema.py), exatamente como está na
planilha (mesmas linhas, mesmos valores, mais a linha do Excel de origem):

  inv_operadoras_csp   operadoras com CSP
  inv_al_anatel        áreas locais da Anatel
  inv_rn1              repositório de RN1
  inv_rotngin          ROTNGIN em uso na fixa (ASITX VIVO1 região 3)
  inv_sas_resumido     labels de SAS resumido em uso
  inv_livres           planilha livres_sas_resumido_rotngin (uma coluna por CN)
  inv_cargas           registro de cada carga (base, arquivo, linhas, quando, quem)

As planilhas vão em data/inventarios/ e são carregadas sozinhas (carga.py,
vigia.py). Os códigos livres são calculados em faixas.py: faixas da planilha
de livres menos o que já está em uso.
"""
