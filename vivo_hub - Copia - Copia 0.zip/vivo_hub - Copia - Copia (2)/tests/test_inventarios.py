"""Testes da carga dos inventários (planilhas fictícias no formato das reais).

As planilhas entram exatamente como estão: nada é conferido nem corrigido.
"""
from __future__ import annotations

import os
import shutil
import sqlite3
import sys
import tempfile
import time
import unittest
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from openpyxl import Workbook  # noqa: E402

from inventarios import faixas  # noqa: E402
from inventarios.carga import analisar, carregar, carregar_alterados, relatorio  # noqa: E402
from inventarios.esquema import criar_esquema  # noqa: E402

# Layout da planilha de livres como está hoje (colunas separadas por tabulação)
LIVRES_TSV = """cn\t11\t12\t13\t14\t15\t16\t17\t18\t19\t\tROTNGIN cn 11 ao 19\t
\tD00478\tD02204\tD03208\tC48E\tC50B\tD06263\tC76B\tD08253\tD09307\t\tC8791573\t
\tD00479\tD02205\tD03209\tC49B\tC51B\tD06264\tC76C\tD08254\tD09308\t\tC8791574\t
\tD00480\tD02206\tD03210\tC49C\tC52B\tD06265\tC76D\tD08255\tD09309\t\tC8791575\t
\tD00481\tD02207\tD03211\tC49D\tC53B\taté\tC76E\taté\taté\t\taté\t
\tD00482\tD02208\tD03212\tC49E\tC54B\tD06999\tC77B\tD08999\tD09999\t\tC8799999\t
\taté\taté\taté\tD04000\tC55B\t\tC77C\t\t\t\t\t
\tD00199\tD02299\tD03999\taté\tC56B\t\tC77D\t\t\t\t\t
\t\t\t\tD04999\tC57B\t\tC77E\t\t\t\t\t
\t\t\t\t\tC58B\t\tC78B\t\t\t\t\tspo
\t\t\t\t\tC59B\t\tC78C\t\t\t\t\t
\t\t\t\t\tC50C\t\tC78D\t\t\t\t\t
\t\t\t\t\tC51C\t\tC78E\t\t\t\t\t
\t\t\t\t\tC52C\t\tC79B\t\t\t\t\t
\t\t\t\t\tC53C\t\tC79C\t\t\t\t\t
\t\t\t\t\tC54C\t\tC79D\t\t\t\t\t
\t\t\t\t\tC55C\t\tC79E\t\t\t\t\t
\t\t\t\t\tC56C\t\t\t\t\t\t\t
\t\t\t\t\tC57C\t\tdepois de acabar os núemros acima\t\t\t\t\t
\t\t\t\t\tC58C\t\t\t\t\t\t\t
\t\t\t\t\tC59C\t\tD07000\t\t\t\t\t
\t\t\t\t\tC50D\t\taté\t\t\t\t\t
\t\t\t\t\tC51D\t\tD07999\t\t\t\t\t
\t\t\t\t\tC52D\t\t\t\t\t\t\t
\t\t\t\t\tC53D\t\t\t\t\t\t\t
\t\t\t\t\tC54D\t\t\t\t\t\t\t
\t\t\t\t\tC55D\t\t\t\t\t\t\t
\t\t\t\t\tC56D\t\t\t\t\t\t\t
\t\t\t\t\tC57D\t\t\t\t\t\t\t
\t\t\t\t\tC58D\t\t\t\t\t\t\t
\t\t\t\t\tC59D\t\t\t\t\t\t\t
\t\t\t\t\tdepois de acabar os núemros acima\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t15\tD05000\tD05499\tusar apenas para CSP15 do cn 15\t\t\t\t
\t\t\t\t\t15\tD05500\tD05599\tUsar para LC e CNG no cn 15\t\t\t\t"""


def planilha(caminho: Path, linhas: list[list]) -> Path:
    wb = Workbook()
    ws = wb.active
    for linha in linhas:
        ws.append(linha)
    wb.save(caminho)
    return caminho


def livres_linhas() -> list[list]:
    linhas = []
    for linha in LIVRES_TSV.split("\n"):
        celulas = [c if c != "" else None for c in linha.split("\t")]
        linhas.append([int(c) if c and c.isdigit() and len(c) == 2 else c for c in celulas])
    return linhas


class Base(unittest.TestCase):
    def setUp(self):
        self.pasta = Path(tempfile.mkdtemp(prefix="inventarios_"))
        self.db = sqlite3.connect(":memory:")
        self.db.row_factory = sqlite3.Row
        criar_esquema(self.db)

    def tearDown(self):
        self.db.close()
        shutil.rmtree(self.pasta, ignore_errors=True)

    def antigo(self, caminho: Path) -> Path:
        """Arquivo 'pronto' (modificado há mais de 10 s)."""
        t = time.time() - 60
        os.utime(caminho, (t, t))
        return caminho

    def linhas(self, tabela: str) -> list[dict]:
        return [dict(r) for r in self.db.execute(f"SELECT * FROM {tabela} ORDER BY linha_planilha, id")]


class TestComoEstaNoExcel(Base):
    def test_operadoras_com_csp_entram_como_estao(self):
        p = planilha(self.pasta / "operadoras_com_csp.xlsx", [
            ["RN1", "Nome Fantasia", "CSP"],
            [55121, "Operadora A", 21],
            [55121, "Operadora A repetida", 21],          # repetida: entra
            [5512, "Operadora B ", "5"],                   # RN1 curto e espaço no fim: entram como estão
            [None, None, None],                            # totalmente vazia: fica de fora
            [None, "Só o nome", None]])                    # parcialmente vazia: entra
        r = carregar(self.db, "operadoras_csp", p)
        self.assertTrue(r["ok"])
        linhas = self.linhas("inv_operadoras_csp")
        self.assertEqual([(l["linha_planilha"], l["rn1"], l["nome_fantasia"], l["csp"]) for l in linhas], [
            (2, "55121", "Operadora A", "21"), (3, "55121", "Operadora A repetida", "21"),
            (4, "5512", "Operadora B ", "5"), (6, None, "Só o nome", None)])
        carga = self.db.execute("SELECT * FROM inv_cargas").fetchone()
        self.assertEqual((carga["situacao"], carga["linhas"]), ("ok", 4))

    def test_rotngin_com_linhas_incompletas(self):
        p = planilha(self.pasta / "rot.xlsx", [
            ["OPERADORA", "CN", "LOCALIDADE", "TIPO DE ROTA", "ROTNGIN", "rn1"],
            ["DB3", 12, "SJC", "LC + TR LC", "C8790000", 55104],
            [None, None, None, None, "C8790001", "-"],     # só ROTNGIN e rn1 fora do padrão
            ["X", 123, None, "LD15", "C8790000", 55104],    # CN com 3 dígitos e ROTNGIN repetido
        ])
        r = carregar(self.db, "rotngin", p)
        self.assertTrue(r["ok"])
        self.assertEqual(r["linhas"], 3)
        self.assertEqual(self.linhas("inv_rotngin")[1]["rn1"], "-")
        self.assertEqual(self.linhas("inv_rotngin")[2]["cn"], "123")

    def test_sas_com_labels_repetidos_e_anotacoes(self):
        p = planilha(self.pasta / "sas.xlsx", [
            ["CN", "OPERADORA", "LABEL (SAS)", "ROTA", "rn1", None, None, "sas resumido"],
            [11, "Op A", "C000", "LC", 55124, None, 1, "para alocar label sas resumido"],
            [11, "Op B", "C000", "LD15", 55737, None, 2, "com cn + rn1 vc já sabe"],   # label repetido: entra
            [None, None, None, None, None, None, 3, "se existir label alocado usa esses mesmos"],
        ])
        r = carregar(self.db, "sas_resumido", p)
        self.assertTrue(r["ok"])
        self.assertEqual([l["operadora"] for l in self.linhas("inv_sas_resumido")], ["Op A", "Op B"])

    def test_al_anatel_com_colunas_de_apoio(self):
        p = planilha(self.pasta / "al_anatel.xlsx", [
            ["SIGLA_AL", "AREA_LOCAL", "LOCALIDADE", "SIGLA_CNL", "COD_CNL", None, "SIGLA_CNL", "CN", "AREA_LOCAL"],
            ["PPE", "PRESIDENTE PRUDENTE", "ADAMANTINA", "ADT", 11001, "FALSO", "PPE", 18, "PRESIDENTE PRUDENTE"],
            ["CAS", "CAMPINAS", "AGUAI", "AAI", 11004, "FALSO", "CAS", 19, "CAMPINAS"]])
        self.assertTrue(carregar(self.db, "al_anatel", p)["ok"])
        row = self.linhas("inv_al_anatel")[0]
        self.assertEqual((row["sigla_cnl"], row["cod_cnl"], row["cn"]), ("ADT", "11001", "18"))

    def test_rn1_valores_como_estao(self):
        p = planilha(self.pasta / "rn1.xlsx", [
            ["DATA MODIFICAÇÃO", "IDP", "NOM                      ", "TTE", "RN1 (YY)    (CSP SAS)",
             "AÇÃO (TIPO DE MODIFICAÇÃO)", "CSP (OPERADORA)", "ECR", "RN1", "RESP", "existe anexo 5?", "IDP"],
            [datetime(2001, 1, 1), "AAA", "OPERADORA_A", "FIXO2", "05", "Acrescentar", "70 (virtual)", None, 55205, None, "não", "AAA"],
            ["13/02/2001", "BBB", "OPERADORA_B", "MOVEL", 14, None, "-", None, 55314, None, 55127, "BBB"]])
        self.assertTrue(carregar(self.db, "rn1", p)["ok"])
        a, b = self.linhas("inv_rn1")
        self.assertEqual((a["data_modificacao"], a["rn1_yy"], a["csp_operadora"]), ("2001-01-01", "05", "70 (virtual)"))
        self.assertEqual((b["data_modificacao"], b["rn1_yy"], b["existe_anexo5"]), ("13/02/2001", "14", "55127"))

    def test_so_o_cabecalho_impede_a_carga(self):
        p = planilha(self.pasta / "x.xlsx", [["OPERADORA", "CN", "LOCALIDADE", "TIPO", "CODIGO", "rn1"],
                                             ["X", 12, "SJC", "LD15", "C8790000", 55104]])
        r = carregar(self.db, "rotngin", p)
        self.assertFalse(r["ok"])
        self.assertIn("não achei as colunas: ROTNGIN, TIPO DE ROTA", r["erros"][0])
        self.assertIn("Colunas encontradas: OPERADORA, CN, LOCALIDADE, TIPO, CODIGO, rn1", r["erros"][0])

    def test_carga_com_erro_mantem_a_anterior(self):
        ok = planilha(self.pasta / "a.xlsx", [["RN1", "Nome Fantasia", "CSP"], [55121, "Sigilosa SA", 21]])
        carregar(self.db, "operadoras_csp", ok)
        ruim = planilha(self.pasta / "b.xlsx", [["RN1", "Nome", "CSP"], [55121, "Sigilosa SA", 21]])
        r = carregar(self.db, "operadoras_csp", ruim)
        self.assertFalse(r["ok"])
        self.assertNotIn("Sigilosa", " ".join(r["erros"]))
        self.assertEqual(len(self.linhas("inv_operadoras_csp")), 1)


class TestLivres(Base):
    def test_planilha_entra_como_esta(self):
        p = planilha(self.pasta / "livres.xlsx", livres_linhas())
        r = carregar(self.db, "livres", p)
        self.assertTrue(r["ok"], r["erros"])
        linhas = self.linhas("inv_livres")
        self.assertEqual(len(linhas), 33)                                   # todas as linhas com conteúdo
        self.assertEqual((linhas[0]["linha_planilha"], linhas[0]["cn_11"], linhas[0]["rotngin"]), (2, "D00478", "C8791573"))
        self.assertEqual(linhas[6]["cn_11"], "D00199")                      # a faixa invertida fica como está
        self.assertEqual(linhas[8]["anotacoes"], "spo")
        especial = [l for l in linhas if l["cn_15"] == "15"]
        self.assertEqual([(l["cn_16"], l["cn_17"]) for l in especial], [("D05000", "D05499"), ("D05500", "D05599")])
        # A faixa invertida só é apontada, não impede a carga
        self.assertEqual(r["avisos"], ["linha 8, coluna CN 11: faixa invertida (fim menor que o início)"])

    def test_codigos_livres(self):
        carregar(self.db, "livres", planilha(self.pasta / "livres.xlsx", livres_linhas()))
        # CN 11: só os avulsos (a faixa invertida não gera códigos)
        self.assertEqual(faixas.livres(self.db, "sas_resumido", "11"), ["D00478", "D00479", "D00480", "D00481", "D00482"])
        self.assertEqual(len(faixas.livres(self.db, "sas_resumido", "15")), 30)          # C50B..C59D
        self.assertEqual(faixas.livres(self.db, "sas_resumido", "15", uso="csp15", limite=1), ["D05000"])
        self.assertEqual(faixas.livres(self.db, "sas_resumido", "15", uso="lc_cng", limite=1), ["D05500"])
        self.assertEqual(faixas.livres(self.db, "sas_resumido", "17", limite=1), ["C76B"])
        self.assertEqual(faixas.livres(self.db, "sas_resumido", "17")[16], "D07000")      # depois dos 16 C7x
        self.db.execute("INSERT INTO inv_sas_resumido (cn, operadora, label, rota, rn1) VALUES ('12','X','D02204','LC','55104')")
        self.assertEqual(faixas.livres(self.db, "sas_resumido", "12", limite=3), ["D02205", "D02206", "D02207"])
        self.assertEqual(len(faixas.livres(self.db, "sas_resumido", "12")), 95)          # D02205..D02299
        self.db.execute("INSERT INTO inv_rotngin (operadora, cn, localidade, tipo_rota, rotngin, rn1) "
                        "VALUES ('X','12','SJC','LC','C8791573','55104')")
        self.assertEqual(faixas.livres(self.db, "rotngin", "12", limite=2), ["C8791574", "C8791575"])


class TestPasta(Base):
    def test_carrega_so_o_que_mudou(self):
        p = self.antigo(planilha(self.pasta / "operadoras_com_csp.xlsx", [["RN1", "Nome Fantasia", "CSP"], [55121, "A", 21]]))
        self.assertEqual(len(carregar_alterados(self.db, self.pasta)), 1)
        self.assertEqual(carregar_alterados(self.db, self.pasta), [])           # mesmo arquivo: não relê
        planilha(p, [["RN1", "Nome Fantasia", "CSP"], [55121, "A", 21], [55112, "B", 12]])
        self.assertEqual(carregar_alterados(self.db, self.pasta), [])           # acabou de mudar: espera
        self.antigo(p)
        r = carregar_alterados(self.db, self.pasta)
        self.assertEqual((len(r), r[0]["linhas"]), (1, 2))

    def test_relatorio_sem_valores(self):
        self.antigo(planilha(self.pasta / "operadoras_com_csp.xlsx",
                             [["RN1", "Nome Fantasia", "CSP"], [55121, "Nome Sigiloso", 21]]))
        rel = {i["base"]: i for i in relatorio(self.db, self.pasta)}
        self.assertEqual(rel["operadoras_csp"]["linhas"], 1)
        self.assertNotIn("Sigiloso", repr({k: v for k, v in rel["operadoras_csp"].items() if k != "ultima"}))
        self.assertFalse(rel["rn1"]["presente"])


class TestAtualizacaoDoBanco(unittest.TestCase):
    def test_tabelas_da_versao_anterior(self):
        """Banco com as tabelas da versão 1 (obrigatórios e únicos): dados mantidos,
        restrições retiradas e planilhas marcadas para reler."""
        db = sqlite3.connect(":memory:")
        self.addCleanup(db.close)
        db.executescript("""
            CREATE TABLE inv_operadoras_csp (id INTEGER PRIMARY KEY AUTOINCREMENT, rn1 TEXT NOT NULL UNIQUE,
                nome_fantasia TEXT NOT NULL, csp TEXT NOT NULL);
            CREATE TABLE inv_faixas_codigos (id INTEGER PRIMARY KEY AUTOINCREMENT, tipo TEXT NOT NULL,
                cn TEXT, inicio TEXT NOT NULL, fim TEXT, prioridade INTEGER, uso TEXT, observacao TEXT);
            CREATE TABLE inv_cargas (id INTEGER PRIMARY KEY AUTOINCREMENT, base TEXT NOT NULL, arquivo TEXT,
                hash TEXT, situacao TEXT NOT NULL DEFAULT 'ok', linhas INTEGER NOT NULL DEFAULT 0, mensagem TEXT,
                carregado_em TEXT NOT NULL, carregado_por TEXT);
            INSERT INTO inv_operadoras_csp (rn1, nome_fantasia, csp) VALUES ('55121', 'A', '21');
            INSERT INTO inv_cargas (base, arquivo, hash, linhas, carregado_em) VALUES ('operadoras_csp', 'x.xlsx', 'abc', 1, '2026-11-04');
        """)
        criar_esquema(db)
        self.assertEqual(db.execute("SELECT rn1, nome_fantasia FROM inv_operadoras_csp").fetchall(), [("55121", "A")])
        db.execute("INSERT INTO inv_operadoras_csp (rn1, nome_fantasia, csp) VALUES ('55121', NULL, NULL)")   # agora aceita
        self.assertIsNone(db.execute("SELECT hash FROM inv_cargas").fetchone()[0])
        tabelas = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
        self.assertNotIn("inv_faixas_codigos", tabelas)
        self.assertIn("inv_livres", tabelas)
        criar_esquema(db)                                   # rodar de novo não muda nada
        self.assertEqual(db.execute("SELECT COUNT(*) FROM inv_operadoras_csp").fetchone()[0], 2)


if __name__ == "__main__":
    unittest.main()
