"""Testes do fluxo do PTI (linha do tempo). Executar: python -m unittest discover -s tests

Banco SQLite em memória com o mesmo esquema da aplicação; o relógio é
controlado para testar SLA, pausas e alertas de prazo.
"""
from __future__ import annotations

import sqlite3
import sys
import unittest
from contextlib import ExitStack, contextmanager
from datetime import datetime, timedelta
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from db import _ATACADO_FORMS_MIGRATIONS, _SCHEMA_SQL, _ensure_column  # noqa: E402
from fluxo import alertas, consultas, indicadores  # noqa: E402
from fluxo.definicao import ETAPAS, Ator  # noqa: E402
from fluxo.esquema import criar_esquema, migrar_formularios  # noqa: E402
from fluxo.servico import ConflitoVersao, Fluxo, FluxoErro, transacao  # noqa: E402
from fluxo.tempo import DIA_UTIL, segundos_uteis, situacao_sla, avancar_util  # noqa: E402
from inventarios.esquema import criar_esquema as criar_esquema_inventarios  # noqa: E402

# Segunda-feira, 10h em Brasília (13h UTC)
SEGUNDA = datetime(2026, 10, 5, 13, 0, 0)


@contextmanager
def relogio(dt: datetime):
    """Fixa agora() em todos os módulos do fluxo."""
    alvos = ["fluxo.tempo.agora", "fluxo.servico.agora", "fluxo.consultas.agora",
             "fluxo.alertas.agora", "fluxo.indicadores.agora"]
    with ExitStack() as pilha:
        for alvo in alvos:
            pilha.enter_context(mock.patch(alvo, return_value=dt))
        yield


def novo_banco() -> sqlite3.Connection:
    db = sqlite3.connect(":memory:")
    db.row_factory = sqlite3.Row
    db.executescript(_SCHEMA_SQL)
    for coluna, definicao in _ATACADO_FORMS_MIGRATIONS:
        _ensure_column(db, "atacado_forms", coluna, definicao)
    db.executemany("INSERT INTO users (id, email, password_hash, role) VALUES (?, ?, 'x', ?)", [
        (1, "ana.atacado@vivo.com", "atacado"),
        (2, "bruno.eng@vivo.com", "engenharia"),
        (3, "carla.atacado@vivo.com", "atacado"),
        (4, "davi.eng@vivo.com", "engenharia"),
    ])
    db.commit()
    criar_esquema(db)
    criar_esquema_inventarios(db)   # como em db.init_db
    db.commit()
    return db


ATACADO = Ator(1, "ana.atacado@vivo.com", "atacado")
OUTRO_ATACADO = Ator(3, "carla.atacado@vivo.com", "atacado")
ENG = Ator(2, "bruno.eng@vivo.com", "engenharia")
ENG2 = Ator(4, "davi.eng@vivo.com", "engenharia")
ADMIN = Ator(2, "bruno.eng@vivo.com", "engenharia", admin=True)


class Base(unittest.TestCase):
    def setUp(self):
        self.db = novo_banco()

    def tearDown(self):
        self.db.close()

    def criar(self, dono: int = 1, quando: datetime = SEGUNDA, status: str = "rascunho") -> int:
        with relogio(quando), transacao(self.db):
            cur = self.db.execute(
                "INSERT INTO atacado_forms (owner_id, status, nome_operadora, version, created_at, updated_at) "
                "VALUES (?, ?, 'Operadora Teste', 1, ?, ?)", (dono, status, quando.isoformat(" "), quando.isoformat(" ")))
            Fluxo(self.db, Ator(dono, "", "atacado")).criar_processo(cur.lastrowid)
        return cur.lastrowid

    def agir(self, ator: Ator, quando: datetime, metodo: str, *args, **kwargs):
        with relogio(quando), transacao(self.db):
            return getattr(Fluxo(self.db, ator), metodo)(*args, **kwargs)

    def proc(self, form_id: int):
        return consultas.processo(self.db, form_id)

    def eventos(self, form_id: int) -> list[str]:
        return [r["tipo"] for r in self.db.execute(
            "SELECT tipo FROM pti_eventos WHERE form_id = ? ORDER BY id", (form_id,))]

    def conferir_invariantes(self, form_id: int):
        """Sempre há área responsável, exatamente uma etapa aberta e o status derivado bate."""
        p = self.proc(form_id)
        self.assertTrue(p["area_responsavel"])
        abertas = self.db.execute("SELECT id FROM pti_etapas WHERE form_id = ? AND fim_em IS NULL",
                                  (form_id,)).fetchall()
        self.assertEqual(len(abertas), 1)
        self.assertEqual(abertas[0]["id"], p["etapa_instancia_id"])
        status = self.db.execute("SELECT status FROM atacado_forms WHERE id = ?", (form_id,)).fetchone()
        if status:
            self.assertEqual(status["status"], ETAPAS[p["etapa"]].status)


class TestTransicoes(Base):
    def test_criacao(self):
        fid = self.criar()
        p = self.proc(fid)
        self.assertEqual(p["etapa"], "elaboracao")
        self.assertEqual(p["area_responsavel"], "atacado")
        self.assertEqual(p["usuario_responsavel_id"], 1)
        self.assertEqual(self.eventos(fid), ["processo_criado"])
        self.conferir_invariantes(fid)

    def test_envio_passa_responsabilidade_para_engenharia(self):
        fid = self.criar()
        self.agir(ATACADO, SEGUNDA + timedelta(hours=2), "enviar", fid)
        p = self.proc(fid)
        self.assertEqual(p["etapa"], "validacao_tecnica")
        self.assertEqual(p["area_responsavel"], "engenharia")
        self.assertIsNone(p["usuario_responsavel_id"])
        self.assertIsNotNone(p["primeiro_envio_em"])
        ev = self.db.execute("SELECT * FROM pti_eventos WHERE form_id = ? AND tipo = 'enviado'", (fid,)).fetchone()
        self.assertEqual((ev["area_anterior"], ev["area_nova"]), ("atacado", "engenharia"))
        self.assertEqual((ev["etapa_anterior"], ev["etapa_nova"]), ("elaboracao", "validacao_tecnica"))
        self.assertEqual(ev["usuario_id"], 1)
        self.assertEqual(ev["tempo_etapa_anterior_s"], 2 * 3600)
        elab = self.db.execute("SELECT * FROM pti_etapas WHERE form_id = ? AND etapa = 'elaboracao'", (fid,)).fetchone()
        self.assertEqual(elab["desfecho"], "concluida")
        self.assertEqual(elab["tempo_util_s"], 2 * 3600)
        alerta = self.db.execute("SELECT * FROM pti_alertas WHERE form_id = ?", (fid,)).fetchone()
        self.assertEqual(alerta["area_destino"], "engenharia")
        self.conferir_invariantes(fid)

    def test_transicoes_invalidas_sao_barradas(self):
        fid = self.criar()
        with self.assertRaises(FluxoErro):
            self.agir(ENG, SEGUNDA, "aprovar", fid)            # etapa errada
        with self.assertRaises(FluxoErro):
            self.agir(OUTRO_ATACADO, SEGUNDA, "enviar", fid)   # não é o dono
        self.agir(ATACADO, SEGUNDA, "enviar", fid)
        with self.assertRaises(FluxoErro):
            self.agir(ATACADO, SEGUNDA, "aprovar", fid)        # área errada
        with self.assertRaises(FluxoErro):
            self.agir(ATACADO, SEGUNDA, "enviar", fid)         # já enviado
        with self.assertRaises(FluxoErro):
            self.agir(ENG, SEGUNDA, "devolver", fid, "")       # motivo obrigatório
        self.assertEqual(self.proc(fid)["etapa"], "validacao_tecnica")
        self.conferir_invariantes(fid)

    def test_devolucao_e_reenvio(self):
        fid = self.criar()
        self.agir(ATACADO, SEGUNDA, "enviar", fid)
        self.agir(ENG, SEGUNDA + timedelta(hours=1), "assumir", fid)
        self.agir(ENG, SEGUNDA + timedelta(hours=3), "devolver", fid, "CN divergente",
                  ["Corrigir o CN da linha 2", "Informar o ASN"])
        p = self.proc(fid)
        self.assertEqual((p["etapa"], p["area_responsavel"], p["usuario_responsavel_id"]), ("ajustes", "atacado", 1))
        self.assertEqual(p["retornos"], 1)
        self.assertEqual(len(consultas.pendencias(self.db, fid, abertas=True)), 2)
        ev = self.db.execute("SELECT * FROM pti_eventos WHERE tipo = 'devolvido'").fetchone()
        self.assertEqual(ev["motivo"], "CN divergente")
        self.assertIn("Informar o ASN", ev["pendencias_json"])
        alerta = self.db.execute("SELECT * FROM pti_alertas WHERE tipo = 'devolvido'").fetchone()
        self.assertEqual((alerta["area_destino"], alerta["usuario_destino_id"]), ("atacado", 1))
        self.conferir_invariantes(fid)

        self.agir(ATACADO, SEGUNDA + timedelta(hours=5), "enviar", fid)   # vira reenvio
        p = self.proc(fid)
        self.assertEqual(p["etapa"], "validacao_tecnica")
        self.assertEqual(p["usuario_responsavel_id"], 2)                  # o mesmo engenheiro
        self.assertIn("reenviado", self.eventos(fid))
        inst = consultas.instancia_atual(self.db, p)
        self.assertEqual(inst["ocorrencia"], 2)
        self.conferir_invariantes(fid)

    def test_aprovacao_exige_pendencias_resolvidas(self):
        fid = self.criar()
        self.agir(ATACADO, SEGUNDA, "enviar", fid)
        pid = self.agir(ENG, SEGUNDA, "abrir_pendencia", fid, "Conferir a Mask", "engenharia")
        with self.assertRaises(FluxoErro):
            self.agir(ENG, SEGUNDA, "aprovar", fid)
        self.agir(ENG, SEGUNDA, "resolver_pendencia", fid, pid, "Conferida")
        self.agir(ENG, SEGUNDA + timedelta(days=1), "aprovar", fid)
        p = self.proc(fid)
        self.assertEqual(p["etapa"], "concluido")
        self.assertIsNotNone(p["concluido_em"])
        self.conferir_invariantes(fid)

    def test_reabertura_preserva_historico(self):
        fid = self.criar()
        self.agir(ATACADO, SEGUNDA, "enviar", fid)
        self.agir(ENG, SEGUNDA, "aprovar", fid)
        antes = [dict(r) for r in self.db.execute("SELECT * FROM pti_eventos WHERE form_id = ?", (fid,))]
        with self.assertRaises(FluxoErro):
            self.agir(ENG, SEGUNDA, "reabrir", fid, "")
        self.agir(ENG2, SEGUNDA + timedelta(days=1), "reabrir", fid, "Mask errada")
        depois = [dict(r) for r in self.db.execute("SELECT * FROM pti_eventos WHERE form_id = ?", (fid,))]
        self.assertEqual(depois[:len(antes)], antes)
        self.assertEqual(depois[-1]["tipo"], "reaberto")
        p = self.proc(fid)
        self.assertEqual((p["etapa"], p["reaberturas"], p["concluido_em"]), ("validacao_tecnica", 1, None))
        self.assertEqual(p["usuario_responsavel_id"], 4)
        self.conferir_invariantes(fid)

    def test_cancelamento_e_reabertura(self):
        fid = self.criar()
        with self.assertRaises(FluxoErro):
            self.agir(ENG, SEGUNDA, "cancelar", fid, "x")       # Engenharia não cancela
        self.agir(ATACADO, SEGUNDA, "cancelar", fid, "Operadora desistiu")
        self.assertEqual(self.proc(fid)["etapa"], "cancelado")
        self.conferir_invariantes(fid)
        self.agir(ATACADO, SEGUNDA, "reabrir", fid, "Operadora voltou")
        self.assertEqual(self.proc(fid)["etapa"], "elaboracao")
        self.conferir_invariantes(fid)

    def test_operadora(self):
        fid = self.criar()
        self.agir(ATACADO, SEGUNDA, "enviar", fid)
        self.agir(ENG, SEGUNDA, "enviar_operadora", fid)
        p = self.proc(fid)
        self.assertEqual((p["etapa"], p["area_responsavel"]), ("resposta_operadora", "integracao"))
        self.conferir_invariantes(fid)
        self.agir(ENG, SEGUNDA + timedelta(days=2), "registrar_resposta_operadora", fid,
                  {"tipo": "PTI respondido", "arquivo": "pti.xlsx"})
        p = self.proc(fid)
        self.assertEqual((p["etapa"], p["usuario_responsavel_id"]), ("validacao_tecnica", 2))
        ev = self.db.execute("SELECT * FROM pti_eventos WHERE tipo = 'resposta_importada'").fetchone()
        self.assertEqual(ev["origem"], "integracao")
        self.assertIn("pti.xlsx", ev["documentos_json"])
        self.conferir_invariantes(fid)

    def test_trava_otimista(self):
        fid = self.criar()
        self.agir(ATACADO, SEGUNDA, "enviar", fid)
        versao = self.proc(fid)["versao_registro"]
        self.agir(ENG, SEGUNDA, "comentar", fid, "Olhando agora")
        with self.assertRaises(ConflitoVersao):
            self.agir(ENG, SEGUNDA, "aprovar", fid, versao=versao)
        self.agir(ENG, SEGUNDA, "aprovar", fid, versao=self.proc(fid)["versao_registro"])
        self.assertEqual(self.proc(fid)["etapa"], "concluido")

    def test_transacao_desfaz_tudo_em_erro(self):
        fid = self.criar()
        with self.assertRaises(FluxoErro), relogio(SEGUNDA), transacao(self.db):
            self.db.execute("UPDATE atacado_forms SET nome_operadora = 'Alterada' WHERE id = ?", (fid,))
            Fluxo(self.db, ENG).aprovar(fid)
        nome = self.db.execute("SELECT nome_operadora FROM atacado_forms WHERE id = ?", (fid,)).fetchone()[0]
        self.assertEqual(nome, "Operadora Teste")
        self.assertEqual(self.eventos(fid), ["processo_criado"])


class TestAuditoria(Base):
    def test_eventos_sao_imutaveis(self):
        fid = self.criar()
        with self.assertRaises(sqlite3.DatabaseError):
            self.db.execute("UPDATE pti_eventos SET motivo = 'x' WHERE form_id = ?", (fid,))
        with self.assertRaises(sqlite3.DatabaseError):
            self.db.execute("DELETE FROM pti_eventos WHERE form_id = ?", (fid,))

    def test_exclusao_so_antes_do_primeiro_envio(self):
        fid = self.criar()
        ok, _ = Fluxo(self.db, ATACADO).pode_excluir(fid)
        self.assertTrue(ok)
        ok, _ = Fluxo(self.db, OUTRO_ATACADO).pode_excluir(fid)
        self.assertFalse(ok)
        fid2 = self.criar()
        self.agir(ATACADO, SEGUNDA, "enviar", fid2)
        self.agir(ENG, SEGUNDA, "devolver", fid2, "Ajustar")
        ok, msg = Fluxo(self.db, ATACADO).pode_excluir(fid2)
        self.assertFalse(ok)
        self.assertIn("Cancelar", msg)
        self.agir(ATACADO, SEGUNDA, "excluir", fid)
        self.db.execute("DELETE FROM atacado_forms WHERE id = ?", (fid,))
        p = self.proc(fid)
        self.assertEqual(p["etapa"], "excluido")
        self.assertIn("excluido", self.eventos(fid))

    def test_dados_alterados(self):
        fid = self.criar()
        antes = self.db.execute("SELECT * FROM atacado_forms WHERE id = ?", (fid,)).fetchone()
        self.assertIsNone(self.agir(ATACADO, SEGUNDA, "registrar_dados", fid, antes,
                                    {"nome_operadora": "Operadora Teste"}, ["nome_operadora"]))
        self.agir(ATACADO, SEGUNDA, "registrar_dados", fid, antes, {"nome_operadora": "Nova", "asn": "12345"},
                  ["nome_operadora", "asn"])
        ev = self.db.execute("SELECT * FROM pti_eventos WHERE tipo = 'dados_atualizados'").fetchone()
        self.assertIn('"para": "Nova"', ev["dados_alterados_json"])

    def test_permissao_de_edicao(self):
        fid = self.criar()
        self.assertTrue(Fluxo(self.db, ATACADO).pode_editar(fid)[0])
        self.assertFalse(Fluxo(self.db, ENG).pode_editar(fid)[0])
        self.agir(ATACADO, SEGUNDA, "enviar", fid)
        ok, msg = Fluxo(self.db, ATACADO).pode_editar(fid)
        self.assertFalse(ok)
        self.assertIn("Engenharia", msg)
        self.assertTrue(Fluxo(self.db, ENG).pode_editar(fid)[0])

    def test_formulario_sem_processo_e_migrado_na_hora(self):
        cur = self.db.execute("INSERT INTO atacado_forms (owner_id, status) VALUES (1, 'enviado')")
        self.db.commit()
        ok, _ = Fluxo(self.db, ENG).pode_editar(cur.lastrowid)
        self.assertTrue(ok)
        self.assertEqual(self.proc(cur.lastrowid)["etapa"], "validacao_tecnica")

    def test_migracao_do_status_antigo(self):
        ids = {}
        for st in ("rascunho", "enviado", "aprovado", "reprovado", "em revisão"):
            cur = self.db.execute(
                "INSERT INTO atacado_forms (owner_id, status, created_at, updated_at) VALUES "
                "(1, ?, '2026-09-01 12:00:00', '2026-09-03 12:00:00')", (st,))
            ids[st] = cur.lastrowid
        self.assertEqual(migrar_formularios(self.db), 5)
        self.assertEqual(migrar_formularios(self.db), 0)
        esperado = {"rascunho": "elaboracao", "enviado": "validacao_tecnica", "aprovado": "concluido",
                    "reprovado": "ajustes", "em revisão": "resposta_operadora"}
        for st, fid in ids.items():
            self.assertEqual(self.proc(fid)["etapa"], esperado[st])
            self.conferir_invariantes(fid)
        # Etapa atual migrada recebe o SLA configurado (início = data estimada)
        inst = consultas.instancia_atual(self.db, self.proc(ids["enviado"]))
        self.assertEqual(inst["sla_dias_uteis"], 3)
        # Processo migrado continua no fluxo normalmente
        self.agir(ENG, SEGUNDA, "aprovar", ids["enviado"])
        self.assertEqual(self.proc(ids["enviado"])["etapa"], "concluido")


class TestTempo(Base):
    def test_dias_uteis(self):
        sexta_18h = datetime(2026, 10, 9, 21, 0)     # 18h em Brasília
        segunda_9h = datetime(2026, 10, 12, 12, 0)   # 9h em Brasília
        self.assertEqual(segundos_uteis(sexta_18h, segunda_9h), (6 + 9) * 3600)
        self.assertEqual(avancar_util(sexta_18h, 15 * 3600), segunda_9h)
        self.assertEqual(situacao_sla(10, 100, aberta=True), "no_prazo")
        self.assertEqual(situacao_sla(80, 100, aberta=True), "proximo")
        self.assertEqual(situacao_sla(101, 100, aberta=True), "vencido")
        self.assertEqual(situacao_sla(50, 100, aberta=True, suspenso=True), "suspenso")
        self.assertEqual(situacao_sla(101, 100, aberta=False), "descumprido")

    def test_pausa_e_bloqueio_fora_do_sla(self):
        fid = self.criar()
        self.agir(ATACADO, SEGUNDA, "enviar", fid)
        self.agir(ENG, SEGUNDA + timedelta(hours=2), "pausar", fid, "Aguardando janela")
        with self.assertRaises(FluxoErro):
            self.agir(ENG, SEGUNDA + timedelta(hours=3), "aprovar", fid)
        self.agir(ENG, SEGUNDA + timedelta(days=1, hours=2), "retomar", fid)
        self.agir(ENG, SEGUNDA + timedelta(days=1, hours=3), "bloquear", fid, "Falta o CN", "ausencia_informacao", "atacado")
        self.assertEqual(len([p for p in consultas.pendencias(self.db, fid, abertas=True) if p["bloqueante"]]), 1)
        self.agir(ATACADO, SEGUNDA + timedelta(days=1, hours=7), "desbloquear", fid, "CN informado")
        self.assertEqual(len(consultas.pendencias(self.db, fid, abertas=True)), 0)
        with relogio(SEGUNDA + timedelta(days=1, hours=8)):
            t = consultas.tempos_instancia(self.db, consultas.instancia_atual(self.db, self.proc(fid)))
        self.assertEqual(t["pausado_s"], DIA_UTIL)
        self.assertEqual(t["bloqueado_s"], 4 * 3600)
        self.assertEqual(t["aguardando_info_s"], 4 * 3600)
        self.assertEqual(t["ativo_s"], 2 * 3600 + 1 * 3600 + 1 * 3600)
        self.assertEqual(t["sla"], "no_prazo")
        tempos = consultas.tempos_por_responsabilidade(self.db, fid)["segundos"]
        self.assertEqual(tempos["pausado"], DIA_UTIL)

    def test_reenvio_de_bloqueado_encerra_bloqueio(self):
        fid = self.criar()
        self.agir(ATACADO, SEGUNDA, "enviar", fid)
        self.agir(ENG, SEGUNDA, "devolver", fid, "Ajustar")
        self.agir(ATACADO, SEGUNDA, "bloquear", fid, "Aguardo a operadora", "dependencia_externa", "integracao")
        self.agir(ATACADO, SEGUNDA + timedelta(hours=1), "enviar", fid)
        p = self.proc(fid)
        self.assertEqual((p["etapa"], p["situacao"]), ("validacao_tecnica", "ativo"))
        self.assertFalse([x for x in consultas.pendencias(self.db, fid, abertas=True) if x["bloqueante"]])
        self.conferir_invariantes(fid)


class TestAlertasEIndicadores(Base):
    def test_alertas_de_prazo(self):
        fid = self.criar()
        self.agir(ATACADO, SEGUNDA, "enviar", fid)
        with relogio(SEGUNDA + timedelta(days=2, hours=8)):     # 2,3 de 3 dias úteis
            self.assertEqual(alertas.gerar_alertas_de_prazo(self.db), 1)
        with relogio(SEGUNDA + timedelta(days=4)):              # sexta: vencido
            criados = alertas.gerar_alertas_de_prazo(self.db)
            self.assertGreaterEqual(criados, 1)
            self.assertEqual(alertas.gerar_alertas_de_prazo(self.db), 0)   # sem duplicar
        tipos = {r["tipo"] for r in self.db.execute("SELECT tipo FROM pti_alertas")}
        self.assertTrue({"sla_proximo", "sla_vencido"} <= tipos)

    def test_visibilidade_dos_alertas(self):
        fid = self.criar()
        self.agir(ATACADO, SEGUNDA, "enviar", fid)
        self.agir(ENG, SEGUNDA, "devolver", fid, "Ajustar")
        self.assertEqual(alertas.nao_lidos(self.db, 1, "atacado"), 1)
        self.assertEqual(alertas.nao_lidos(self.db, 3, "atacado"), 0)
        self.assertEqual(alertas.nao_lidos(self.db, 2, "engenharia"), 1)
        alertas.marcar_lidos(self.db, 1, "atacado")
        self.assertEqual(alertas.nao_lidos(self.db, 1, "atacado"), 0)

    def test_indicadores(self):
        a = self.criar()
        b = self.criar()
        c = self.criar(dono=3)
        self.agir(ATACADO, SEGUNDA, "enviar", a)
        self.agir(ENG, SEGUNDA + timedelta(hours=4), "devolver", a, "Ajustar")
        self.agir(ATACADO, SEGUNDA + timedelta(days=1), "enviar", a)
        self.agir(ENG, SEGUNDA + timedelta(days=1, hours=4), "aprovar", a)
        self.agir(ATACADO, SEGUNDA, "enviar", b)
        with relogio(SEGUNDA + timedelta(days=2)):
            r = indicadores.calcular(self.db, indicadores.normalizar_filtros({}))
            self.assertEqual(r["resumo"]["total"], 3)
            self.assertEqual(r["resumo"]["concluidos"], 1)
            self.assertEqual(r["resumo"]["abertos"], 2)
            self.assertEqual(r["resumo"]["devolucoes"], 1)
            self.assertEqual(r["resumo"]["taxa_devolucao"], 50)
            eng = next(x for x in r["por_equipe"] if x["area"] == "engenharia")
            self.assertEqual(eng["com_a_equipe"], 1)
            validacao = next(x for x in r["por_etapa"] if x["etapa"] == "validacao_tecnica")
            self.assertEqual(validacao["passagens"], 3)
            so_meus = indicadores.calcular(self.db, indicadores.normalizar_filtros({}), form_ids={c})
            self.assertEqual(so_meus["resumo"]["total"], 1)
            filtrado = indicadores.calcular(self.db, indicadores.normalizar_filtros({"situacao": "concluido"}))
            self.assertEqual([x["form_id"] for x in filtrado["processos"]], [a])
            por_equipe = indicadores.calcular(self.db, indicadores.normalizar_filtros({"equipe": "engenharia"}))
            self.assertTrue(all(x["area"] == "engenharia" or x["passagens"] == 0 for x in por_equipe["por_equipe"]
                                if x["processos"]))

    def test_linha_do_tempo_e_estado(self):
        fid = self.criar()
        self.agir(ATACADO, SEGUNDA, "enviar", fid)
        with relogio(SEGUNDA + timedelta(hours=1)):
            itens = consultas.linha_do_tempo(self.db, fid)
            est = consultas.estado(self.db, fid)
        self.assertEqual([i["chave"] for i in itens],
                         ["elaboracao", "validacao_tecnica", "resposta_operadora", "concluido"])
        self.assertEqual([i["estado"] for i in itens], ["concluida", "atual", "futura", "futura"])
        self.assertEqual(est["frase"], "Em validação técnica pela Engenharia")
        self.assertEqual(est["area_nome"], "Engenharia")
        self.agir(ENG, SEGUNDA + timedelta(hours=2), "aprovar", fid)
        with relogio(SEGUNDA + timedelta(hours=3)):
            itens = consultas.linha_do_tempo(self.db, fid)
        self.assertEqual([i["estado"] for i in itens], ["concluida", "concluida", "ignorada", "encerrada"])


if __name__ == "__main__":
    unittest.main()
