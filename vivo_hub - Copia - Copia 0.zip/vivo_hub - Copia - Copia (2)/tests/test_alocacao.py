"""Testes dos labels ROTNGIN e da Tabela 2 do ECR (dados fictícios)."""
from __future__ import annotations

import json
import sqlite3
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from excel.ecr import EcrErro, linhas_tabela2, montar  # noqa: E402
from inventarios import alocacao  # noqa: E402
from inventarios.esquema import criar_esquema  # noqa: E402
from traffic_types import TIPOS_COM_LABEL, conflitos_de_grupo  # noqa: E402

LC = "Tráf LC + Trans LC - CN XY (N8)"
LD15 = "LD15 + CNG"
LDSCSP = "LD S/CSP + CNG Oper."
VC1 = "VC1 - CN"


def formulario(id_=10, parent=None, tipos=(LC, LD15), linhas=None, rn1="55181", nome="Operadora Teste"):
    if linhas is None:
        linhas = [{"localidade": "sjc", "cn": "12", "cidade": "São José dos Campos"}]
    return {"id": id_, "parent_id": parent, "version": 1, "nome_operadora": nome, "rn1": rn1,
            "escopo_flags_json": json.dumps(list(tipos)), "dados_operadora_json": json.dumps(linhas)}


class Base(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(":memory:")
        self.db.row_factory = sqlite3.Row
        criar_esquema(self.db)
        self.db.executemany(
            "INSERT INTO inv_rotngin (linha_planilha, operadora, cn, localidade, tipo_rota, rotngin, rn1) VALUES (?,?,?,?,?,?,?)",
            [(2, "DB3", "12", "SJC", "LC + TR LC", "C8790000", "55104"),
             (3, None, None, None, None, "c8791571 ", "0"),          # como está na planilha
             (4, "X", "16", "RPO", "LD15", "C8791572", "55915"),
             (5, None, None, None, None, "anotação", None)])

    def tearDown(self):
        self.db.close()

    def codigos(self):
        return [r["rotngin"] for r in self.db.execute("SELECT rotngin FROM inv_rotngin_alocados ORDER BY id")]


class TestGrupos(unittest.TestCase):
    def test_um_por_grupo(self):
        self.assertEqual(conflitos_de_grupo([LC, LD15, LDSCSP, VC1]), [])
        self.assertEqual(conflitos_de_grupo(["Tráf LC - CN XY (N8)", LC, LD15]), [["Tráf LC - CN XY (N8)", LC]])

    def test_so_os_quatro_primeiros_grupos_tem_label(self):
        self.assertIn("TRANSP LD s/CSP", TIPOS_COM_LABEL)
        self.assertNotIn(VC1, TIPOS_COM_LABEL)
        self.assertNotIn("STIR SHAKEN (TRANSP LD XY)", TIPOS_COM_LABEL)


class TestAlocacao(Base):
    def test_segue_a_sequencia_do_inventario(self):
        self.assertEqual(alocacao.proximo_codigo(self.db), "C8791573")
        r = alocacao.alocar(self.db, formulario(tipos=(LC, LD15, VC1)), "eng@teste")
        self.assertEqual([(i["tipo"], i["rotngin"]) for i in r["alocados"]], [(LC, "C8791573"), (LD15, "C8791574")])
        linha = dict(self.db.execute("SELECT * FROM inv_rotngin_alocados WHERE rotngin = 'C8791574'").fetchone())
        self.assertEqual((linha["operadora"], linha["cn"], linha["localidade"], linha["tipo_rota"], linha["rn1"]),
                         ("Operadora Teste", "12", "SJC", LD15, "55181"))
        self.assertEqual(alocacao.proximo_codigo(self.db), "C8791575")

    def test_um_label_por_localidade_e_tipo(self):
        linhas = [{"localidade": "PPE", "cn": "18"}, {"localidade": "ppe ", "cn": "18"},   # mesma localidade
                  {"localidade": "BTU", "cn": "14"}, {"localidade": "", "cn": "14"}]
        form = formulario(tipos=(LC, LD15, LDSCSP), linhas=linhas)
        s = alocacao.situacao(self.db, form)
        self.assertEqual(len(s["itens"]), 6)
        self.assertEqual(s["avisos"], ["Dados Operadora, linha 4: sem CN ou sem localidade; não recebe label."])
        alocacao.alocar(self.db, form, None)
        self.assertEqual(self.codigos(), [f"C879{n}" for n in range(1573, 1579)])

    def test_alocar_de_novo_nao_muda_nada(self):
        form = formulario()
        alocacao.alocar(self.db, form, None)
        r = alocacao.alocar(self.db, form, None)
        self.assertEqual((r["alocados"], r["liberados"]), ([], []))
        self.assertEqual(alocacao.situacao(self.db, form)["pendentes"], 0)

    def test_tipo_retirado_e_liberado(self):
        alocacao.alocar(self.db, formulario(tipos=(LC, LD15)), None)
        form = formulario(tipos=(LD15, LDSCSP))
        s = alocacao.situacao(self.db, form)
        self.assertEqual([r["rotngin"] for r in s["a_liberar"]], ["C8791573"])
        r = alocacao.alocar(self.db, form, None)
        self.assertEqual([i["rotngin"] for i in r["liberados"]], ["C8791573"])
        self.assertEqual([i["rotngin"] for i in r["alocados"]], ["C8791575"])
        self.assertEqual(self.codigos(), ["C8791574", "C8791575"])

    def test_nova_versao_usa_os_labels_da_anterior(self):
        alocacao.alocar(self.db, formulario(id_=10), None)
        v2 = formulario(id_=11, parent=10, tipos=(LD15,))
        s = alocacao.situacao(self.db, v2)
        self.assertEqual([i["rotngin"] for i in s["itens"]], ["C8791574"])
        self.assertEqual(s["a_liberar"], [])                  # o LC é da versão 1: a 2 não libera
        alocacao.alocar(self.db, formulario(id_=11, parent=10, tipos=(LD15, LDSCSP)), None)
        self.assertEqual(len(alocacao.liberar_da_versao(self.db, 11)), 1)
        self.assertEqual(self.codigos(), ["C8791573", "C8791574"])

    def test_sem_inventario(self):
        self.db.execute("DELETE FROM inv_rotngin")
        with self.assertRaises(alocacao.AlocacaoErro):
            alocacao.alocar(self.db, formulario(), None)

    def test_recarga_da_planilha_nao_apaga_os_alocados(self):
        alocacao.alocar(self.db, formulario(), None)
        self.db.execute("DELETE FROM inv_rotngin")            # a carga troca a tabela inteira
        self.db.execute("INSERT INTO inv_rotngin (rotngin) VALUES ('C8790000')")
        self.assertEqual(alocacao.proximo_codigo(self.db), "C8791575")


class TestTabela2(Base):
    def setUp(self):
        super().setUp()
        self.db.executemany("INSERT INTO inv_al_anatel (linha_planilha, sigla_al, area_local, localidade, sigla_cnl, cod_cnl, cn) "
                            "VALUES (?,?,?,?,?,?,?)",
                            [(2, "SJC", "SAO JOSE DOS CAMPOS", "SAO JOSE DOS CAMPOS", "SJC", "11563", "12"),
                             (3, "TTE", "TAUBATE", "TAUBATE", "TBT", "11570", "12")])
        self.db.executemany("INSERT INTO inv_rn1 (linha_planilha, idp, rn1) VALUES (?,?,?)",
                            [(2, "ITL", "55181"), (3, "ITEL", "55181 "), (4, None, "55181")])

    def test_so_com_ld15(self):
        form = formulario(tipos=(LC, LDSCSP))
        alocacao.alocar(self.db, form, None)
        self.assertIsNone(linhas_tabela2(self.db, form))

    def test_exige_label_alocado(self):
        with self.assertRaises(EcrErro):
            linhas_tabela2(self.db, formulario())

    def test_linhas(self):
        linhas = [{"localidade": "SJC", "cn": "12", "cidade": "São José dos Campos"},
                  {"localidade": "Taubaté", "cn": "12", "cidade": "Taubaté"}]
        form = formulario(linhas=linhas)
        alocacao.alocar(self.db, form, None)          # LC: 1573, LD15: 1574 (SJC) / LC: 1575, LD15: 1576 (Taubaté)
        t2 = linhas_tabela2(self.db, form)
        self.assertEqual([(l["cn"], l["milhar_ini"], l["milhar_fin"], l["tipo"], l["cnl"], l["label"], l["idp"]) for l in t2], [
            ("12", "0000", "9999", "1", "11563", "C8791574", "ITEL"),
            ("12", "B000", "E999", "1", "11563", "C8791574", "ITEL"),
            ("12", "0000", "9999", "1", "11570", "C8791576", "ITEL"),
            ("12", "B000", "E999", "1", "11570", "C8791576", "ITEL")])
        ws = montar(t2).active
        self.assertEqual(ws.title, "LABELS E PREFIXOS")
        self.assertEqual([ws.cell(3, c).value for c in range(1, 9)],
                         ["CN", "PREFIXO", "MILHAR_INI", "MILHAR_FIN", "TIPO", "CNL", "LABEL", "IDP"])
        self.assertEqual((ws["A1"].value, ws["A2"].value, ws["C4"].value, ws["G5"].value, ws["I4"].value),
                         ("TABELA 2", "NUMERAÇÃO OUTRAS", "0000", "C8791574", "São José dos Campos"))


if __name__ == "__main__":
    unittest.main()
