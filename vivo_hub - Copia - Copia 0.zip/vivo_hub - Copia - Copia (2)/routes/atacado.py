"""routes/atacado.py — CRUD de formulários do perfil Atacado + versionamento."""
import json
import logging

from flask import (
    Blueprint, abort, flash, redirect, render_template,
    request, session, url_for,
)

from auth import login_required, role_required
from config import BOOLEAN_FIELDS, ENG_ITX_NAME, MAX_TABLE_ROWS, TEXT_FIELDS
from db import get_db
from fluxo import consultas
from fluxo.servico import Fluxo, FluxoErro, transacao
from forms import extract_form_payload, validate_cn_uf_rows, validate_table_rows
from helpers import display_name_from_email, group_forms_by_operadora, utc_now_str
from operadoras import rn1_is_valid, rn1_nome_match
from queries import build_list_query, get_status_counters
from routes.processos import ator_atual
from traffic_types import conflitos_de_grupo

logger = logging.getLogger(__name__)
bp = Blueprint("atacado", __name__, url_prefix="/atacado_formularios")

# Colunas JSON gravadas junto com os campos de texto/booleanos.
_JSON_COLS = ["escopo_flags_json", "dados_vivo_json", "dados_operadora_json"]
# O status não é gravado pelo formulário: é derivado da etapa do fluxo
# (fluxo/servico.py). O campo "status" do pedido só indica a intenção
# ("enviado" = botão Enviar à Engenharia).
_FORM_COLS = [c for c in TEXT_FIELDS if c != "status"] + list(BOOLEAN_FIELDS) + _JSON_COLS


def _apply_fixed_responsaveis(payload: dict) -> None:
    """Campos de responsáveis não são editáveis: valores definidos no servidor.

    - Gestão ITX Atacado = usuário logado (responsavel_atacado/responsavel_vivo)
    - Eng de ITX e Aprovado por = ENG_ITX_NAME (definido em config.py)
    """
    gestao = display_name_from_email(session.get("email", ""))
    payload["responsavel_atacado"]    = gestao
    payload["responsavel_vivo"]       = gestao
    payload["responsavel_engenharia"] = ENG_ITX_NAME
    payload["aprovado_por"]           = ENG_ITX_NAME


def _validate_payload(db, payload: dict) -> list[str]:
    """Valida campos restritos contra o Anexo 5. Retorna lista de erros.

    Em rascunho, campos vazios são tolerados; valores preenchidos nunca
    podem estar fora da tabela de operadoras.
    """
    errors: list[str] = []
    strict = payload.get("status") == "enviado"

    rn1  = (payload.get("rn1") or "").strip()
    nome = (payload.get("nome_operadora") or "").strip()
    tmr  = (payload.get("tmr") or "").strip()

    if rn1:
        if not rn1_is_valid(rn1):
            errors.append("RN1 deve conter apenas números (máx. 5 dígitos).")
        elif not db.execute(
            "SELECT 1 FROM operadoras WHERE rn1 = ? LIMIT 1", (rn1,)
        ).fetchone():
            errors.append(f"RN1 {rn1} não consta no Anexo 5.")
    elif strict:
        errors.append("Informe o RN1 da operadora.")

    if nome:
        if not db.execute(
            "SELECT 1 FROM operadoras WHERE nome = ? LIMIT 1", (nome,)
        ).fetchone():
            errors.append(f'Operadora "{nome}" não consta no Anexo 5.')
        elif rn1 and rn1_is_valid(rn1) and not rn1_nome_match(db, rn1, nome):
            errors.append(f'O RN1 {rn1} não pertence à operadora "{nome}".')
    elif strict:
        errors.append("Informe o nome da operadora.")

    if tmr and not (tmr.isdigit() and len(tmr) <= 2):
        errors.append("TMR deve conter apenas números (máx. 2 dígitos).")

    asn = (payload.get("asn") or "").strip()
    if asn and not (asn.isdigit() and 5 <= len(asn) <= 6):
        errors.append("ASN deve conter apenas números (5 a 6 dígitos).")

    # Um tipo de tráfego por grupo (o formulário já troca a escolha sozinho)
    try:
        tipos = json.loads(payload.get("escopo_flags_json") or "[]")
    except (json.JSONDecodeError, TypeError):
        tipos = []
    for conflito in conflitos_de_grupo(tipos):
        errors.append("Tipos de tráfego: escolha só um destes, que são do mesmo grupo: "
                      + ", ".join(conflito) + ".")

    errors += validate_cn_uf_rows(payload.get("dados_operadora_json", "[]"), "Dados Operadora")
    errors += validate_cn_uf_rows(payload.get("dados_vivo_json", "[]"), "Dados VIVO")

    return errors


def _get_own_form(db, form_id: int):
    """Retorna o formulário se pertencer ao usuário logado; senão 404."""
    form = db.execute(
        "SELECT * FROM atacado_forms WHERE id = ? AND owner_id = ?",
        (form_id, session["user_id"]),
    ).fetchone()
    if not form:
        abort(404)
    return form


# ---------------------------------------------------------------------------
# LISTAGEM — agrupada por operadora, com versões
# ---------------------------------------------------------------------------
@bp.get("")
@login_required
@role_required("atacado")
def form_list():
    db     = get_db()
    uid    = session["user_id"]
    q      = (request.args.get("q") or "").strip()
    status = (request.args.get("status") or "").strip()

    sql, params = build_list_query(
        "SELECT * FROM atacado_forms",
        search_term=q or None,
        status_filter=status or None,
        owner_id=uid,
        sort_key="operadora_version",
    )
    forms    = db.execute(sql, params).fetchall()
    grupos   = group_forms_by_operadora(forms)
    counters = get_status_counters(db, "WHERE owner_id = ?", (uid,))

    return render_template(
        "atacado_formularios.html",
        grupos=grupos,
        counters=counters,
        resumos=consultas.resumo_processos(db, [f["id"] for f in forms]),
        q=q,
        status=status,
        # Registro recém-criado/atualizado: destacado uma vez na lista
        destaque_id=session.pop("_destaque_pti", None),
    )


# ---------------------------------------------------------------------------
# CRIAR
# ---------------------------------------------------------------------------
@bp.get("/new")
@login_required
@role_required("atacado")
def form_new():
    return render_template("formulario_atacado.html", form=None)


@bp.post("/new")
@login_required
@role_required("atacado")
def form_create():
    payload = extract_form_payload()
    payload["owner_id"]               = session["user_id"]
    payload["status"]                 = (payload.get("status") or "rascunho").lower()
    payload["engenharia_params_json"] = "{}"
    payload["version"]                = 1
    payload["parent_id"]              = None
    truncated = validate_table_rows(payload)
    _apply_fixed_responsaveis(payload)

    db = get_db()
    errors = _validate_payload(db, payload)
    if errors:
        for err in errors:
            flash(err, "warning")
        return redirect(url_for("atacado.form_new"))

    cols = ["owner_id", "version", "parent_id"] + _FORM_COLS + ["engenharia_params_json"]
    enviar = payload["status"] == "enviado"
    try:
        with transacao(db):
            cur = db.execute(
                f"INSERT INTO atacado_forms ({','.join(cols)}) "
                f"VALUES ({','.join(['?'] * len(cols))})",
                [payload.get(c) for c in cols],
            )
            fluxo = Fluxo(db, ator_atual())
            fluxo.criar_processo(cur.lastrowid)
            if enviar:
                fluxo.enviar(cur.lastrowid)
    except FluxoErro as exc:
        flash(str(exc), "danger")
        return redirect(url_for("atacado.form_new"))
    session["_destaque_pti"] = cur.lastrowid

    msg = (f"Pré-PTI #{cur.lastrowid} enviado à Engenharia, que passa a ser a responsável."
           if enviar else f"Pré-PTI #{cur.lastrowid} salvo em elaboração (rascunho).")
    if truncated:
        msg += f" Tabelas limitadas a {MAX_TABLE_ROWS} linhas."
    flash(msg, "success")
    return redirect(url_for("atacado.form_list"))


# ---------------------------------------------------------------------------
# NOVA VERSÃO
# ---------------------------------------------------------------------------
@bp.post("/<int:form_id>/new_version")
@login_required
@role_required("atacado")
def form_new_version(form_id: int):
    db   = get_db()
    orig = _get_own_form(db, form_id)

    root_id = orig["parent_id"] or orig["id"]
    max_ver = db.execute(
        "SELECT MAX(version) FROM atacado_forms "
        "WHERE owner_id = ? AND (id = ? OR parent_id = ?)",
        (session["user_id"], root_id, root_id),
    ).fetchone()[0] or 1
    next_ver = max_ver + 1

    row_dict = dict(orig)
    with transacao(db):
        cur = db.execute(
            f"INSERT INTO atacado_forms "
            f"(owner_id, version, parent_id, status, {','.join(_FORM_COLS)}, engenharia_params_json) "
            f"VALUES (?, ?, ?, 'rascunho', {','.join(['?'] * len(_FORM_COLS))}, '{{}}')",
            [session["user_id"], next_ver, root_id] + [row_dict.get(c) for c in _FORM_COLS],
        )
        Fluxo(db, ator_atual()).criar_processo(cur.lastrowid, versao_de=form_id)
    session["_destaque_pti"] = cur.lastrowid

    flash(f"Versão {next_ver} criada a partir do formulário #{form_id}.", "success")
    return redirect(url_for("atacado.form_list"))


# ---------------------------------------------------------------------------
# EDITAR
# ---------------------------------------------------------------------------
@bp.get("/<int:form_id>")
@login_required
@role_required("atacado")
def form_edit(form_id: int):
    db = get_db()
    form = _get_own_form(db, form_id)
    pode_editar, motivo = Fluxo(db, ator_atual()).pode_editar(form_id)
    return render_template(
        "formulario_atacado.html", form=form,
        estado=consultas.estado(db, form_id, form),
        somente_leitura=not pode_editar, motivo_leitura=motivo,
    )


@bp.post("/<int:form_id>")
@login_required
@role_required("atacado")
def form_update(form_id: int):
    db = get_db()
    antes = _get_own_form(db, form_id)
    fluxo = Fluxo(db, ator_atual())
    pode_editar, motivo = fluxo.pode_editar(form_id)
    if not pode_editar:
        flash(motivo, "warning")
        return redirect(url_for("processos.processo", form_id=form_id))

    payload               = extract_form_payload()
    payload["status"]     = (payload.get("status") or "rascunho").lower()
    payload["updated_at"] = utc_now_str()
    truncated             = validate_table_rows(payload)
    _apply_fixed_responsaveis(payload)

    errors = _validate_payload(db, payload)
    if errors:
        for err in errors:
            flash(err, "warning")
        return redirect(url_for("atacado.form_edit", form_id=form_id))

    assignments = ", ".join([f"{col} = ?" for col in _FORM_COLS] + ["updated_at = ?"])
    params = (
        [payload.get(col) for col in _FORM_COLS]
        + [payload["updated_at"], form_id, session["user_id"]]
    )
    enviar = payload["status"] == "enviado"
    try:
        with transacao(db):
            db.execute(
                f"UPDATE atacado_forms SET {assignments} WHERE id = ? AND owner_id = ?",
                params,
            )
            fluxo.registrar_dados(form_id, antes, payload, _FORM_COLS)
            if enviar:
                fluxo.enviar(form_id)
    except FluxoErro as exc:
        flash(str(exc), "danger")
        return redirect(url_for("atacado.form_edit", form_id=form_id))
    session["_destaque_pti"] = form_id

    msg = (f"Pré-PTI #{form_id} enviado à Engenharia, que passa a ser a responsável."
           if enviar else f"Pré-PTI #{form_id} salvo.")
    if truncated:
        msg += f" Tabelas limitadas a {MAX_TABLE_ROWS} linhas."
    flash(msg, "success")
    return redirect(url_for("atacado.form_list"))


# ---------------------------------------------------------------------------
# DELETAR
# ---------------------------------------------------------------------------
@bp.post("/<int:form_id>/delete")
@login_required
@role_required("atacado")
def form_delete(form_id: int):
    """Exclusão só antes do primeiro envio; depois disso, o caminho é cancelar
    (a linha do tempo do excluído fica no banco para auditoria)."""
    db = get_db()
    _get_own_form(db, form_id)
    fluxo = Fluxo(db, ator_atual())
    pode, motivo = fluxo.pode_excluir(form_id)
    if not pode:
        flash(motivo, "warning")
        return redirect(url_for("processos.processo", form_id=form_id))
    with transacao(db):
        fluxo.excluir(form_id)
        db.execute(
            "DELETE FROM atacado_forms WHERE id = ? AND owner_id = ?",
            (form_id, session["user_id"]),
        )
    flash(f"Pré-PTI #{form_id} excluído. O registro da exclusão fica no histórico.", "info")
    return redirect(url_for("atacado.form_list"))
