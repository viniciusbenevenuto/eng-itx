"""excel/ecr.py — Documento de configuração ECR.

Primeira parte: aba LABELS E PREFIXOS, Tabela 2 (numeração outras). A tabela
só existe quando o PTI tem LD15 + CNG. Cada localidade da operadora vira um
bloco com as milhares padrão (0000–9999 e B000–E999):

    CN        CN da localidade (Dados Operadora)
    PREFIXO   em branco por enquanto (preenchimento manual)
    TIPO      sempre 1
    CNL       inventário al_anatel, pela localidade (sigla CNL ou nome)
    LABEL     label ROTNGIN alocado para o LD15 + CNG da localidade
    IDP       repositório de RN1, pelo RN1 da operadora

Os labels precisam estar alocados antes (inventarios/alocacao.py).
"""
from __future__ import annotations

import sqlite3

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from inventarios import alocacao
from traffic_types import TIPO_LD15

MILHARES = (("0000", "9999"), ("B000", "E999"))
TIPO_NUMERACAO = "1"
COLUNAS = (("CN", 6), ("PREFIXO", 12), ("MILHAR_INI", 13), ("MILHAR_FIN", 13),
           ("TIPO", 7), ("CNL", 10), ("LABEL", 14), ("IDP", 10))


class EcrErro(Exception):
    """O documento não pode ser gerado (mensagem pronta para o usuário)."""


def linhas_tabela2(db: sqlite3.Connection, form) -> list[dict] | None:
    """Linhas da Tabela 2; None quando o PTI não tem LD15 + CNG."""
    if TIPO_LD15 not in alocacao.tipos_com_label(form):
        return None
    locs, _ = alocacao.localidades(form)
    if not locs:
        raise EcrErro("Preencha CN e Localidade em Dados Operadora.")
    labels = alocacao.labels_ld15(db, form)
    faltando = [f"{l['localidade']} (CN {l['cn']})" for l in locs if (l["cn"], l["localidade"]) not in labels]
    if faltando:
        raise EcrErro("Falta alocar o label ROTNGIN do LD15 + CNG para " + ", ".join(faltando)
                      + ". Use \"Alocar labels\" no formulário de validação.")
    codigo_idp = alocacao.idp(db, form["rn1"])
    linhas = []
    for loc in locs:
        codigo_cnl = alocacao.cnl(db, loc["cn"], loc["localidade"], loc["cidade"])
        for ini, fim in MILHARES:
            linhas.append({"cn": loc["cn"], "prefixo": "", "milhar_ini": ini, "milhar_fin": fim,
                           "tipo": TIPO_NUMERACAO, "cnl": codigo_cnl,
                           "label": labels[(loc["cn"], loc["localidade"])], "idp": codigo_idp,
                           "localidade": loc["cidade"] or loc["localidade"]})
    return linhas


def montar(linhas: list[dict]) -> Workbook:
    wb = Workbook()
    ws = wb.active
    ws.title = "LABELS E PREFIXOS"

    amarelo = PatternFill("solid", fgColor="FFFF00")
    fina = Side(style="thin", color="000000")
    borda = Border(left=fina, right=fina, top=fina, bottom=fina)
    centro = Alignment(horizontal="center", vertical="center")
    negrito = Font(name="Calibri", size=11, bold=True)
    normal = Font(name="Calibri", size=11)
    cinza = Font(name="Calibri", size=11, color="808080")
    ultima = len(COLUNAS)

    for linha, titulo in ((1, "TABELA 2"), (2, "NUMERAÇÃO OUTRAS")):
        ws.merge_cells(start_row=linha, start_column=1, end_row=linha, end_column=ultima)
        for col in range(1, ultima + 1):
            c = ws.cell(row=linha, column=col)
            c.fill, c.border = amarelo, borda
        c = ws.cell(row=linha, column=1, value=titulo)
        c.font, c.alignment = negrito, centro

    for col, (nome, largura) in enumerate(COLUNAS, start=1):
        c = ws.cell(row=3, column=col, value=nome)
        c.font, c.fill, c.border, c.alignment = negrito, amarelo, borda, centro
        ws.column_dimensions[get_column_letter(col)].width = largura
    ws.column_dimensions[get_column_letter(ultima + 1)].width = 28

    campos = ("cn", "prefixo", "milhar_ini", "milhar_fin", "tipo", "cnl", "label", "idp")
    for i, registro in enumerate(linhas, start=4):
        for col, campo in enumerate(campos, start=1):
            c = ws.cell(row=i, column=col, value=registro[campo])
            c.number_format = "@"          # texto: 0000 continua 0000
            c.font, c.border, c.alignment = normal, borda, centro
        # Referência fora da tabela (como na planilha modelo): a localidade
        ws.cell(row=i, column=ultima + 1, value=registro["localidade"]).font = cinza
    return wb
