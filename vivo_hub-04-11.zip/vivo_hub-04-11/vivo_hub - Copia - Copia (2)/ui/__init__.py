"""Camada de apresentação: ícones Lucide e auxiliares de movimento."""
