/* ==========================================================================
   motion.js · PTI Automatizado
   Motor de movimento em JavaScript puro, sem dependências.
   1 Utilidades · 2 Estado · 3 Relógio · 4 Ciclo · 5 Contagem
   6 Escopos · 7 Leitura · 8 Ciclos disponíveis · 9 Início
   ========================================================================== */
(() => {
  'use strict';

  /* 1 Utilidades ------------------------------------------------------------ */
  const root = document.documentElement;
  const $ = (selector, scope = document) => scope.querySelector(selector);
  const $$ = (selector, scope = document) => Array.from(scope.querySelectorAll(selector));
  const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
  const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);
  const formatNumber = new Intl.NumberFormat('pt-BR').format;
  const PAUSE_KEY = 'pti:motion-paused';

  const storage = {
    get(key) {
      try { return window.localStorage.getItem(key); } catch { return null; }
    },
    set(key, value) {
      try { window.localStorage.setItem(key, value); } catch { /* armazenamento indisponível */ }
    },
  };

  const announce = (message) => {
    const region = $('#announcer');
    if (region) region.textContent = message;
  };

  /* 2 Estado de movimento ----------------------------------------------------
     Pausa do usuário (WCAG 2.2.2, persistida entre páginas), aba oculta e
     prefers-reduced-motion. */
  class MotionState {
    constructor() {
      this.query = window.matchMedia('(prefers-reduced-motion: reduce)');
      this.reduced = this.query.matches;
      this.userPaused = storage.get(PAUSE_KEY) === '1';
      this.hidden = document.hidden;
      this.listeners = new Set();

      const onQuery = () => {
        this.reduced = this.query.matches;
        this.sync();
      };
      if (this.query.addEventListener) this.query.addEventListener('change', onQuery);
      else if (this.query.addListener) this.query.addListener(onQuery);

      document.addEventListener('visibilitychange', () => {
        this.hidden = document.hidden;
        this.sync();
      });
    }

    /** Ciclos e contagens podem avançar. */
    get animating() { return !this.userPaused && !this.hidden && !this.reduced; }

    setPaused(paused) {
      this.userPaused = paused;
      storage.set(PAUSE_KEY, paused ? '1' : '0');
      this.sync();
    }

    subscribe(listener) { this.listeners.add(listener); }

    sync() {
      root.classList.toggle('is-paused', this.userPaused);
      root.classList.toggle('is-hidden', this.hidden);
      root.classList.toggle('is-reduced', this.reduced);
      this.listeners.forEach((listener) => listener(this));
    }
  }

  /* 3 Relógio único -----------------------------------------------------------
     Um só requestAnimationFrame para todos os ciclos; dorme quando ninguém precisa. */
  class Clock {
    constructor() {
      this.tasks = new Set();
      this.frame = 0;
      this.last = 0;
      this.loop = this.loop.bind(this);
    }

    add(task) {
      task.clock = this;
      this.tasks.add(task);
      this.wake();
    }

    wake() {
      if (this.frame) return;
      if (!Array.from(this.tasks).some((task) => task.wantsFrame)) return;
      this.last = performance.now();
      this.frame = requestAnimationFrame(this.loop);
    }

    loop(now) {
      const dt = Math.min(100, Math.max(0, now - this.last));
      this.last = now;
      let busy = false;
      this.tasks.forEach((task) => {
        if (!task.wantsFrame) return;
        busy = true;
        task.tick(dt, now);
      });
      this.frame = busy ? requestAnimationFrame(this.loop) : 0;
    }
  }

  /* 4 Ciclo ----------------------------------------------------------------------
     Passos com duração própria; começa quando o escopo fica vivo, para quando sai,
     segura no item em foco ou sob o mouse e mostra um quadro representativo
     com movimento reduzido. */
  class Cycle {
    constructor({ motion, steps, apply, progress = null, still }) {
      this.motion = motion;
      this.steps = steps;
      this.applyStep = apply;
      this.progress = progress;
      this.stillStep = still;
      this.index = 0;
      this.elapsed = 0;
      this.applied = null;
      this.live = false;
      this.held = false;
      this.clock = null;
    }

    get wantsFrame() { return this.live && !this.held && this.motion.animating; }

    show(index) {
      this.index = index;
      const step = this.steps[index];
      if (this.applied !== step) {
        this.applied = step;
        this.applyStep(step, index);
      }
    }

    restart() {
      this.elapsed = 0;
      this.applied = null;
      this.show(0);
      if (this.progress) this.progress(0, this.steps[0]);
    }

    setLive(live) {
      if (live === this.live) return;
      this.live = live;
      if (!live || this.held) return;
      if (this.motion.animating) this.restart();
      else if (this.applied === null) this.still();
    }

    tick(dt) {
      this.elapsed += dt;
      let step = this.steps[this.index];
      while (this.elapsed >= step.duration) {
        this.elapsed -= step.duration;
        this.show((this.index + 1) % this.steps.length);
        step = this.steps[this.index];
      }
      if (this.progress) this.progress(this.elapsed / step.duration, step);
    }

    hold(index) {
      this.held = true;
      this.elapsed = 0;
      this.show(index);
      if (this.progress) this.progress(1, this.steps[index]);
    }

    release() {
      if (!this.held) return;
      this.held = false;
      this.elapsed = 0;
      if (this.motion.reduced) this.still();
      else if (this.clock) this.clock.wake();
    }

    still() {
      this.held = false;
      this.elapsed = 0;
      this.applied = this.stillStep;
      this.applyStep(this.stillStep, -1);
      if (this.progress) this.progress(1, this.stillStep);
    }
  }

  /* Liga o destaque e a pausa do ciclo ao mouse e ao foco de cada item */
  const bindHold = (items, cycle, stepIndexOf) => {
    items.forEach((item, i) => {
      const enter = () => cycle.hold(stepIndexOf(i));
      const leave = (event) => {
        if (event.type === 'focusout' && item.contains(event.relatedTarget)) return;
        if (event.type === 'pointerleave' && item.contains(document.activeElement)) return;
        cycle.release();
      };
      item.addEventListener('pointerenter', enter);
      item.addEventListener('focusin', enter);
      item.addEventListener('pointerleave', leave);
      item.addEventListener('focusout', leave);
    });
  };

  /* 5 Contagem ----------------------------------------------------------------------
     De zero até o valor real, uma única vez. O número real fica no DOM; a contagem
     é uma camada decorativa sobreposta (aria-hidden). */
  class Counter {
    constructor(element, motion) {
      this.element = element;
      this.motion = motion;
      this.value = Number(element.dataset.count);
      this.done = !Number.isInteger(this.value) || this.value <= 0;
      this.timer = 0;
      this.anim = null;
      element.classList.add('count');
      if (!$('.count__value', element)) {
        const value = document.createElement('span');
        value.className = 'count__value';
        value.textContent = element.textContent.trim();
        element.textContent = '';
        element.append(value);
      }
    }

    run(delay = 0) {
      if (this.done) return;
      this.done = true;
      if (!this.motion.animating) return;
      this.anim = document.createElement('span');
      this.anim.className = 'count__anim';
      this.anim.setAttribute('aria-hidden', 'true');
      this.anim.textContent = '0';
      this.element.append(this.anim);
      this.element.classList.add('is-counting');
      const duration = 900 + Math.min(this.value, 62) * 10;
      this.timer = window.setTimeout(() => {
        const start = performance.now();
        const step = (now) => {
          if (!this.anim) return;
          const t = clamp((now - start) / duration, 0, 1);
          this.anim.textContent = formatNumber(Math.round(easeOutCubic(t) * this.value));
          if (t < 1 && this.motion.animating) requestAnimationFrame(step);
          else this.finish();
        };
        requestAnimationFrame(step);
      }, delay);
    }

    finish() {
      this.done = true;
      window.clearTimeout(this.timer);
      if (this.anim) this.anim.remove();
      this.anim = null;
      this.element.classList.remove('is-counting');
    }
  }

  /* 6 Escopos -----------------------------------------------------------------------
     Geometria medida a cada rolagem (um cálculo por quadro), sem IntersectionObserver.
     Vivo: o escopo ocupa a faixa entre 12% e 88% da altura da tela → ciclos e laços rodam.
     Entrada: o topo do escopo passa de 80% da altura da tela → entra uma única vez. */
  class ScopeWatcher {
    constructor(scopes, { onLive, onReveal }) {
      this.scopes = scopes;
      this.onLive = onLive;
      this.onReveal = onReveal;
      this.live = new Set();
      this.revealed = new Set();
      this.frame = 0;
      const request = () => {
        if (this.frame) return;
        this.frame = requestAnimationFrame(() => {
          this.frame = 0;
          this.check();
        });
      };
      window.addEventListener('scroll', request, { passive: true });
      window.addEventListener('resize', request);
    }

    check() {
      const viewport = window.innerHeight || document.documentElement.clientHeight;
      this.scopes.forEach((scope) => {
        const rect = scope.getBoundingClientRect();
        const live = rect.height > 0 && rect.bottom > viewport * 0.12 && rect.top < viewport * 0.88;
        if (live !== this.live.has(scope)) {
          if (live) this.live.add(scope);
          else this.live.delete(scope);
          this.onLive(scope, live);
        }
        if (!this.revealed.has(scope) && rect.top < viewport * 0.8 && rect.bottom > 0) {
          this.revealed.add(scope);
          this.onReveal(scope);
        }
      });
    }
  }

  /* 7 Leitura -----------------------------------------------------------------------
     Progresso de leitura, tema da barra superior e parallax, num cálculo por quadro. */
  class Reader {
    constructor({ topbar, motion }) {
      this.topbar = topbar;
      this.motion = motion;
      this.progress = topbar ? $('.topbar__progress', topbar) : null;
      this.darkBands = $$('.band--dark');
      this.parallax = $$('[data-parallax]');
      this.frame = 0;
      const request = () => {
        if (this.frame) return;
        this.frame = requestAnimationFrame(() => {
          this.frame = 0;
          this.update();
        });
      };
      window.addEventListener('scroll', request, { passive: true });
      window.addEventListener('resize', request);
    }

    update() {
      const viewport = window.innerHeight;
      const max = document.documentElement.scrollHeight - viewport;
      if (this.progress) {
        this.progress.hidden = max < viewport * 0.5;
        this.progress.style.setProperty('--progress', max > 0 ? (window.scrollY / max).toFixed(4) : '0');
      }
      if (this.topbar) {
        const probe = this.topbar.getBoundingClientRect().height / 2;
        const dark = this.darkBands.some((band) => {
          const rect = band.getBoundingClientRect();
          return rect.top <= probe && rect.bottom > probe;
        });
        this.topbar.dataset.theme = dark ? 'dark' : 'light';
      }
      if (this.motion.reduced) return;
      const middle = viewport / 2;
      this.parallax.forEach((element) => {
        const rect = element.getBoundingClientRect();
        if (rect.bottom < 0 || rect.top > viewport) return;
        const offset = (rect.top + rect.height / 2 - middle) * -0.06;
        element.style.setProperty('--parallax', `${offset.toFixed(1)}px`);
      });
    }
  }

  /* 8 Ciclos disponíveis --------------------------------------------------------------
     sequence: o destaque percorre os itens [data-cycle-item]; cada um fica ativo por
     data-step-ms (2200) e, no fim, todos ficam completos por data-rest-ms (1400).
     É o ciclo dos pilares da apresentação, usado nos cartões de módulo do painel. */
  const CYCLES = {
    sequence(container, motion) {
      const items = $$('[data-cycle-item]', container);
      const stepMs = Number(container.dataset.stepMs || 2200);
      const restMs = Number(container.dataset.restMs || 1400);
      const steps = items.map((item, i) => ({ key: i, duration: stepMs }));
      if (restMs > 0) steps.push({ key: 'all', duration: restMs });
      const cycle = new Cycle({
        motion,
        steps,
        still: { key: 'all' },
        apply: (step) => items.forEach((item, i) => item.classList.toggle('is-active', step.key === i)),
        progress: (p, step) => items.forEach((item, i) => {
          const value = step.key === 'all' ? 1 : step.key === i ? p : 0;
          item.style.setProperty('--p', value.toFixed(3));
        }),
      });
      bindHold(items, cycle, (i) => i);
      return cycle;
    },
  };

  /* 9 Início --------------------------------------------------------------------------- */
  const start = () => {
    const motion = new MotionState();
    const clock = new Clock();
    const scopes = $$('[data-scope]');

    // Entradas: ordem de escalonamento, contadores, atrasos da grade e proporção dos anéis
    scopes.forEach((scope) => {
      $$('[data-reveal]', scope).forEach((element, i) => element.style.setProperty('--i', String(i)));
    });
    const counters = new Map($$('[data-count]').map((element) => [element, new Counter(element, motion)]));
    $$('.cell-ink').forEach((cell) => {
      const position = Number(cell.dataset.p || 0);
      cell.style.setProperty('--delay', `${(position * 2.4 - 5.2).toFixed(3)}s`);
    });
    $$('[data-ring]').forEach((arc) => arc.style.setProperty('--ring', String(Number(arc.dataset.ring) || 0)));

    // Ciclos, agrupados por escopo
    const cyclesByScope = new Map();
    const cycles = [];
    $$('[data-cycle]').forEach((container) => {
      const factory = CYCLES[container.dataset.cycle];
      const scope = container.closest('[data-scope]');
      if (!factory || !scope) return;
      const cycle = factory(container, motion);
      cyclesByScope.set(scope, [...(cyclesByScope.get(scope) || []), cycle]);
      cycles.push(cycle);
      clock.add(cycle);
    });

    const watcher = new ScopeWatcher(scopes, {
      onLive: (scope, live) => {
        scope.classList.toggle('is-live', live);
        (cyclesByScope.get(scope) || []).forEach((cycle) => cycle.setLive(live));
        clock.wake();
      },
      onReveal: (scope) => {
        const instant = scope.dataset.motion === 'static';
        scope.classList.add('is-in');
        $$('[data-count]', scope).forEach((element) => {
          const counter = counters.get(element);
          if (instant) counter.finish();
          else counter.run(420);
        });
      },
    });

    // Movimento reduzido: quadro representativo. Ao voltar a animar, o ciclo que estava
    // no quadro representativo recomeça; o que estava só pausado continua do passo atual.
    let wasAnimating = motion.animating;
    motion.subscribe(() => {
      if (motion.reduced) cycles.forEach((cycle) => cycle.still());
      else if (motion.animating && !wasAnimating) {
        cycles.forEach((cycle) => { if (cycle.live && cycle.applied === cycle.stillStep) cycle.restart(); });
      }
      wasAnimating = motion.animating;
      clock.wake();
    });
    motion.sync();

    // Controle de pausa (WCAG 2.2.2): o ícone alterna entre pausar e retomar
    const pauseButton = $('[data-action="motion"]');
    const renderPause = () => {
      const label = motion.userPaused ? 'Retomar animações' : 'Pausar animações';
      pauseButton.classList.toggle('is-alt', motion.userPaused);
      pauseButton.setAttribute('aria-label', label);
      pauseButton.title = label;
    };
    if (pauseButton) {
      renderPause();
      pauseButton.addEventListener('click', () => {
        motion.setPaused(!motion.userPaused);
        renderPause();
        announce(motion.userPaused ? 'Animações pausadas.' : 'Animações retomadas.');
      });
    }

    const reader = new Reader({ topbar: $('#topbar'), motion });
    reader.update();
    watcher.check();
    root.classList.add('is-ready');

    // Impressão: tudo visível, números finais e quadros representativos
    window.addEventListener('beforeprint', () => {
      scopes.forEach((scope) => scope.classList.add('is-in'));
      counters.forEach((counter) => counter.finish());
      cycles.forEach((cycle) => cycle.still());
    });
    window.addEventListener('afterprint', () => {
      if (motion.animating) cycles.forEach((cycle) => { if (cycle.live) cycle.restart(); });
    });

    window.PTI = Object.assign(window.PTI || {}, { motion, announce });
    document.dispatchEvent(new CustomEvent('pti:ready'));
  };

  // Começa com as fontes prontas (ou após 800 ms), para as palavras não pularem na troca de fonte
  const fontsReady = document.fonts && document.fonts.ready
    ? Promise.race([document.fonts.ready, new Promise((resolve) => setTimeout(resolve, 800))])
    : Promise.resolve();

  fontsReady.then(start, start);
})();
