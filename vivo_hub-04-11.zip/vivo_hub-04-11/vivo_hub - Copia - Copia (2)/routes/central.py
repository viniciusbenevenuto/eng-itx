"""routes/central.py — Rotas das centrais (landing pages por role)."""
from flask import Blueprint, redirect, render_template, session, url_for

from auth import ROLE_HOME_ENDPOINTS, login_required, role_required
from db import get_db
from fluxo import consultas

bp = Blueprint("central", __name__)


def _painel(owner_id: int | None = None) -> dict:
    """Números reais do painel (todos do banco) e os últimos Pré-PTIs.

    owner_id restringe aos formulários do usuário (perfil Atacado).
    """
    db = get_db()
    where, params = ("WHERE owner_id = ?", (owner_id,)) if owner_id else ("", ())
    por_status = {
        row["st"]: row["n"]
        for row in db.execute(
            "SELECT LOWER(COALESCE(NULLIF(status, ''), 'rascunho')) AS st, COUNT(*) AS n "
            f"FROM atacado_forms {where} GROUP BY st",
            params,
        )
    }
    operadoras = db.execute(
        f"SELECT COUNT(DISTINCT nome_operadora) FROM atacado_forms {where}", params
    ).fetchone()[0]
    recentes = db.execute(
        "SELECT id, nome_operadora, version, status, rn1, updated_at, created_at "
        f"FROM atacado_forms {where} "
        "ORDER BY COALESCE(updated_at, created_at) DESC, id DESC LIMIT 5",
        params,
    ).fetchall()
    return {
        "total": sum(por_status.values()),
        "aprovados": por_status.get("aprovado", 0),
        "operadoras": operadoras,
        "rascunhos": por_status.get("rascunho", 0),
        "aguardando": por_status.get("enviado", 0) + por_status.get("em revisão", 0),
        "reprovados": por_status.get("reprovado", 0),
        "recentes": recentes,
        # Situação de cada recente, pela linha do tempo
        "resumos": consultas.resumo_processos(db, [r["id"] for r in recentes]),
    }


@bp.get("/")
@login_required
def index():
    home = ROLE_HOME_ENDPOINTS.get(session.get("role"))
    return redirect(url_for(home) if home else url_for("auth.login"))


@bp.get("/central_atacado")
@login_required
@role_required("atacado")
def central_atacado():
    return render_template("central_atacado.html", painel=_painel(session["user_id"]))


@bp.get("/central_engenharia")
@login_required
@role_required("engenharia")
def central_engenharia():
    return render_template("central_engenharia.html", painel=_painel())
