"""routes/processos.py — Linha do tempo, ações do fluxo, indicadores e alertas.

A tela da linha do tempo é a mesma para Engenharia e Atacado: o que muda é o
que cada um pode fazer (as regras ficam em fluxo/definicao.py e o serviço em
fluxo/servico.py; esta camada só lê o pedido e mostra o resultado).
"""
import logging

from flask import (
    Blueprint, abort, flash, jsonify, redirect, render_template, request, session, url_for,
)

from auth import login_required
from db import get_db
from fluxo import alertas, consultas, indicadores
from fluxo.definicao import ACOES, AREAS, EVENTOS, PRIORIDADES, TIPOS_BLOQUEIO, Ator, nome_area, nome_usuario
from fluxo.servico import ConflitoVersao, Fluxo, FluxoErro, transacao

logger = logging.getLogger(__name__)
bp = Blueprint("processos", __name__)


def ator_atual() -> Ator:
    """Quem está agindo: usuário da sessão e, se validou o código, administração."""
    return Ator(session.get("user_id"), session.get("email", ""), session.get("role"),
                bool(session.get("is_admin")))


def _dono_do_processo(db, form_id: int, form):
    if form:
        return form["owner_id"]
    ev = db.execute("SELECT usuario_resp_novo FROM pti_eventos WHERE form_id = ? AND tipo IN "
                    "('processo_criado', 'versao_criada') ORDER BY id LIMIT 1", (form_id,)).fetchone()
    return ev["usuario_resp_novo"] if ev else None


def _acesso(form_id: int):
    """Formulário e processo visíveis para o usuário (Atacado: só os próprios)."""
    db = get_db()
    form = db.execute("SELECT * FROM atacado_forms WHERE id = ?", (form_id,)).fetchone()
    proc = consultas.processo(db, form_id)
    if not proc and form:
        Fluxo(db, ator_atual()).processo(form_id)   # formulário sem processo: migra na hora
        proc = consultas.processo(db, form_id)
    if not proc:
        abort(404)
    if session.get("role") == "atacado" and not session.get("is_admin") \
            and _dono_do_processo(db, form_id, form) != session.get("user_id"):
        abort(404)
    return db, form, proc


def _form_ids_visiveis(db) -> set[int] | None:
    """Universo dos indicadores: Atacado vê só os próprios Pré-PTIs."""
    if session.get("role") == "atacado" and not session.get("is_admin"):
        return {r["id"] for r in db.execute("SELECT id FROM atacado_forms WHERE owner_id = ?", (session["user_id"],))}
    return None


# Ações exibidas na tela, por grupo, na ordem em que aparecem
GRUPOS_ACOES = (
    ("Decisão da etapa", ("enviar", "reenviar", "aprovar", "devolver", "enviar_operadora",
                          "registrar_resposta", "retomar_validacao")),
    ("Responsabilidade", ("assumir", "reatribuir")),
    ("Situação", ("pausar", "retomar", "bloquear", "desbloquear")),
    ("Registro", ("comentar", "pendencia_abrir", "prioridade")),
    ("Encerramento", ("cancelar", "reabrir_concluido", "reabrir_cancelado")),
)


def _acoes(db, form_id: int, proc) -> list[dict]:
    """Cada ação com (pode, explicação). Só entram as que fazem sentido na etapa
    atual; as indisponíveis aparecem com o motivo."""
    ator = ator_atual()
    fx = Fluxo(db, ator)
    grupos = []
    for titulo, chaves in GRUPOS_ACOES:
        itens = []
        for chave in chaves:
            a = ACOES[chave]
            if proc["etapa"] not in a.de:
                continue
            # Fora da lista (não são "indisponíveis", só não se aplicam agora):
            # pausar/retomar/bloquear/desbloquear fora da situação certa e
            # ações exclusivas da administração para quem não é administrador
            if chave in ("pausar", "retomar", "bloquear", "desbloquear") and proc["situacao"] not in a.situacoes:
                continue
            if a.executores == frozenset({"administracao"}) and not ator.admin:
                continue
            pode, explicacao = fx.pode(chave, form_id)
            itens.append({"chave": chave, "nome": a.nome, "pode": pode, "explicacao": explicacao,
                          "descricao": a.descricao, "motivo": a.motivo})
        if itens:
            grupos.append({"titulo": titulo, "itens": itens})
    return grupos


@bp.get("/processos/<int:form_id>")
@login_required
def processo(form_id: int):
    db, form, proc = _acesso(form_id)
    estado = consultas.estado(db, form_id, form)
    usuarios = db.execute("SELECT id, email, role FROM users ORDER BY email").fetchall()
    usuarios_nomes = {u["id"]: nome_usuario(u["email"]) for u in usuarios}
    papel = session.get("role")
    if papel == "engenharia":
        url_form = url_for("engenharia.form_view", form_id=form_id) if form else None
    else:
        url_form = url_for("atacado.form_edit", form_id=form_id) if form else None
    return render_template(
        "processo.html",
        form=form, estado=estado,
        linha=consultas.linha_do_tempo(db, form_id),
        historico=consultas.historico(db, form_id),
        # Abertas primeiro, depois as resolvidas (cada grupo por data de abertura)
        pendencias=sorted(consultas.pendencias(db, form_id),
                          key=lambda p: (p["resolvida_em"] is not None, p["aberta_em"])),
        tempos=consultas.tempos_por_responsabilidade(db, form_id),
        grupos_acoes=_acoes(db, form_id, proc),
        url_form=url_form,
        usuarios=usuarios, usuarios_nomes=usuarios_nomes,
        areas=[(k, v) for k, v in AREAS.items() if k not in ("nao_atribuida", "sistema")],
        areas_destino=[("engenharia", AREAS["engenharia"]), ("atacado", AREAS["atacado"])],
        tipos_bloqueio=list(TIPOS_BLOQUEIO.items()),
        prioridades=list(PRIORIDADES.items()),
        ator=ator_atual(),
    )


@bp.post("/processos/<int:form_id>/acao")
@login_required
def acao(form_id: int):
    db, form, proc = _acesso(form_id)
    chave = (request.form.get("acao") or "").strip()
    if chave not in ACOES and chave != "reabrir":
        abort(400)
    try:
        with transacao(db):
            Fluxo(db, ator_atual()).executar(chave, form_id, request.form)
    except ConflitoVersao as exc:
        flash(str(exc), "warning")
        return redirect(url_for("processos.processo", form_id=form_id))
    except FluxoErro as exc:
        flash(str(exc), "danger")
        return redirect(url_for("processos.processo", form_id=form_id) + "#acoes")
    estado = consultas.estado(db, form_id, form)
    evento = EVENTOS.get(ACOES[chave].evento if chave in ACOES else "reaberto", "Ação registrada")
    flash(f"{evento}. Situação atual: {estado['frase']}.", "success")
    session["_destaque_pti"] = form_id
    return redirect(url_for("processos.processo", form_id=form_id))


@bp.get("/api/processos/<int:form_id>")
@login_required
def api_processo(form_id: int):
    db, form, proc = _acesso(form_id)
    estado = consultas.estado(db, form_id, form)
    estado = {k: v for k, v in estado.items() if k not in ("etapa", "ultimo_evento")}
    estado["etapa"] = proc["etapa"]
    linha = [{k: v for k, v in i.items() if k not in ("comentarios",)} for i in consultas.linha_do_tempo(db, form_id)]
    return jsonify({
        "estado": estado,
        "linha_do_tempo": linha,
        "historico": consultas.historico(db, form_id),
        "pendencias": [dict(p) for p in consultas.pendencias(db, form_id)],
        "tempos": consultas.tempos_por_responsabilidade(db, form_id)["segundos"],
    })


# ---------------------------------------------------------------------------
# INDICADORES
# ---------------------------------------------------------------------------
@bp.get("/indicadores")
@login_required
def painel_indicadores():
    db = get_db()
    filtros = indicadores.normalizar_filtros(request.args)
    dados = indicadores.calcular(db, filtros, form_ids=_form_ids_visiveis(db))
    return render_template("indicadores.html", dados=dados, filtros=filtros, opcoes=indicadores.opcoes(db),
                           filtrado=any(filtros.values()))


@bp.get("/api/indicadores")
@login_required
def api_indicadores():
    db = get_db()
    filtros = indicadores.normalizar_filtros(request.args)
    return jsonify(indicadores.calcular(db, filtros, form_ids=_form_ids_visiveis(db)))


# ---------------------------------------------------------------------------
# ALERTAS
# ---------------------------------------------------------------------------
@bp.get("/alertas")
@login_required
def lista_alertas():
    db = get_db()
    somente = request.args.get("filtro") == "nao_lidos"
    itens = alertas.listar(db, session.get("user_id"), session.get("role"), bool(session.get("is_admin")),
                           somente_nao_lidos=somente)
    return render_template("alertas.html", itens=itens, somente_nao_lidos=somente)


@bp.post("/alertas/lidos")
@login_required
def marcar_alertas():
    db = get_db()
    ids = [int(i) for i in request.form.getlist("alerta_id") if i.isdigit()]
    with transacao(db):
        n = alertas.marcar_lidos(db, session["user_id"], session.get("role"), bool(session.get("is_admin")),
                                 ids or None)
    destino = request.form.get("abrir")
    if destino and destino.isdigit():
        return redirect(url_for("processos.processo", form_id=int(destino)))
    flash(f"{n} alerta(s) marcado(s) como lido(s)." if n else "Nenhum alerta para marcar.", "info")
    return redirect(url_for("processos.lista_alertas"))


@bp.app_context_processor
def contexto_fluxo():
    """Contagem de alertas não lidos na barra superior (e varredura de prazos)."""
    if not session.get("user_id"):
        return {"ALERTAS_NAO_LIDOS": 0, "nome_area": nome_area}
    try:
        db = get_db()
        alertas.varrer_se_preciso(db)
        n = alertas.nao_lidos(db, session.get("user_id"), session.get("role"), bool(session.get("is_admin")))
    except Exception:  # a barra superior nunca derruba a página
        logger.exception("Falha ao contar alertas")
        n = 0
    return {"ALERTAS_NAO_LIDOS": n, "nome_area": nome_area}
