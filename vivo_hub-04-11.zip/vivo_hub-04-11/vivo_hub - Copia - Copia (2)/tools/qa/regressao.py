"""Regressão: rotas e planilhas comparadas com o estado antes da repaginada.

1 Rotas: cada rota do inventário é chamada no código do branch "main" (antes)
  e no código atual, com a mesma cópia do banco; status e tipo de conteúdo
  precisam ser iguais. Só rotas de leitura e envios que não gravam nada.
2 Planilhas: o PTI de cada formulário do banco é gerado com o builder de antes
  e com o atual; todas as abas e células precisam ser idênticas. A Mask é
  esvaziada para não tentar reservar rede no phpIPAM real.

Uso: python tools/qa/regressao.py   (precisa do git e do branch main)
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from comum import FORM_ID, RAIZ

ROTAS = [
    # (perfil, método, caminho, dados)
    (None, "GET", "/login", None),
    (None, "GET", "/admin_login", None),
    (None, "GET", "/register", None),
    ("admin", "GET", "/register", None),
    (None, "GET", "/central_atacado", None),
    ("atacado", "GET", "/", None),
    ("atacado", "GET", "/central_atacado", None),
    ("atacado", "GET", "/central_engenharia", None),
    ("atacado", "GET", "/atacado_formularios", None),
    ("atacado", "GET", "/atacado_formularios?q=a&status=enviado", None),
    ("atacado", "GET", "/atacado_formularios/new", None),
    ("atacado", "GET", f"/atacado_formularios/{FORM_ID}", None),
    ("atacado", "GET", "/atacado_formularios/999999", None),
    ("engenharia", "GET", "/central_engenharia", None),
    ("engenharia", "GET", "/engenharia_formularios", None),
    ("engenharia", "GET", "/engenharia_formularios?status=aprovado", None),
    ("engenharia", "GET", f"/engenharia_formularios/{FORM_ID}", None),
    ("engenharia", "GET", "/excel_download", None),
    ("atacado", "GET", "/api/cns", None),
    ("atacado", "GET", "/api/operadoras", None),
    ("atacado", "GET", "/api/sbc/sugestoes?cn=11", None),
    ("atacado", "GET", "/api/sbc/sugestoes?cn=abc", None),
    ("atacado", "GET", "/api/siprouter/query?cn=11&rn1=55181", None),
    (None, "POST", "/login", {"email": "qa@exemplo.invalid", "password": "x"}),
    (None, "POST", "/admin_login", {"code": "codigo-errado"}),
]

SESSOES = {
    "atacado": {"user_id": 1, "role": "atacado", "email": "qa.atacado@vivohub.local"},
    "engenharia": {"user_id": 2, "role": "engenharia", "email": "qa.engenharia@vivohub.local"},
    "admin": {"is_admin": True},
}

SCRIPT = r"""
import json, sys
sys.path.insert(0, sys.argv[1])
from app import create_app
rotas = json.loads(sys.argv[2]); sessoes = json.loads(sys.argv[3])
app = create_app(); c = app.test_client(); out = []
for perfil, metodo, caminho, dados in rotas:
    with c.session_transaction() as s:
        s.clear()
        if perfil: s.update(sessoes[perfil])
    r = c.open(caminho, method=metodo, data=dados)
    out.append([r.status_code, r.content_type, r.headers.get("Location", "")])
print("@@" + json.dumps(out))
"""


# Ambiente dos dois lados: semente de hash fixa (o builder junta CNs a partir de
# um set, cuja ordem muda a cada execução) e, no código atual, a cópia do banco
# em VIVOHUB_DB (definida em main), para nada gravar no banco real
AMBIENTE = {**os.environ, "PYTHONIOENCODING": "utf-8", "PYTHONHASHSEED": "0"}


def rodar(raiz: Path) -> list:
    proc = subprocess.run(
        [sys.executable, "-c", SCRIPT, str(raiz), json.dumps(ROTAS), json.dumps(SESSOES)],
        capture_output=True, text=True, encoding="utf-8", cwd=raiz,
        env=AMBIENTE,
    )
    linha = next((l for l in proc.stdout.splitlines() if l.startswith("@@")), None)
    if not linha:
        raise RuntimeError(proc.stderr[-2000:])
    return json.loads(linha[2:])


def comparar_rotas(antes_dir: Path) -> int:
    antes, depois = rodar(antes_dir), rodar(RAIZ)
    falhas = 0
    for rota, a, d in zip(ROTAS, antes, depois):
        igual = a[0] == d[0] and a[1] == d[1] and a[2] == d[2]
        falhas += not igual
        print(f"{'ok   ' if igual else 'FALHA'} {rota[1]:<4} {rota[2]:<45} {rota[0] or 'anônimo':<11} antes={a[0]} {a[1]}  depois={d[0]} {d[1]}")
    return falhas


SCRIPT_PLANILHA = r"""
import json, sys
sys.path.insert(0, sys.argv[1])
from app import create_app
from db import get_db
from excel.builder import PTIWorkbookBuilder
app = create_app(); out = {}
with app.app_context():
    for row in get_db().execute("SELECT * FROM atacado_forms ORDER BY id").fetchall():
        d = dict(row)
        ops = json.loads(d.get("dados_operadora_json") or "[]")
        d["dados_operadora_json"] = json.dumps([{**o, "mask": ""} for o in ops])
        wb = PTIWorkbookBuilder(d).build()
        out[d["id"]] = {ws.title: [[str(c.value) if c.value is not None else None for c in r] for r in ws.iter_rows()] for ws in wb.worksheets}
print("@@" + json.dumps(out))
"""


def planilhas(raiz: Path) -> dict:
    proc = subprocess.run([sys.executable, "-c", SCRIPT_PLANILHA, str(raiz)], capture_output=True,
                          text=True, encoding="utf-8", cwd=raiz, env=AMBIENTE)
    linha = next((l for l in proc.stdout.splitlines() if l.startswith("@@")), None)
    if not linha:
        raise RuntimeError(proc.stderr[-2000:])
    return json.loads(linha[2:])


def comparar_planilhas(antes_dir: Path) -> int:
    antes, depois = planilhas(antes_dir), planilhas(RAIZ)
    falhas = 0
    for form_id in sorted(set(antes) | set(depois), key=int):
        a, d = antes.get(form_id), depois.get(form_id)
        igual = a == d
        falhas += not igual
        celulas = sum(len(r) for aba in (d or {}).values() for r in aba)
        print(f"{'ok   ' if igual else 'FALHA'} PTI #{form_id}: {len(d or {})} abas, {celulas} células {'idênticas' if igual else 'DIFERENTES'}")
    return falhas


def main() -> int:
    tmp = Path(tempfile.mkdtemp(prefix="pti_antes_"))
    antes_dir = tmp / "main"
    subprocess.run(["git", "worktree", "add", "--detach", str(antes_dir), "main"], cwd=RAIZ,
                   check=True, capture_output=True)
    try:
        # Mesma cópia do banco nos dois lados (o banco real não é alterado)
        for lado in (antes_dir,):
            (lado / "instance").mkdir(exist_ok=True)
            shutil.copy2(RAIZ / "instance" / "vivohub.db", lado / "instance" / "vivohub.db")
        # Código atual: cópia em VIVOHUB_DB (a linha do tempo grava alertas ao abrir telas)
        shutil.copy2(RAIZ / "instance" / "vivohub.db", tmp / "depois.db")
        AMBIENTE["VIVOHUB_DB"] = str(tmp / "depois.db")
        print("== Rotas (status, tipo de conteúdo e redirecionamento)")
        f_rotas = comparar_rotas(antes_dir)
        print("\n== Planilhas do PTI (todas as abas e células)")
        f_planilhas = comparar_planilhas(antes_dir)
    finally:
        subprocess.run(["git", "worktree", "remove", "--force", str(antes_dir)], cwd=RAIZ, capture_output=True)
        shutil.rmtree(tmp, ignore_errors=True)
    print(f"\nFalhas: rotas={f_rotas} planilhas={f_planilhas}")
    return 1 if (f_rotas or f_planilhas) else 0


if __name__ == "__main__":
    sys.exit(main())
