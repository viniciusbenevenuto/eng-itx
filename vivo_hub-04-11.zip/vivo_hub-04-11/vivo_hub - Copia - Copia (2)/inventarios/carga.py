"""Carga dos inventários a partir das planilhas em data/inventarios/.

Fluxo de cada carga:
  1. acha a aba e a linha de cabeçalho; confere as colunas;
  2. confere todas as linhas (obrigatórios, formatos, repetidos);
  3. com erro: nada muda (vale a carga anterior) e o motivo fica registrado;
     sem erro: troca a base inteira de uma vez e registra a carga.

O mesmo arquivo (mesmo hash) não é lido duas vezes; trocar o arquivo na pasta
basta para atualizar. Mensagens e relatórios nunca mostram valores das
planilhas, só aba, linha, coluna e contagens.
"""
from __future__ import annotations

import hashlib
import logging
import os
import sqlite3
import time
from pathlib import Path

from fluxo.tempo import agora, gravar
from inventarios import faixas
from inventarios.bases import BASES, ORDEM, Base, valor
from inventarios.planilha import achar_cabecalho, cabecalhos_encontrados, ler_abas, normalizar_cabecalho, texto

logger = logging.getLogger(__name__)

EXTENSOES = (".xlsx", ".xlsm")
MAX_MENSAGENS = 30
ESTAVEL_S = 10          # arquivo modificado há menos tempo pode estar sendo copiado


def arquivo_da_base(pasta, base: Base) -> Path | None:
    for ext in EXTENSOES:
        p = Path(pasta) / f"{base.arquivo}{ext}"
        if p.is_file():
            return p
    return None


def hash_arquivo(caminho) -> str:
    h = hashlib.sha256()
    with open(caminho, "rb") as f:
        for bloco in iter(lambda: f.read(1 << 20), b""):
            h.update(bloco)
    return h.hexdigest()


def _limitar(mensagens: list[str]) -> list[str]:
    if len(mensagens) <= MAX_MENSAGENS:
        return mensagens
    return mensagens[:MAX_MENSAGENS] + [f"… e mais {len(mensagens) - MAX_MENSAGENS} ocorrência(s)"]


def analisar(chave: str, caminho) -> dict:
    """Lê e confere a planilha sem gravar nada.

    {"registros": [...], "erros": [...], "avisos": [...], "estrutura": {...}}
    """
    base = BASES[chave]
    try:
        abas = ler_abas(caminho)
    except Exception as exc:  # arquivo corrompido, protegido ou ainda sendo copiado
        return {"registros": [], "erros": [f"não foi possível abrir o arquivo ({exc.__class__.__name__})"],
                "avisos": [], "estrutura": {}}

    if chave == "livres":
        ultimo = None
        for nome, linhas in abas:
            registros, erros, estrutura = faixas.ler(linhas)
            if estrutura:
                estrutura["aba"] = nome
                return {"registros": registros, "erros": _limitar(erros), "avisos": [], "estrutura": estrutura}
            ultimo = erros
        return {"registros": [], "erros": ultimo or ["planilha vazia"], "avisos": [], "estrutura": {}}

    obrigatorios = [c.cabecalho for c in base.colunas]
    for nome, linhas in abas:
        achado = achar_cabecalho(linhas, obrigatorios)
        if achado:
            break
    else:
        nomes_ok = {normalizar_cabecalho(c) for c in obrigatorios}
        encontrados = cabecalhos_encontrados(abas[0][1]) if abas else []
        faltando = sorted(c.cabecalho for c in base.colunas
                          if normalizar_cabecalho(c.cabecalho) not in {normalizar_cabecalho(e) for e in encontrados})
        return {"registros": [], "avisos": [], "estrutura": {"abas": [a for a, _ in abas]},
                "erros": [f"não achei as colunas: {', '.join(faltando) or ', '.join(sorted(nomes_ok))}. "
                          f"Colunas encontradas: {', '.join(encontrados) or 'nenhuma'}"]}

    indice_cab, mapa = achado
    posicao = {c.campo: mapa[normalizar_cabecalho(c.cabecalho)] for c in base.colunas}
    registros, erros, avisos, vazias = [], [], [], 0
    vistos: dict[tuple, int] = {}
    for i in range(indice_cab + 1, len(linhas)):
        linha = linhas[i]
        brutos = {c.campo: (linha[posicao[c.campo]] if posicao[c.campo] < len(linha) else None) for c in base.colunas}
        if not any(texto(v) for v in brutos.values()):
            vazias += 1
            continue
        registro, problemas = {}, False
        for c in base.colunas:
            v, erro = valor(c, brutos[c.campo])
            if erro and c.preenchida:
                erros.append(f"linha {i + 1}, coluna {c.cabecalho}: {erro}")
                problemas = True
            elif erro:
                avisos.append(f"linha {i + 1}, coluna {c.cabecalho}: {erro} (guardado como está)")
                v = texto(brutos[c.campo]) or None
            registro[c.campo] = v
        if problemas:
            continue
        if base.unica:
            chave_unica = tuple(registro[c] for c in base.unica)
            if chave_unica in vistos:
                nomes = ", ".join(next(c.cabecalho for c in base.colunas if c.campo == u) for u in base.unica)
                erros.append(f"linhas {vistos[chave_unica]} e {i + 1}: {nomes} repetido")
                continue
            vistos[chave_unica] = i + 1
        registros.append(registro)
    estrutura = {"aba": nome, "linha_cabecalho": indice_cab + 1,
                 "colunas": [c.cabecalho for c in base.colunas], "linhas_em_branco": vazias}
    if not registros and not erros:
        erros.append("nenhuma linha de dados abaixo do cabeçalho")
    return {"registros": registros, "erros": _limitar(erros), "avisos": _limitar(avisos), "estrutura": estrutura}


def _registrar(db, chave, caminho, hash_, situacao, linhas, mensagens, autor) -> None:
    db.execute(
        "INSERT INTO inv_cargas (base, arquivo, hash, situacao, linhas, mensagem, carregado_em, carregado_por) "
        "VALUES (?,?,?,?,?,?,?,?)",
        (chave, Path(caminho).name, hash_, situacao, linhas, "\n".join(mensagens) or None, gravar(agora()), autor))


def carregar(db: sqlite3.Connection, chave: str, caminho, autor: str = "sistema", hash_: str | None = None) -> dict:
    """Confere e, sem erros, troca a base inteira (uma transação). Faz commit."""
    base = BASES[chave]
    hash_ = hash_ or hash_arquivo(caminho)
    r = analisar(chave, caminho)
    if not db.in_transaction:
        db.execute("BEGIN IMMEDIATE")
    try:
        if r["erros"]:
            _registrar(db, chave, caminho, hash_, "erro", 0, r["erros"], autor)
        else:
            db.execute(f"DELETE FROM {base.tabela}")
            if chave == "livres":
                campos = ["tipo", "cn", "inicio", "fim", "prioridade", "uso", "observacao"]
            else:
                campos = [c.campo for c in base.colunas]
            db.executemany(
                f"INSERT INTO {base.tabela} ({','.join(campos)}) VALUES ({','.join('?' * len(campos))})",
                [[reg[c] for c in campos] for reg in r["registros"]])
            _registrar(db, chave, caminho, hash_, "ok", len(r["registros"]), r["avisos"], autor)
        db.commit()
    except Exception:
        db.rollback()
        raise
    r["ok"] = not r["erros"]
    r["linhas"] = len(r["registros"]) if r["ok"] else 0
    r["base"], r["arquivo"] = chave, Path(caminho).name
    nivel = logging.INFO if r["ok"] else logging.WARNING
    logger.log(nivel, "Inventário %s (%s): %s", base.nome, Path(caminho).name,
               f"{r['linhas']} linhas carregadas" if r["ok"] else f"não carregado, {len(r['erros'])} erro(s)")
    return r


def ultima_carga(db: sqlite3.Connection, chave: str):
    return db.execute("SELECT * FROM inv_cargas WHERE base = ? ORDER BY id DESC LIMIT 1", (chave,)).fetchone()


def ultima_carga_ok(db: sqlite3.Connection, chave: str):
    return db.execute("SELECT * FROM inv_cargas WHERE base = ? AND situacao = 'ok' ORDER BY id DESC LIMIT 1",
                      (chave,)).fetchone()


def carregar_alterados(db: sqlite3.Connection, pasta, autor: str = "sistema") -> list[dict]:
    """Carrega os arquivos novos ou trocados na pasta (o mesmo arquivo não é relido)."""
    resultados = []
    for chave in ORDEM:
        caminho = arquivo_da_base(pasta, BASES[chave])
        if not caminho:
            continue
        if time.time() - os.path.getmtime(caminho) < ESTAVEL_S:
            continue  # ainda pode estar sendo copiado; fica para a próxima verificação
        hash_ = hash_arquivo(caminho)
        anterior = ultima_carga(db, chave)
        if anterior and anterior["hash"] == hash_:
            continue
        resultados.append(carregar(db, chave, caminho, autor, hash_))
    return resultados


def relatorio(db: sqlite3.Connection, pasta) -> list[dict]:
    """Situação de cada base para o comando de conferência (sem valores)."""
    saida = []
    for chave in ORDEM:
        base = BASES[chave]
        caminho = arquivo_da_base(pasta, base)
        item = {"base": chave, "nome": base.nome, "arquivo_esperado": f"{base.arquivo}.xlsx",
                "presente": bool(caminho), "ultima": ultima_carga(db, chave), "ultima_ok": ultima_carga_ok(db, chave)}
        if caminho:
            r = analisar(chave, caminho)
            item.update(estrutura=r["estrutura"], erros=r["erros"], avisos=r["avisos"], linhas=len(r["registros"]))
        saida.append(item)
    return saida
