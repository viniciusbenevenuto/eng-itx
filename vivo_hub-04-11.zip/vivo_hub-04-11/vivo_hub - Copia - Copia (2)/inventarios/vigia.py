"""Verificação periódica da pasta dos inventários (linha de execução em segundo plano).

Ao iniciar o sistema e a cada INVENTARIOS_VERIFICAR_MIN minutos (padrão 5),
carrega as planilhas novas ou trocadas em data/inventarios/. Desligue com
INVENTARIOS_VIGIA=0 (ficam os comandos flask inventario-*).
"""
from __future__ import annotations

import logging
import os
import threading
import time

from flask import Flask

from inventarios.carga import carregar_alterados

logger = logging.getLogger(__name__)
_iniciado = False


def verificar_agora(app: Flask) -> list[dict]:
    from db import get_db
    with app.app_context():
        return carregar_alterados(get_db(), app.config["INVENTARIOS_DIR"])


def iniciar(app: Flask) -> None:
    global _iniciado
    if _iniciado or os.environ.get("INVENTARIOS_VIGIA", "1") == "0":
        return
    _iniciado = True
    intervalo = max(1, int(os.environ.get("INVENTARIOS_VERIFICAR_MIN", "5") or 5)) * 60

    def laco() -> None:
        time.sleep(5)   # deixa a aplicação terminar de subir
        while True:
            try:
                verificar_agora(app)
            except Exception:  # a verificação nunca derruba a aplicação
                logger.exception("Falha ao verificar a pasta dos inventários")
            time.sleep(intervalo)

    threading.Thread(target=laco, name="inventarios", daemon=True).start()
    logger.info("Inventários: verificando %s a cada %d min.", app.config["INVENTARIOS_DIR"], intervalo // 60)
