"""Faixas livres de SAS resumido e ROTNGIN (planilha livres_sas_resumido_rotngin).

Formato da planilha (uma coluna por CN e uma para ROTNGIN):

    cn      11       12      ...   15      ...   ROTNGIN cn 11 ao 19
            D00478   D02204        C50B          C8791573
            D00479   D02205        C51B          C8791574
            até      até           ...           até
            D00999   D02299        depois de acabar os números acima
                                   ...
                     15  D05000  D05499  usar apenas para CSP15 do cn 15

  - código solto: código livre avulso;
  - "até" entre dois códigos: faixa do código de cima ao de baixo;
  - "depois de acabar os números acima": o que vem abaixo só é usado depois;
  - linha "<CN> <início> <fim> <texto>": faixa especial daquele CN, com o uso
    descrito no texto (CSP15; LC e CNG).

Livre = códigos das faixas que ainda não estão em uso (inv_sas_resumido para
SAS resumido, inv_rotngin para ROTNGIN), na ordem de prioridade.
"""
from __future__ import annotations

import re
import sqlite3
from typing import Iterator

from inventarios.planilha import normalizar_cabecalho, texto

CODIGO = re.compile(r"^([A-Z]+)(\d+)([A-Z]?)$")


def _codigo(v: str) -> re.Match | None:
    return CODIGO.match(v.strip().upper()) if v else None


def _uso(observacao: str) -> str | None:
    t = normalizar_cabecalho(observacao)
    if "CSP15" in t.replace(" ", ""):
        return "csp15"
    if "LC" in t.split() and "CNG" in t.split():
        return "lc_cng"
    return None


def validar_faixa(inicio: str, fim: str) -> str | None:
    """Erro da faixa (sem mostrar os códigos), ou None se válida."""
    a, b = _codigo(inicio), _codigo(fim)
    if not a or not b:
        return "faixa com código fora do padrão"
    if a.group(3) or b.group(3):
        return "faixa com código terminado em letra (liste esses códigos um a um)"
    if a.group(1) != b.group(1) or len(a.group(2)) != len(b.group(2)):
        return "início e fim da faixa com prefixos ou tamanhos diferentes"
    if int(a.group(2)) > int(b.group(2)):
        return "faixa invertida (fim menor que o início)"
    return None


def ler(linhas: list[tuple]) -> tuple[list[dict], list[str], dict]:
    """Planilha → (faixas para inv_faixas_codigos, erros, estrutura).

    Erros e estrutura não contêm códigos, só posição (linha/coluna)."""
    erros: list[str] = []
    cab = None
    for i, linha in enumerate(linhas[:30]):
        if linha and normalizar_cabecalho(linha[0]) == "CN":
            cab = i
            break
    if cab is None:
        return [], ["não achei a linha de cabeçalho (primeira célula \"cn\" seguida dos CNs)"], {}

    colunas: dict[int, tuple[str, str | None]] = {}
    for j, celula in enumerate(linhas[cab]):
        t = texto(celula)
        if t.isdigit() and len(t) == 2:
            colunas[j] = ("sas_resumido", t)
        elif "ROTNGIN" in normalizar_cabecalho(t):
            colunas[j] = ("rotngin", None)
    estrutura = {"linha_cabecalho": cab + 1,
                 "colunas": [f"CN {cn}" if cn else "ROTNGIN" for _, (_, cn) in sorted(colunas.items())]}
    if not colunas:
        return [], ["a linha de cabeçalho não tem colunas de CN nem de ROTNGIN"], estrutura

    # Linhas de faixa especial: "<CN> <início> <fim> <texto>" a partir da coluna do CN
    especiais: set[int] = set()
    faixas: list[dict] = []
    for i in range(cab + 1, len(linhas)):
        linha = linhas[i]
        for j, (tipo, cn) in colunas.items():
            if tipo != "sas_resumido" or j + 2 >= len(linha) or texto(linha[j]) != cn:
                continue
            inicio, fim = texto(linha[j + 1]).upper(), texto(linha[j + 2]).upper()
            if not (_codigo(inicio) and _codigo(fim)):
                continue
            obs = texto(linha[j + 3]) if j + 3 < len(linha) else ""
            erro = validar_faixa(inicio, fim)
            if erro:
                erros.append(f"linha {i + 1}, faixa especial do CN {cn}: {erro}")
            faixas.append({"tipo": tipo, "cn": cn, "inicio": inicio, "fim": fim, "prioridade": 1,
                           "uso": _uso(obs), "observacao": obs or None})
            especiais.add(i)

    # Cada coluna, de cima para baixo
    for j, (tipo, cn) in sorted(colunas.items()):
        nome_col = f"CN {cn}" if cn else "ROTNGIN"
        prioridade, anterior, ate = 1, None, False
        for i in range(cab + 1, len(linhas)):
            if i in especiais or j >= len(linhas[i]):
                continue
            v = texto(linhas[i][j])
            if not v:
                continue
            norm = normalizar_cabecalho(v)
            if norm in ("ATE", "ATE:"):
                if not anterior:
                    erros.append(f"linha {i + 1}, coluna {nome_col}: \"até\" sem código acima")
                ate = True
                continue
            if "DEPOIS DE ACABAR" in norm:
                prioridade, anterior, ate = prioridade + 1, None, False
                continue
            if not _codigo(v):
                continue  # anotação (ex.: "spo")
            codigo = v.strip().upper()
            if ate and anterior:
                erro = validar_faixa(anterior, codigo)
                if erro:
                    erros.append(f"linha {i + 1}, coluna {nome_col}: {erro}")
                else:
                    faixas.append({"tipo": tipo, "cn": cn, "inicio": anterior, "fim": codigo,
                                   "prioridade": prioridade, "uso": None, "observacao": None})
            else:
                faixas.append({"tipo": tipo, "cn": cn, "inicio": codigo, "fim": None,
                               "prioridade": prioridade, "uso": None, "observacao": None})
            anterior, ate = codigo, False
        if ate:
            erros.append(f"coluna {nome_col}: \"até\" sem código abaixo")
    estrutura["faixas"] = len(faixas)
    return faixas, erros, estrutura


def codigos(inicio: str, fim: str | None) -> Iterator[str]:
    """Códigos de uma faixa (ou o código avulso)."""
    if not fim:
        yield inicio
        return
    a, b = _codigo(inicio), _codigo(fim)
    prefixo, largura = a.group(1), len(a.group(2))
    for n in range(int(a.group(2)), int(b.group(2)) + 1):
        yield f"{prefixo}{n:0{largura}d}"


def livres(db: sqlite3.Connection, tipo: str, cn: str | None = None, uso: str | None = None,
           limite: int | None = None) -> list[str]:
    """Próximos códigos livres, na ordem de uso (prioridade, ordem da planilha).

    SAS resumido: faixas do CN, sem os labels em uso naquele CN.
    ROTNGIN: faixas gerais (e do CN, se houver), sem os ROTNGIN em uso.
    uso: None = faixas gerais; "csp15" / "lc_cng" = faixas especiais.
    """
    if tipo == "sas_resumido":
        faixas = db.execute(
            "SELECT inicio, fim FROM inv_faixas_codigos WHERE tipo = ? AND cn = ? AND uso IS ? "
            "ORDER BY prioridade, id", (tipo, cn, uso)).fetchall()
        em_uso = {r[0] for r in db.execute("SELECT label FROM inv_sas_resumido WHERE cn = ?", (cn,))}
    else:
        faixas = db.execute(
            "SELECT inicio, fim FROM inv_faixas_codigos WHERE tipo = ? AND (cn IS NULL OR cn = ?) AND uso IS ? "
            "ORDER BY prioridade, id", (tipo, cn, uso)).fetchall()
        em_uso = {r[0] for r in db.execute("SELECT rotngin FROM inv_rotngin")}
    saida: list[str] = []
    vistos: set[str] = set()
    for inicio, fim in faixas:
        for c in codigos(inicio, fim):
            if c in vistos or c in em_uso:
                continue
            vistos.add(c)
            saida.append(c)
            if limite and len(saida) >= limite:
                return saida
    return saida
