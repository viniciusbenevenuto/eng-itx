"""Inventários usados para gerar o PTI e os documentos de configuração.

Cada inventário vem de uma planilha Excel mantida pelas equipes e fica numa
tabela própria com prefixo inv_ (esquema.py):

  inv_operadoras_csp   operadoras com CSP (RN1 → nome fantasia e CSP)
  inv_al_anatel        áreas locais da Anatel (localidade → CNL, área local, CN)
  inv_rn1              repositório de RN1 (IDP, nome, tipo, CSP, ECR, RN1...)
  inv_rotngin          ROTNGIN em uso na fixa (ASITX VIVO1 região 3)
  inv_sas_resumido     labels de SAS resumido em uso, por CN
  inv_faixas_codigos   faixas de onde saem os novos labels SAS e ROTNGIN
  inv_cargas           registro de cada carga (base, arquivo, linhas, quando, quem)

Os códigos livres não são uma tabela: livre = faixa definida em
inv_faixas_codigos menos o que já está em uso em inv_sas_resumido e
inv_rotngin. Assim, um código alocado deixa de estar livre na hora, sem
manter duas listas em sincronia.
"""
