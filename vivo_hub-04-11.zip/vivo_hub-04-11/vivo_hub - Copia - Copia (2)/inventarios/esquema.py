"""Tabelas dos inventários (criadas por db.init_db).

Códigos (RN1, CSP, CN, CNL, labels, ROTNGIN) são TEXT: preservam zeros à
esquerda ("05") e letras ("C8790000", "D00478"). Cada código que identifica
um registro tem UNIQUE, para a carga não duplicar linhas.
"""
from __future__ import annotations

import logging
import sqlite3

logger = logging.getLogger(__name__)

ESQUEMA_SQL = """
-- Operadoras com CSP: RN1 → nome fantasia e CSP
CREATE TABLE IF NOT EXISTS inv_operadoras_csp (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    rn1            TEXT NOT NULL UNIQUE,
    nome_fantasia  TEXT NOT NULL,
    csp            TEXT NOT NULL
);

-- Áreas locais da Anatel: localidade → sigla e código CNL, área local e CN
CREATE TABLE IF NOT EXISTS inv_al_anatel (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    sigla_al    TEXT NOT NULL,
    area_local  TEXT NOT NULL,
    localidade  TEXT NOT NULL,
    sigla_cnl   TEXT NOT NULL,
    cod_cnl     TEXT NOT NULL UNIQUE,
    cn          TEXT NOT NULL
);

-- Repositório de RN1 (pode haver mais de uma linha por IDP ao longo do tempo)
CREATE TABLE IF NOT EXISTS inv_rn1 (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    data_modificacao  TEXT,      -- aaaa-mm-dd
    idp               TEXT NOT NULL,
    nome              TEXT,      -- NOM
    tipo              TEXT,      -- TTE (FIXO, MOVEL, FIXO2...)
    rn1_yy            TEXT,      -- RN1 (YY) (CSP SAS)
    acao              TEXT,      -- AÇÃO (TIPO DE MODIFICAÇÃO)
    csp_operadora     TEXT,      -- CSP (OPERADORA)
    ecr               TEXT,
    rn1               TEXT,
    resp              TEXT,
    existe_anexo5     TEXT       -- existe anexo 5?
);

-- ROTNGIN em uso na fixa (inventário rotngin_fixa_asitx_vivo1_reg3)
CREATE TABLE IF NOT EXISTS inv_rotngin (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    operadora   TEXT NOT NULL,
    cn          TEXT NOT NULL,
    localidade  TEXT NOT NULL,
    tipo_rota   TEXT NOT NULL,   -- LC + TR LC, LD15...
    rotngin     TEXT NOT NULL UNIQUE,
    rn1         TEXT NOT NULL
);

-- Labels de SAS resumido em uso (um label pertence a um CN)
CREATE TABLE IF NOT EXISTS inv_sas_resumido (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    cn         TEXT NOT NULL,
    operadora  TEXT NOT NULL,
    label      TEXT NOT NULL,    -- LABEL (SAS)
    rota       TEXT NOT NULL,    -- LC, LD15, LD24...
    rn1        TEXT NOT NULL,
    UNIQUE (cn, label)
);

-- Faixas para novas alocações (planilha livres_sas_resumido_rotngin).
-- Uma linha por faixa (inicio..fim) ou por código avulso (fim vazio).
-- Livre = códigos da faixa que não estão em uso (inv_sas_resumido / inv_rotngin).
CREATE TABLE IF NOT EXISTS inv_faixas_codigos (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    tipo        TEXT NOT NULL CHECK (tipo IN ('sas_resumido', 'rotngin')),
    cn          TEXT,            -- vazio: vale para toda a faixa de CN (ROTNGIN cn 11 a 19)
    inicio      TEXT NOT NULL,   -- D00478, C48E, C8791573...
    fim         TEXT,            -- D00999; vazio = código avulso
    prioridade  INTEGER NOT NULL DEFAULT 1,  -- 1 primeiro; 2 "depois de acabar os números acima"
    uso         TEXT,            -- vazio = qualquer rota; csp15; lc_cng
    observacao  TEXT
);

-- Cada tentativa de carga: de onde veio, quantas linhas, quando, quem e se
-- deu certo. O hash identifica o arquivo: o mesmo arquivo não é lido de novo.
CREATE TABLE IF NOT EXISTS inv_cargas (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    base          TEXT NOT NULL,
    arquivo       TEXT,
    hash          TEXT,
    situacao      TEXT NOT NULL DEFAULT 'ok' CHECK (situacao IN ('ok', 'erro')),
    linhas        INTEGER NOT NULL DEFAULT 0,
    mensagem      TEXT,          -- erros (só linha e coluna, nunca valores)
    carregado_em  TEXT NOT NULL,
    carregado_por TEXT
);

CREATE INDEX IF NOT EXISTS ix_inv_al_anatel_cn ON inv_al_anatel (cn);
CREATE INDEX IF NOT EXISTS ix_inv_al_anatel_sigla ON inv_al_anatel (sigla_cnl);
CREATE INDEX IF NOT EXISTS ix_inv_rn1_rn1 ON inv_rn1 (rn1);
CREATE INDEX IF NOT EXISTS ix_inv_rn1_idp ON inv_rn1 (idp);
CREATE INDEX IF NOT EXISTS ix_inv_rotngin_rn1_cn ON inv_rotngin (rn1, cn);
CREATE INDEX IF NOT EXISTS ix_inv_sas_cn_rn1 ON inv_sas_resumido (cn, rn1);
CREATE INDEX IF NOT EXISTS ix_inv_faixas_tipo_cn ON inv_faixas_codigos (tipo, cn, prioridade);
CREATE INDEX IF NOT EXISTS ix_inv_cargas_base ON inv_cargas (base, carregado_em);
"""

# Primeira versão das tabelas (criada direto no db.py, sem dados). Substituídas
# pelas inv_* acima; removidas só se estiverem vazias.
TABELAS_ANTIGAS: tuple[str, ...] = (
    "operadoras_com_csp", "al_anatel", "rn1", "rotngin_fixa_asitx_vivo1_reg3",
    "sas_resumido_em_uso_zz", "livres_sas_resumido_rotngin",
)


def criar_esquema(db: sqlite3.Connection) -> None:
    db.executescript(ESQUEMA_SQL)
    # inv_cargas criada antes das colunas de controle da carga automática
    existentes = {r[1] for r in db.execute("PRAGMA table_info(inv_cargas)")}
    for coluna, definicao in (("hash", "TEXT"), ("situacao", "TEXT NOT NULL DEFAULT 'ok'"), ("mensagem", "TEXT")):
        if coluna not in existentes:
            db.execute(f"ALTER TABLE inv_cargas ADD COLUMN {coluna} {definicao}")
    _remover_tabelas_antigas(db)


def _remover_tabelas_antigas(db: sqlite3.Connection) -> None:
    existentes = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
    for tabela in TABELAS_ANTIGAS:
        if tabela not in existentes:
            continue
        linhas = db.execute(f"SELECT COUNT(*) FROM {tabela}").fetchone()[0]
        if linhas:
            logger.warning("Inventários: tabela antiga %s mantida (%d linhas); os dados devem ir para a "
                           "tabela inv_ correspondente.", tabela, linhas)
            continue
        db.execute(f"DROP TABLE {tabela}")
        logger.info("Inventários: tabela antiga vazia %s removida (substituída pela inv_ correspondente).", tabela)
