"""Definição de cada inventário: arquivo, tabela, colunas e regras de validação.

Os nomes de cabeçalho são os das planilhas das equipes. Para incluir uma
coluna nova, acrescente uma Coluna aqui e o campo em esquema.py.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from inventarios.planilha import data_br, texto


@dataclass(frozen=True)
class Coluna:
    campo: str                 # coluna na tabela inv_*
    cabecalho: str             # nome na planilha
    tipo: str = "texto"        # texto | rn1 | cn | csp | csp_livre | codigo | data
    preenchida: bool = True    # valor obrigatório em toda linha


@dataclass(frozen=True)
class Base:
    chave: str
    nome: str
    arquivo: str               # nome do arquivo em data/inventarios/ (sem extensão)
    tabela: str
    colunas: tuple[Coluna, ...] = field(default_factory=tuple)
    unica: tuple[str, ...] = ()   # campos que não podem se repetir na planilha


BASES: dict[str, Base] = {b.chave: b for b in (
    Base("operadoras_csp", "Operadoras com CSP", "operadoras_com_csp", "inv_operadoras_csp", (
        Coluna("rn1", "RN1", "rn1"),
        Coluna("nome_fantasia", "Nome Fantasia"),
        Coluna("csp", "CSP", "csp"),
    ), unica=("rn1",)),
    Base("al_anatel", "Áreas locais Anatel", "al_anatel", "inv_al_anatel", (
        Coluna("sigla_al", "SIGLA_AL"),
        Coluna("area_local", "AREA_LOCAL"),
        Coluna("localidade", "LOCALIDADE"),
        Coluna("sigla_cnl", "SIGLA_CNL"),
        Coluna("cod_cnl", "COD_CNL", "codigo"),
        Coluna("cn", "CN", "cn"),
    ), unica=("cod_cnl",)),
    Base("rn1", "Repositório de RN1", "rn1", "inv_rn1", (
        Coluna("data_modificacao", "DATA MODIFICAÇÃO", "data", preenchida=False),
        Coluna("idp", "IDP"),
        Coluna("nome", "NOM", preenchida=False),
        Coluna("tipo", "TTE", preenchida=False),
        Coluna("rn1_yy", "RN1 (YY) (CSP SAS)", "csp_livre", preenchida=False),
        Coluna("acao", "AÇÃO (TIPO DE MODIFICAÇÃO)", preenchida=False),
        Coluna("csp_operadora", "CSP (OPERADORA)", preenchida=False),
        Coluna("ecr", "ECR", preenchida=False),
        Coluna("rn1", "RN1", "rn1", preenchida=False),
        Coluna("resp", "RESP", preenchida=False),
        Coluna("existe_anexo5", "existe anexo 5?", preenchida=False),
    )),
    Base("rotngin", "ROTNGIN em uso (fixa ASITX VIVO1 reg. 3)", "rotngin_fixa_asitx_vivo1_reg3", "inv_rotngin", (
        Coluna("operadora", "OPERADORA"),
        Coluna("cn", "CN", "cn"),
        Coluna("localidade", "LOCALIDADE"),
        Coluna("tipo_rota", "TIPO DE ROTA"),
        Coluna("rotngin", "ROTNGIN", "codigo"),
        Coluna("rn1", "rn1", "rn1"),
    ), unica=("rotngin",)),
    Base("sas_resumido", "SAS resumido em uso", "sas_resumido_em_uso", "inv_sas_resumido", (
        Coluna("cn", "CN", "cn"),
        Coluna("operadora", "OPERADORA"),
        Coluna("label", "LABEL (SAS)", "codigo"),
        Coluna("rota", "ROTA"),
        Coluna("rn1", "rn1", "rn1"),
    ), unica=("cn", "label")),
    # Planilha em colunas por CN, com "até" e faixas especiais: leitor próprio (faixas.py)
    Base("livres", "Faixas livres de SAS resumido e ROTNGIN", "livres_sas_resumido_rotngin", "inv_faixas_codigos"),
)}

# Ordem de carga e de exibição
ORDEM: tuple[str, ...] = ("operadoras_csp", "al_anatel", "rn1", "rotngin", "sas_resumido", "livres")


def valor(coluna: Coluna, bruto) -> tuple[str | None, str | None]:
    """(valor normalizado, erro). O erro nunca contém o valor da célula."""
    if coluna.tipo == "data":
        t = texto(bruto)
        if not t:
            return None, ("vazia" if coluna.preenchida else None)
        convertido = data_br(bruto)
        return (convertido, None) if convertido else (None, "data inválida (use dia/mês/ano)")
    t = texto(bruto)
    if not t:
        return None, ("vazia" if coluna.preenchida else None)
    if coluna.tipo == "rn1":
        return (t, None) if t.isdigit() and len(t) == 5 else (None, "RN1 deve ter 5 dígitos")
    if coluna.tipo == "cn":
        return (t, None) if t.isdigit() and len(t) == 2 else (None, "CN deve ter 2 dígitos")
    if coluna.tipo == "csp":
        return (t.zfill(2), None) if t.isdigit() and len(t) <= 2 else (None, "CSP deve ter até 2 dígitos")
    if coluna.tipo == "csp_livre":
        return (t.zfill(2) if t.isdigit() and len(t) <= 2 else t), None
    if coluna.tipo == "codigo":
        return t.upper(), None
    return t, None
