"""Tempo útil e SLA.

Datas são gravadas em UTC (texto ISO, como o restante do banco) e os dias
úteis são contados no horário de Brasília (UTC−3, sem horário de verão desde
2019). Dia útil = segunda a sexta, 24 horas; feriados não são considerados.
"""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone

DIA_UTIL = 86400                      # segundos de um dia útil
FUSO_BRASILIA = timedelta(hours=-3)   # sem tzdata no Windows: deslocamento fixo


def agora() -> datetime:
    """Agora em UTC, sem fuso (mesmo padrão de helpers.utc_now_str)."""
    return datetime.now(timezone.utc).replace(tzinfo=None, microsecond=0)


def ler(valor) -> datetime | None:
    """Texto do banco ('2026-10-06 08:46:06' ou ISO com 'T') → datetime UTC."""
    if not valor:
        return None
    if isinstance(valor, datetime):
        return valor.replace(tzinfo=None)
    try:
        return datetime.fromisoformat(str(valor).replace("T", " ").split(".")[0])
    except ValueError:
        return None


def gravar(dt: datetime | None) -> str | None:
    return dt.replace(microsecond=0).isoformat(timespec="seconds") if dt else None


def para_local(dt: datetime | None) -> datetime | None:
    """UTC → horário de Brasília (para exibir e para contar dias úteis)."""
    return dt + FUSO_BRASILIA if dt else None


def _util(d: date) -> bool:
    return d.weekday() < 5


def segundos_uteis(inicio: datetime | None, fim: datetime | None) -> int:
    """Segundos entre início e fim que caem em dias úteis (horário de Brasília)."""
    if not inicio or not fim or fim <= inicio:
        return 0
    atual, limite = para_local(inicio), para_local(fim)
    total = 0.0
    while atual < limite:
        fim_do_dia = datetime.combine(atual.date() + timedelta(days=1), datetime.min.time())
        trecho_fim = min(fim_do_dia, limite)
        if _util(atual.date()):
            total += (trecho_fim - atual).total_seconds()
        atual = trecho_fim
    return int(total)


def avancar_util(inicio: datetime, segundos: int) -> datetime:
    """Momento (UTC) em que se completam `segundos` úteis a partir de `inicio`."""
    atual = para_local(inicio)
    restante = float(max(segundos, 0))
    while True:
        fim_do_dia = datetime.combine(atual.date() + timedelta(days=1), datetime.min.time())
        if _util(atual.date()):
            disponivel = (fim_do_dia - atual).total_seconds()
            if disponivel >= restante:
                return atual + timedelta(seconds=restante) - FUSO_BRASILIA
            restante -= disponivel
        atual = fim_do_dia


def uteis_em_intervalos(intervalos, inicio: datetime, fim: datetime) -> int:
    """Soma dos segundos úteis de intervalos (início, fim|None) recortados em [inicio, fim]."""
    total = 0
    for a, b in intervalos:
        a, b = ler(a), ler(b) or fim
        if not a:
            continue
        total += segundos_uteis(max(a, inicio), min(b, fim))
    return total


# ---------------------------------------------------------------------------
# Situação do SLA
# ---------------------------------------------------------------------------
LIMIAR_PROXIMO = 0.75

SITUACOES_SLA: dict[str, str] = {
    "no_prazo": "No prazo",
    "proximo": "Próximo do vencimento",
    "vencido": "Vencido",
    "suspenso": "Suspenso",            # pausado ou bloqueado: o relógio para
    "cumprido": "Cumprido",
    "descumprido": "Descumprido",
    "sem_sla": "Sem SLA",
}


def situacao_sla(consumido: int, prazo: int | None, *, aberta: bool, suspenso: bool = False,
                 limiar: float = LIMIAR_PROXIMO) -> str:
    """Classifica o SLA a partir do tempo útil consumido e do prazo (segundos)."""
    if not prazo:
        return "sem_sla"
    if not aberta:
        return "cumprido" if consumido <= prazo else "descumprido"
    if consumido > prazo:
        return "vencido"
    if suspenso:
        return "suspenso"
    return "proximo" if consumido >= prazo * limiar else "no_prazo"


# ---------------------------------------------------------------------------
# Formatação
# ---------------------------------------------------------------------------
def formatar_duracao(segundos: int | None) -> str:
    """3 d 4 h · 2 h 10 min · 15 min · menos de 1 min (tempo corrido)."""
    s = int(segundos or 0)
    if s < 60:
        return "menos de 1 min"
    d, s = divmod(s, 86400)
    h, s = divmod(s, 3600)
    m = s // 60
    if d:
        return f"{d} d {h} h" if h else f"{d} d"
    if h:
        return f"{h} h {m} min" if m else f"{h} h"
    return f"{m} min"


def formatar_dias_uteis(segundos: int | None) -> str:
    """Tempo útil em dias úteis com uma casa decimal ('1,5 dia útil')."""
    dias = (segundos or 0) / DIA_UTIL
    texto = f"{dias:.1f}".replace(".", ",")
    return f"{texto} {'dia útil' if dias < 1.05 else 'dias úteis'}"


def formatar_data(dt) -> str:
    """dd/mm/aaaa hh:mm no horário de Brasília."""
    local = para_local(ler(dt))
    return local.strftime("%d/%m/%Y %H:%M") if local else ""
