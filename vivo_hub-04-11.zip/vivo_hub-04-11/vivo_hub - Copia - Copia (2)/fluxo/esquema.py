"""Tabelas da linha do tempo, gatilhos de auditoria e migração dos formulários.

As tabelas não têm chave estrangeira para atacado_forms de propósito: se um
formulário for excluído (só é permitido antes do primeiro envio), o histórico
dele continua no banco para auditoria.
"""
from __future__ import annotations

import logging
import sqlite3

from config import SLA_ETAPAS_DIAS_UTEIS
from fluxo.definicao import ETAPAS, STATUS_PARA_ETAPA
from fluxo.tempo import gravar, ler

logger = logging.getLogger(__name__)

ESQUEMA_SQL = """
-- Estado atual de cada processo: única fonte de verdade
CREATE TABLE IF NOT EXISTS pti_processos (
    form_id                INTEGER PRIMARY KEY,
    etapa                  TEXT NOT NULL,
    situacao               TEXT NOT NULL DEFAULT 'ativo'
                           CHECK (situacao IN ('ativo', 'pausado', 'bloqueado')),
    motivo_situacao        TEXT,
    area_dependencia       TEXT,
    area_responsavel       TEXT NOT NULL,
    usuario_responsavel_id INTEGER,
    responsavel_desde      TEXT NOT NULL,
    etapa_instancia_id     INTEGER NOT NULL,
    prioridade             TEXT NOT NULL DEFAULT 'normal',
    tipo_processo          TEXT NOT NULL DEFAULT 'novo',
    criado_em              TEXT NOT NULL,
    primeiro_envio_em      TEXT,
    concluido_em           TEXT,
    cancelado_em           TEXT,
    retornos               INTEGER NOT NULL DEFAULT 0,
    reaberturas            INTEGER NOT NULL DEFAULT 0,
    ultimo_evento_id       INTEGER,
    ultima_movimentacao_em TEXT,
    versao_registro        INTEGER NOT NULL DEFAULT 1
);

-- Cada passagem por uma etapa (base do SLA por etapa e por equipe)
CREATE TABLE IF NOT EXISTS pti_etapas (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    form_id            INTEGER NOT NULL,
    etapa              TEXT NOT NULL,
    ocorrencia         INTEGER NOT NULL DEFAULT 1,
    area               TEXT NOT NULL,
    usuario_id         INTEGER,
    inicio_em          TEXT NOT NULL,
    fim_em             TEXT,
    sla_dias_uteis     INTEGER,
    desfecho           TEXT,
    proxima_etapa      TEXT,
    tempo_util_s       INTEGER,
    tempo_pausado_s    INTEGER,
    tempo_bloqueado_s  INTEGER,
    evento_inicio_id   INTEGER,
    evento_fim_id      INTEGER
);

-- Intervalos de pausa e bloqueio
CREATE TABLE IF NOT EXISTS pti_situacoes (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    form_id             INTEGER NOT NULL,
    etapa_instancia_id  INTEGER NOT NULL,
    tipo                TEXT NOT NULL CHECK (tipo IN ('pausado', 'bloqueado')),
    tipo_bloqueio       TEXT,
    motivo              TEXT NOT NULL,
    area_dependencia    TEXT,
    inicio_em           TEXT NOT NULL,
    fim_em              TEXT,
    usuario_inicio_id   INTEGER,
    usuario_fim_id      INTEGER
);

-- Trilha de auditoria: somente inserção (ver gatilhos)
CREATE TABLE IF NOT EXISTS pti_eventos (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    form_id                 INTEGER NOT NULL,
    tipo                    TEXT NOT NULL,
    ocorrido_em             TEXT NOT NULL,
    origem                  TEXT NOT NULL,
    usuario_id              INTEGER,
    usuario_email           TEXT,
    etapa_anterior          TEXT,
    etapa_nova              TEXT,
    status_anterior         TEXT,
    status_novo             TEXT,
    area_anterior           TEXT,
    area_nova               TEXT,
    usuario_resp_anterior   INTEGER,
    usuario_resp_novo       INTEGER,
    situacao_anterior       TEXT,
    situacao_nova           TEXT,
    acao_esperada           TEXT,
    motivo                  TEXT,
    comentario              TEXT,
    area_destino            TEXT,
    pendencias_json         TEXT,
    documentos_json         TEXT,
    dados_alterados_json    TEXT,
    tempo_etapa_anterior_s  INTEGER,
    prazo_em                TEXT,
    situacao_sla            TEXT,
    etapa_instancia_id      INTEGER
);

CREATE TABLE IF NOT EXISTS pti_pendencias (
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    form_id              INTEGER NOT NULL,
    descricao            TEXT NOT NULL,
    area_responsavel     TEXT NOT NULL,
    bloqueante           INTEGER NOT NULL DEFAULT 0,
    aberta_por           INTEGER,
    aberta_em            TEXT NOT NULL,
    resolvida_por        INTEGER,
    resolvida_em         TEXT,
    resolucao            TEXT,
    evento_abertura_id   INTEGER,
    evento_resolucao_id  INTEGER
);

CREATE TABLE IF NOT EXISTS pti_alertas (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    form_id             INTEGER NOT NULL,
    evento_id           INTEGER,
    tipo                TEXT NOT NULL,
    area_destino        TEXT NOT NULL,
    usuario_destino_id  INTEGER,
    mensagem            TEXT NOT NULL,
    acao                TEXT,
    criado_em           TEXT NOT NULL,
    chave               TEXT UNIQUE
);

CREATE TABLE IF NOT EXISTS pti_alertas_leitura (
    alerta_id   INTEGER NOT NULL,
    usuario_id  INTEGER NOT NULL,
    lido_em     TEXT NOT NULL,
    PRIMARY KEY (alerta_id, usuario_id)
);

CREATE INDEX IF NOT EXISTS ix_pti_eventos_form ON pti_eventos (form_id, ocorrido_em);
CREATE INDEX IF NOT EXISTS ix_pti_eventos_tipo ON pti_eventos (tipo, ocorrido_em);
CREATE INDEX IF NOT EXISTS ix_pti_etapas_form ON pti_etapas (form_id, inicio_em);
CREATE INDEX IF NOT EXISTS ix_pti_etapas_area ON pti_etapas (area, etapa);
CREATE INDEX IF NOT EXISTS ix_pti_situacoes_form ON pti_situacoes (form_id, etapa_instancia_id);
CREATE INDEX IF NOT EXISTS ix_pti_pendencias_form ON pti_pendencias (form_id, resolvida_em);
CREATE INDEX IF NOT EXISTS ix_pti_alertas_destino ON pti_alertas (area_destino, usuario_destino_id, criado_em);
CREATE INDEX IF NOT EXISTS ix_pti_processos_area ON pti_processos (area_responsavel, etapa);

-- Histórico imutável: nenhum evento pode ser alterado ou apagado
CREATE TRIGGER IF NOT EXISTS pti_eventos_sem_alteracao
BEFORE UPDATE ON pti_eventos
BEGIN
    SELECT RAISE(ABORT, 'pti_eventos é somente inserção: o histórico não pode ser alterado');
END;

CREATE TRIGGER IF NOT EXISTS pti_eventos_sem_exclusao
BEFORE DELETE ON pti_eventos
BEGIN
    SELECT RAISE(ABORT, 'pti_eventos é somente inserção: o histórico não pode ser apagado');
END;

-- Visão para dashboards e relatórios externos: cada passagem por etapa com a
-- área responsável no período (tempos úteis gravados ao encerrar a etapa)
CREATE VIEW IF NOT EXISTS vw_pti_etapas AS
SELECT e.id, e.form_id, f.nome_operadora, f.version, e.etapa, e.ocorrencia, e.area,
       e.usuario_id, e.inicio_em, e.fim_em, e.sla_dias_uteis, e.desfecho,
       e.tempo_util_s, e.tempo_pausado_s, e.tempo_bloqueado_s,
       p.prioridade, p.tipo_processo
FROM pti_etapas e
LEFT JOIN atacado_forms f ON f.id = e.form_id
LEFT JOIN pti_processos p ON p.form_id = e.form_id;
"""


def criar_esquema(db: sqlite3.Connection) -> None:
    db.executescript(ESQUEMA_SQL)


def migrar_formularios(db: sqlite3.Connection) -> int:
    """Cria o processo dos formulários que ainda não têm linha do tempo.

    O histórico anterior não existe: o estado é importado do status antigo e
    marcado com origem 'migracao' (datas = created_at e updated_at do formulário).
    Retorna quantos processos foram criados.
    """
    pendentes = db.execute(
        "SELECT f.id, f.owner_id, f.status, f.version, f.parent_id, f.created_at, f.updated_at, "
        "       u.email AS dono_email "
        "FROM atacado_forms f LEFT JOIN users u ON u.id = f.owner_id "
        "WHERE f.id NOT IN (SELECT form_id FROM pti_processos) ORDER BY f.id"
    ).fetchall()
    for f in pendentes:
        criado = ler(f["created_at"]) or ler(f["updated_at"])
        desde = ler(f["updated_at"]) or criado
        etapa = ETAPAS[STATUS_PARA_ETAPA.get((f["status"] or "rascunho").lower(), "elaboracao")]
        tipo = "nova_versao" if f["parent_id"] else "novo"

        def evento(tipo_evento, quando, **campos):
            cols = ["form_id", "tipo", "ocorrido_em", "origem", "usuario_id", "usuario_email"] + list(campos)
            valores = [f["id"], tipo_evento, gravar(quando), "migracao", f["owner_id"], f["dono_email"]] + list(campos.values())
            cur = db.execute(f"INSERT INTO pti_eventos ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})", valores)
            return cur.lastrowid

        ev_criacao = evento("processo_criado", criado, etapa_nova="elaboracao", status_novo="rascunho",
                            area_nova="atacado", usuario_resp_novo=f["owner_id"],
                            acao_esperada=ETAPAS["elaboracao"].acao,
                            comentario="Registro anterior à linha do tempo.")
        if etapa.chave == "elaboracao":
            cur = db.execute(
                "INSERT INTO pti_etapas (form_id, etapa, ocorrencia, area, usuario_id, inicio_em, evento_inicio_id) "
                "VALUES (?, 'elaboracao', 1, 'atacado', ?, ?, ?)",
                (f["id"], f["owner_id"], gravar(criado), ev_criacao))
            inst, ultimo, mov = cur.lastrowid, ev_criacao, criado
            usuario = f["owner_id"]
        else:
            ev_estado = evento(
                "estado_importado", desde,
                etapa_anterior="elaboracao", etapa_nova=etapa.chave,
                status_anterior="rascunho", status_novo=etapa.status,
                area_anterior="atacado", area_nova=etapa.area,
                usuario_resp_anterior=f["owner_id"],
                acao_esperada=etapa.acao,
                motivo=f"Estado importado do status anterior ('{f['status']}'). "
                       "A data é a da última atualização do formulário; o histórico anterior não existe.")
            db.execute(
                "INSERT INTO pti_etapas (form_id, etapa, ocorrencia, area, usuario_id, inicio_em, fim_em, desfecho, "
                "proxima_etapa, evento_inicio_id, evento_fim_id) VALUES (?, 'elaboracao', 1, 'atacado', ?, ?, ?, "
                "'migracao', ?, ?, ?)",
                (f["id"], f["owner_id"], gravar(criado), gravar(desde), etapa.chave, ev_criacao, ev_estado))
            usuario = f["owner_id"] if etapa.area == "atacado" else None
            cur = db.execute(
                "INSERT INTO pti_etapas (form_id, etapa, ocorrencia, area, usuario_id, inicio_em, sla_dias_uteis, "
                "evento_inicio_id) VALUES (?, ?, 1, ?, ?, ?, ?, ?)",
                (f["id"], etapa.chave, etapa.area, usuario, gravar(desde),
                 None if etapa.terminal else SLA_ETAPAS_DIAS_UTEIS.get(etapa.chave), ev_estado))
            inst, ultimo, mov = cur.lastrowid, ev_estado, desde

        enviado = etapa.chave not in ("elaboracao", "cancelado")
        db.execute(
            "INSERT INTO pti_processos (form_id, etapa, area_responsavel, usuario_responsavel_id, responsavel_desde, "
            "etapa_instancia_id, tipo_processo, criado_em, primeiro_envio_em, concluido_em, cancelado_em, retornos, "
            "ultimo_evento_id, ultima_movimentacao_em) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (f["id"], etapa.chave, etapa.area, usuario, gravar(mov), inst, tipo, gravar(criado),
             gravar(desde) if enviado else None,
             gravar(desde) if etapa.chave == "concluido" else None,
             gravar(desde) if etapa.chave == "cancelado" else None,
             1 if etapa.chave == "ajustes" else 0, ultimo, gravar(mov)))
    if pendentes:
        logger.info("Linha do tempo: %d processo(s) migrado(s) a partir do status anterior.", len(pendentes))
    _completar_sla_migrados(db)
    return len(pendentes)


def _completar_sla_migrados(db: sqlite3.Connection) -> None:
    """Etapa atual de processo migrado sem SLA (primeira versão da migração):
    recebe o SLA configurado, contado a partir da data estimada."""
    for etapa, dias in SLA_ETAPAS_DIAS_UTEIS.items():
        if dias:
            db.execute(
                "UPDATE pti_etapas SET sla_dias_uteis = ? WHERE etapa = ? AND fim_em IS NULL "
                "AND sla_dias_uteis IS NULL AND evento_inicio_id IN "
                "(SELECT id FROM pti_eventos WHERE origem = 'migracao')", (dias, etapa))
