"""Leitura do estado, da linha do tempo, do histórico e dos tempos por equipe.

Todas as telas (Atacado, Engenharia, indicadores) leem daqui: a mesma regra,
os mesmos dados, a mesma frase de situação.
"""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime

from config import SEM_MOVIMENTACAO_DIAS_UTEIS, SLA_LIMIAR_PROXIMO, SLA_TOTAL_DIAS_UTEIS
from fluxo.definicao import (
    AREAS, CAMINHO, ETAPAS, EVENTOS, ORIGENS, PRIORIDADES, SITUACOES, TIPOS_BLOQUEIO,
    TIPOS_PROCESSO, da_area, frase_situacao, nome_area, nome_usuario,
)
from fluxo.tempo import (
    DIA_UTIL, SITUACOES_SLA, agora, avancar_util, formatar_data, formatar_dias_uteis,
    formatar_duracao, gravar, ler, segundos_uteis, situacao_sla,
)

# Desfecho de uma passagem por etapa → estado exibido na linha do tempo
_ESTADO_POR_DESFECHO = {
    "concluida": "concluida", "devolvida": "devolvida", "cancelada": "cancelada",
    "reaberta": "concluida", "interrompida": "concluida", "migracao": "concluida",
    "excluida": "cancelada",
}

ESTADOS_ETAPA: dict[str, str] = {
    "concluida": "Concluída", "atual": "Etapa atual", "futura": "Prevista",
    "atrasada": "Atrasada", "bloqueada": "Bloqueada", "pausada": "Pausada",
    "devolvida": "Devolvida para ajuste", "ignorada": "Não utilizada",
    "cancelada": "Cancelada", "encerrada": "Encerramento",
}


def _usuarios(db: sqlite3.Connection) -> dict[int, str]:
    return {r["id"]: r["email"] for r in db.execute("SELECT id, email FROM users")}


# ---------------------------------------------------------------------------
# Tempos de uma passagem por etapa
# ---------------------------------------------------------------------------
def tempos_instancia(db: sqlite3.Connection, inst, ate: datetime | None = None) -> dict:
    """Tempo útil, pausado, bloqueado e ativo de uma passagem por etapa, com o SLA."""
    inicio = ler(inst["inicio_em"])
    fim = ler(inst["fim_em"])
    limite = fim or ate or agora()
    intervalos = db.execute(
        "SELECT tipo, tipo_bloqueio, motivo, area_dependencia, inicio_em, fim_em FROM pti_situacoes "
        "WHERE etapa_instancia_id = ? ORDER BY inicio_em", (inst["id"],)).fetchall()
    pausado = bloqueado = aguardando_info = 0
    for s in intervalos:
        a, b = max(ler(s["inicio_em"]), inicio), min(ler(s["fim_em"]) or limite, limite)
        seg = segundos_uteis(a, b)
        if s["tipo"] == "pausado":
            pausado += seg
        else:
            bloqueado += seg
            if s["tipo_bloqueio"] == "ausencia_informacao":
                aguardando_info += seg
    util = segundos_uteis(inicio, limite)
    ativo = max(util - pausado - bloqueado, 0)
    prazo_s = (inst["sla_dias_uteis"] or 0) * DIA_UTIL or None
    suspenso = bool(fim is None and intervalos and intervalos[-1]["fim_em"] is None)
    prazo_em = avancar_util(inicio, prazo_s + pausado + bloqueado) if prazo_s else None
    return {
        "util_s": util, "pausado_s": pausado, "bloqueado_s": bloqueado,
        "aguardando_info_s": aguardando_info, "ativo_s": ativo,
        "corrido_s": int((limite - inicio).total_seconds()),
        "prazo_s": prazo_s, "prazo_em": prazo_em,
        "sla": situacao_sla(ativo, prazo_s, aberta=fim is None, suspenso=suspenso, limiar=SLA_LIMIAR_PROXIMO),
        "intervalos": intervalos,
    }


def sla_total(db: sqlite3.Connection, proc) -> dict:
    """SLA total: do primeiro envio à conclusão (ou agora), menos pausas e bloqueios."""
    inicio = ler(proc["primeiro_envio_em"])
    prazo_s = SLA_TOTAL_DIAS_UTEIS * DIA_UTIL
    if not inicio:
        return {"consumido_s": 0, "prazo_s": prazo_s, "sla": "sem_sla", "prazo_em": None}
    fim = ler(proc["concluido_em"]) or ler(proc["cancelado_em"]) or agora()
    util = segundos_uteis(inicio, fim)
    suspensos = sum(
        segundos_uteis(max(ler(s["inicio_em"]), inicio), min(ler(s["fim_em"]) or fim, fim))
        for s in db.execute("SELECT inicio_em, fim_em FROM pti_situacoes WHERE form_id = ?", (proc["form_id"],))
    )
    consumido = max(util - suspensos, 0)
    aberto = not ETAPAS[proc["etapa"]].terminal
    return {
        "consumido_s": consumido, "prazo_s": prazo_s,
        "prazo_em": avancar_util(inicio, prazo_s + suspensos),
        "sla": situacao_sla(consumido, prazo_s, aberta=aberto,
                            suspenso=aberto and proc["situacao"] != "ativo", limiar=SLA_LIMIAR_PROXIMO)
        if proc["etapa"] != "cancelado" else "sem_sla",
    }


# ---------------------------------------------------------------------------
# Estado atual (resumo operacional)
# ---------------------------------------------------------------------------
def processo(db: sqlite3.Connection, form_id: int):
    return db.execute("SELECT * FROM pti_processos WHERE form_id = ?", (form_id,)).fetchone()


def instancia_atual(db: sqlite3.Connection, proc):
    return db.execute("SELECT * FROM pti_etapas WHERE id = ?", (proc["etapa_instancia_id"],)).fetchone()


def pendencias(db: sqlite3.Connection, form_id: int, *, abertas: bool | None = None) -> list:
    sql = "SELECT * FROM pti_pendencias WHERE form_id = ?"
    if abertas is True:
        sql += " AND resolvida_em IS NULL"
    elif abertas is False:
        sql += " AND resolvida_em IS NOT NULL"
    return db.execute(sql + " ORDER BY aberta_em", (form_id,)).fetchall()


def descrever_evento(ev) -> str:
    """Rótulo do evento no histórico ("Devolvido ao Atacado para ajustes")."""
    rotulo = EVENTOS.get(ev["tipo"], ev["tipo"])
    if ev["tipo"] == "reaberto" and ev["etapa_nova"] in ETAPAS:
        rotulo += f" em {ETAPAS[ev['etapa_nova']].nome.lower()}"
    return rotulo


def estado(db: sqlite3.Connection, form_id: int, form=None) -> dict | None:
    """Resumo operacional do processo, igual para Engenharia e Atacado."""
    proc = processo(db, form_id)
    if not proc:
        return None
    usuarios = _usuarios(db)
    etapa = ETAPAS[proc["etapa"]]
    inst = instancia_atual(db, proc)
    t = tempos_instancia(db, inst) if inst else None
    resp_email = usuarios.get(proc["usuario_responsavel_id"])
    ultimo = db.execute("SELECT * FROM pti_eventos WHERE id = ?", (proc["ultimo_evento_id"],)).fetchone()
    abertas = pendencias(db, form_id, abertas=True)
    prox = ETAPAS.get(etapa.proxima) if etapa.proxima else None
    alternativas = []
    if etapa.chave == "validacao_tecnica":
        alternativas = ["Ajustes do Atacado (se devolvido)", "Resposta da operadora (se o PTI for enviado à operadora)"]
    parado_s = segundos_uteis(ler(proc["ultima_movimentacao_em"]), agora())
    total = sla_total(db, proc)
    return {
        "form_id": form_id,
        "proc": dict(proc),
        "etapa": etapa,
        "frase": frase_situacao(dict(proc), usuario_nome=nome_usuario(resp_email)),
        "situacao": proc["situacao"],
        "situacao_nome": SITUACOES[proc["situacao"]],
        "area": proc["area_responsavel"], "area_nome": nome_area(proc["area_responsavel"]),
        "executor": etapa.executor, "executor_nome": nome_area(etapa.executor),
        "usuario_id": proc["usuario_responsavel_id"],
        "usuario_nome": nome_usuario(resp_email) or ("não atribuído" if not etapa.terminal else "—"),
        "desde": proc["responsavel_desde"], "desde_fmt": formatar_data(proc["responsavel_desde"]),
        "tempo_etapa": formatar_duracao(t["corrido_s"]) if t else "",
        "tempo_etapa_util": formatar_dias_uteis(t["ativo_s"]) if t else "",
        "prazo_em": gravar(t["prazo_em"]) if t and t["prazo_em"] else None,
        "prazo_fmt": formatar_data(t["prazo_em"]) if t and t["prazo_em"] else "",
        "sla": t["sla"] if t else "sem_sla",
        "sla_nome": SITUACOES_SLA[t["sla"] if t else "sem_sla"],
        "sla_consumo": (f"{formatar_dias_uteis(t['ativo_s'])} de {formatar_dias_uteis(t['prazo_s'])}"
                        if t and t["prazo_s"] else ""),
        "sla_total": total, "sla_total_nome": SITUACOES_SLA[total["sla"]],
        "sla_total_consumo": (f"{formatar_dias_uteis(total['consumido_s'])} de {formatar_dias_uteis(total['prazo_s'])}"
                              if total["sla"] != "sem_sla" else ""),
        "ultimo_evento": dict(ultimo) if ultimo else None,
        "ultimo_evento_desc": descrever_evento(ultimo) if ultimo else "",
        "ultimo_evento_autor": nome_usuario(ultimo["usuario_email"]) if ultimo and ultimo["usuario_email"] not in (None, "sistema") else "Sistema",
        "ultimo_evento_quando": formatar_data(ultimo["ocorrido_em"]) if ultimo else "",
        "acao": etapa.acao,
        "proxima_etapa": prox.nome if prox else "—",
        "proxima_area": nome_area(prox.area) if prox and not prox.terminal else ("Encerramento" if prox else "—"),
        "alternativas": alternativas,
        "pendencias": len(abertas),
        "bloqueado": proc["situacao"] == "bloqueado",
        "motivo_situacao": proc["motivo_situacao"],
        "area_dependencia_nome": nome_area(proc["area_dependencia"]) if proc["area_dependencia"] else "",
        "dependencia_da": da_area(proc["area_dependencia"]) if proc["area_dependencia"] else "",
        "retornos": proc["retornos"], "reaberturas": proc["reaberturas"],
        "prioridade": proc["prioridade"], "prioridade_nome": PRIORIDADES.get(proc["prioridade"], proc["prioridade"]),
        "tipo_nome": TIPOS_PROCESSO.get(proc["tipo_processo"], proc["tipo_processo"]),
        "sem_movimentacao": (not etapa.terminal) and parado_s >= SEM_MOVIMENTACAO_DIAS_UTEIS * DIA_UTIL,
        "parado": formatar_duracao(int((agora() - ler(proc["ultima_movimentacao_em"])).total_seconds())),
        "atualizado_fmt": formatar_data(max(filter(None, [ler(proc["ultima_movimentacao_em"]),
                                                          ler(form["updated_at"]) if form else None]))),
        "terminal": etapa.terminal,
        "versao_registro": proc["versao_registro"],
    }


# ---------------------------------------------------------------------------
# Linha do tempo (passado, presente e próximas etapas)
# ---------------------------------------------------------------------------
def linha_do_tempo(db: sqlite3.Connection, form_id: int) -> list[dict]:
    proc = processo(db, form_id)
    if not proc:
        return []
    usuarios = _usuarios(db)
    instancias = db.execute("SELECT * FROM pti_etapas WHERE form_id = ? ORDER BY inicio_em, id", (form_id,)).fetchall()
    eventos = db.execute("SELECT * FROM pti_eventos WHERE form_id = ? ORDER BY ocorrido_em, id", (form_id,)).fetchall()
    pend = pendencias(db, form_id)
    itens: list[dict] = []
    visitadas = set()
    for inst in instancias:
        etapa = ETAPAS[inst["etapa"]]
        visitadas.add(etapa.chave)
        aberta = inst["fim_em"] is None
        t = tempos_instancia(db, inst)
        if etapa.terminal:
            estado_item = "encerrada" if etapa.chave == "concluido" else "cancelada"
            if not aberta:
                estado_item = "concluida"
        elif aberta:
            if proc["situacao"] == "bloqueado":
                estado_item = "bloqueada"
            elif proc["situacao"] == "pausado":
                estado_item = "pausada"
            elif t["sla"] == "vencido":
                estado_item = "atrasada"
            else:
                estado_item = "atual"
        else:
            estado_item = _ESTADO_POR_DESFECHO.get(inst["desfecho"], "concluida")
            if estado_item == "concluida" and t["sla"] == "descumprido":
                estado_item = "atrasada"
        ev_inicio = next((e for e in eventos if e["id"] == inst["evento_inicio_id"]), None)
        ev_fim = next((e for e in eventos if e["id"] == inst["evento_fim_id"]), None)
        do_periodo = [e for e in eventos if e["etapa_instancia_id"] == inst["id"]]
        motivos = [s["motivo"] for s in t["intervalos"] if s["tipo"] == "bloqueado"]
        inicio, fim = ler(inst["inicio_em"]), ler(inst["fim_em"])
        pend_periodo = [p for p in pend if ler(p["aberta_em"]) >= inicio and (fim is None or ler(p["aberta_em"]) < fim)]
        prox = ETAPAS.get(inst["proxima_etapa"] or "") or (ETAPAS.get(etapa.proxima) if etapa.proxima else None)
        itens.append({
            "id": inst["id"], "chave": etapa.chave, "nome": etapa.nome, "ocorrencia": inst["ocorrencia"],
            "estado": estado_item, "estado_nome": ESTADOS_ETAPA[estado_item], "aberta": aberta and not etapa.terminal,
            "terminal": etapa.terminal,
            "area": inst["area"], "area_nome": nome_area(inst["area"]),
            "usuario_nome": nome_usuario(usuarios.get(inst["usuario_id"])),
            "inicio_fmt": formatar_data(inst["inicio_em"]), "fim_fmt": formatar_data(inst["fim_em"]),
            "permanencia": formatar_duracao(t["corrido_s"]), "permanencia_util": formatar_dias_uteis(t["ativo_s"]),
            "pausado": formatar_dias_uteis(t["pausado_s"]) if t["pausado_s"] else "",
            "bloqueado": formatar_dias_uteis(t["bloqueado_s"]) if t["bloqueado_s"] else "",
            "sla_previsto": f"{inst['sla_dias_uteis']} dias úteis" if inst["sla_dias_uteis"] else "Sem SLA",
            "sla": t["sla"], "sla_nome": SITUACOES_SLA[t["sla"]],
            "prazo_fmt": formatar_data(t["prazo_em"]) if t["prazo_em"] else "",
            "acao": etapa.acao if aberta else "",
            "pendencias": len(pend_periodo),
            "pendencias_abertas": sum(1 for p in pend_periodo if not p["resolvida_em"]),
            "motivos_bloqueio": motivos,
            "comentarios": [e for e in do_periodo if e["tipo"] == "comentario"],
            "documentos": [json.loads(e["documentos_json"]) for e in do_periodo if e["documentos_json"]],
            # Entrada e saída da etapa: o evento (sem repetir o nome da etapa) e quem fez
            "origem": (EVENTOS.get(ev_inicio["tipo"], ev_inicio["tipo"]) + " · "
                       + (nome_usuario(ev_inicio["usuario_email"]) or ORIGENS.get(ev_inicio["origem"], "")))
            if ev_inicio else "",
            "desfecho": (EVENTOS.get(ev_fim["tipo"], ev_fim["tipo"]) + " · "
                         + (nome_usuario(ev_fim["usuario_email"]) or ORIGENS.get(ev_fim["origem"], ""))
                         + (f" — {ev_fim['motivo']}" if ev_fim["motivo"] else "")) if ev_fim else "",
            "proxima": prox.nome if prox else "",
            "proxima_area": nome_area(prox.area) if prox and not prox.terminal else "",
        })

    # Próximas etapas previstas (e etapa opcional não utilizada)
    atual = ETAPAS[proc["etapa"]]
    if not atual.terminal:
        for chave in PREVISTAS.get(atual.chave, ()):
            if chave == "resposta_operadora" and chave in visitadas:
                continue
            itens.append(_futura(chave, opcional=ETAPAS[chave].opcional))
    elif atual.chave == "concluido" and "resposta_operadora" not in visitadas:
        # A etapa opcional que não foi necessária aparece antes do encerramento
        itens.insert(len(itens) - 1, {**_futura("resposta_operadora", opcional=True),
                                      "estado": "ignorada", "estado_nome": ESTADOS_ETAPA["ignorada"]})
    return _sem_duplicadas(itens)


# Caminho previsto a partir de cada etapa aberta
PREVISTAS: dict[str, tuple[str, ...]] = {
    "elaboracao": ("validacao_tecnica", "resposta_operadora", "concluido"),
    "validacao_tecnica": ("resposta_operadora", "concluido"),
    "ajustes": ("validacao_tecnica", "resposta_operadora", "concluido"),
    "resposta_operadora": ("validacao_tecnica", "concluido"),
}


def _futura(chave: str, opcional: bool = False) -> dict:
    e = ETAPAS[chave]
    sla = _sla_config(chave)
    return {
        "id": None, "chave": chave, "nome": e.nome + (" (opcional)" if opcional else ""),
        "estado": "futura", "estado_nome": ESTADOS_ETAPA["futura"], "aberta": False, "terminal": e.terminal,
        "area": e.area, "area_nome": nome_area(e.area) if not e.terminal else "", "acao": e.acao if not e.terminal else "",
        "sla_previsto": f"{sla} dias úteis" if sla else ("Sem SLA" if not e.terminal else ""),
        "proxima": ETAPAS[e.proxima].nome if e.proxima else "",
    }


def _sla_config(chave: str) -> int | None:
    from config import SLA_ETAPAS_DIAS_UTEIS
    return SLA_ETAPAS_DIAS_UTEIS.get(chave)


def _sem_duplicadas(itens: list[dict]) -> list[dict]:
    """Remove etapas futuras repetidas (mantém a primeira ocorrência prevista)."""
    vistas, saida = set(), []
    for it in itens:
        if it["estado"] in ("futura", "ignorada"):
            if it["chave"] in vistas:
                continue
            vistas.add(it["chave"])
        saida.append(it)
    return saida


# ---------------------------------------------------------------------------
# Histórico compartilhado
# ---------------------------------------------------------------------------
def historico(db: sqlite3.Connection, form_id: int) -> list[dict]:
    from fluxo.definicao import ROTULOS_CAMPOS
    saida = []
    for ev in db.execute("SELECT * FROM pti_eventos WHERE form_id = ? ORDER BY ocorrido_em DESC, id DESC", (form_id,)):
        dados = json.loads(ev["dados_alterados_json"]) if ev["dados_alterados_json"] else {}
        saida.append({
            **dict(ev),
            "rotulo": descrever_evento(ev),
            "quando": formatar_data(ev["ocorrido_em"]),
            "autor": nome_usuario(ev["usuario_email"]) if ev["usuario_email"] not in (None, "sistema") else "Sistema",
            "origem_nome": ORIGENS.get(ev["origem"], ev["origem"]),
            "etapa_anterior_nome": ETAPAS[ev["etapa_anterior"]].nome if ev["etapa_anterior"] in ETAPAS else "",
            "etapa_nova_nome": ETAPAS[ev["etapa_nova"]].nome if ev["etapa_nova"] in ETAPAS else "",
            "area_anterior_nome": nome_area(ev["area_anterior"]) if ev["area_anterior"] else "",
            "area_nova_nome": nome_area(ev["area_nova"]) if ev["area_nova"] else "",
            "area_destino_nome": nome_area(ev["area_destino"]) if ev["area_destino"] else "",
            "transferencia": bool(ev["area_anterior"] and ev["area_nova"] and ev["area_anterior"] != ev["area_nova"]),
            "tempo_anterior": formatar_dias_uteis(ev["tempo_etapa_anterior_s"]) if ev["tempo_etapa_anterior_s"] is not None else "",
            "prazo_fmt": formatar_data(ev["prazo_em"]) if ev["prazo_em"] else "",
            "sla_nome": SITUACOES_SLA.get(ev["situacao_sla"] or "", ""),
            "pendencias": json.loads(ev["pendencias_json"]) if ev["pendencias_json"] else [],
            "documentos": json.loads(ev["documentos_json"]) if ev["documentos_json"] else [],
            "dados": [(ROTULOS_CAMPOS.get(k, k), v) for k, v in dados.items()],
        })
    return saida


# ---------------------------------------------------------------------------
# Tempo por responsabilidade (base do SLA por equipe)
# ---------------------------------------------------------------------------
def tempos_por_responsabilidade(db: sqlite3.Connection, form_id: int) -> dict:
    """Separa o tempo do processo por equipe e por natureza (ativo, pausado...)."""
    soma = {k: 0 for k in ("engenharia", "atacado", "integracao", "outras", "aguardando_info",
                           "bloqueado", "pausado", "retrabalho", "total")}
    for inst in db.execute("SELECT * FROM pti_etapas WHERE form_id = ?", (form_id,)):
        if ETAPAS[inst["etapa"]].terminal:
            continue
        t = tempos_instancia(db, inst)
        chave = inst["area"] if inst["area"] in ("engenharia", "atacado", "integracao") else "outras"
        soma[chave] += t["ativo_s"]
        soma["pausado"] += t["pausado_s"]
        soma["bloqueado"] += t["bloqueado_s"]
        soma["aguardando_info"] += t["aguardando_info_s"]
        if inst["etapa"] == "ajustes" or (inst["etapa"] == "validacao_tecnica" and inst["ocorrencia"] > 1):
            soma["retrabalho"] += t["ativo_s"]
        soma["total"] += t["util_s"]
    return {
        "segundos": soma,
        "linhas": [
            ("Sob responsabilidade da Engenharia", formatar_dias_uteis(soma["engenharia"])),
            ("Sob responsabilidade do Atacado", formatar_dias_uteis(soma["atacado"])),
            ("Aguardando integração externa (operadora)", formatar_dias_uteis(soma["integracao"])),
            ("Aguardando informação (bloqueio)", formatar_dias_uteis(soma["aguardando_info"])),
            ("Bloqueado (total)", formatar_dias_uteis(soma["bloqueado"])),
            ("Pausado", formatar_dias_uteis(soma["pausado"])),
            ("Retrabalho (ajustes e revalidações)", formatar_dias_uteis(soma["retrabalho"])),
            ("Tempo total do processo", formatar_dias_uteis(soma["total"])),
        ],
    }


# ---------------------------------------------------------------------------
# Resumo para listas e painel (vários processos de uma vez)
# ---------------------------------------------------------------------------
def resumo_processos(db: sqlite3.Connection, form_ids) -> dict[int, dict]:
    ids = [int(i) for i in form_ids]
    if not ids:
        return {}
    usuarios = _usuarios(db)
    marcadores = ",".join("?" * len(ids))
    procs = db.execute(f"SELECT * FROM pti_processos WHERE form_id IN ({marcadores})", ids).fetchall()
    insts = {r["id"]: r for r in db.execute(
        f"SELECT * FROM pti_etapas WHERE id IN (SELECT etapa_instancia_id FROM pti_processos WHERE form_id IN ({marcadores}))", ids)}
    abertas = {r["form_id"]: r["n"] for r in db.execute(
        f"SELECT form_id, COUNT(*) AS n FROM pti_pendencias WHERE resolvida_em IS NULL AND form_id IN ({marcadores}) "
        "GROUP BY form_id", ids)}
    saida = {}
    for p in procs:
        etapa = ETAPAS[p["etapa"]]
        inst = insts.get(p["etapa_instancia_id"])
        t = tempos_instancia(db, inst) if inst and not etapa.terminal else None
        email = usuarios.get(p["usuario_responsavel_id"])
        saida[p["form_id"]] = {
            "etapa": etapa.chave, "etapa_nome": etapa.nome, "terminal": etapa.terminal,
            "frase": frase_situacao(dict(p), usuario_nome=nome_usuario(email)),
            "area": p["area_responsavel"], "area_nome": nome_area(p["area_responsavel"]),
            "situacao": p["situacao"],
            "usuario_nome": nome_usuario(email),
            "tempo_etapa": formatar_duracao(t["corrido_s"]) if t else "",
            "sla": t["sla"] if t else "sem_sla", "sla_nome": SITUACOES_SLA[t["sla"] if t else "sem_sla"],
            "prazo_fmt": formatar_data(t["prazo_em"]) if t and t["prazo_em"] else "",
            "pendencias": abertas.get(p["form_id"], 0),
            "retornos": p["retornos"],
            "ultima_fmt": formatar_data(p["ultima_movimentacao_em"]),
            "primeiro_envio": bool(p["primeiro_envio_em"]),
        }
    return saida


__all__ = [
    "AREAS", "CAMINHO", "TIPOS_BLOQUEIO", "estado", "linha_do_tempo", "historico",
    "tempos_por_responsabilidade", "resumo_processos", "tempos_instancia", "sla_total",
    "pendencias", "processo", "instancia_atual",
]
