"""Testes da carga dos inventários (planilhas fictícias no formato das reais)."""
from __future__ import annotations

import os
import shutil
import sqlite3
import sys
import tempfile
import time
import unittest
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from openpyxl import Workbook  # noqa: E402

from inventarios import faixas  # noqa: E402
from inventarios.carga import analisar, carregar, carregar_alterados, relatorio  # noqa: E402
from inventarios.esquema import criar_esquema  # noqa: E402

# Layout da planilha de livres como está hoje (colunas separadas por tabulação)
LIVRES_TSV = """cn\t11\t12\t13\t14\t15\t16\t17\t18\t19\t\tROTNGIN cn 11 ao 19\t
\tD00478\tD02204\tD03208\tC48E\tC50B\tD06263\tC76B\tD08253\tD09307\t\tC8791573\t
\tD00479\tD02205\tD03209\tC49B\tC51B\tD06264\tC76C\tD08254\tD09308\t\tC8791574\t
\tD00480\tD02206\tD03210\tC49C\tC52B\tD06265\tC76D\tD08255\tD09309\t\tC8791575\t
\tD00481\tD02207\tD03211\tC49D\tC53B\taté\tC76E\taté\taté\t\taté\t
\tD00482\tD02208\tD03212\tC49E\tC54B\tD06999\tC77B\tD08999\tD09999\t\tC8799999\t
\taté\taté\taté\tD04000\tC55B\t\tC77C\t\t\t\t\t
\tD00199\tD02299\tD03999\taté\tC56B\t\tC77D\t\t\t\t\t
\t\t\t\tD04999\tC57B\t\tC77E\t\t\t\t\t
\t\t\t\t\tC58B\t\tC78B\t\t\t\t\tspo
\t\t\t\t\tC59B\t\tC78C\t\t\t\t\t
\t\t\t\t\tC50C\t\tC78D\t\t\t\t\t
\t\t\t\t\tC51C\t\tC78E\t\t\t\t\t
\t\t\t\t\tC52C\t\tC79B\t\t\t\t\t
\t\t\t\t\tC53C\t\tC79C\t\t\t\t\t
\t\t\t\t\tC54C\t\tC79D\t\t\t\t\t
\t\t\t\t\tC55C\t\tC79E\t\t\t\t\t
\t\t\t\t\tC56C\t\t\t\t\t\t\t
\t\t\t\t\tC57C\t\tdepois de acabar os núemros acima\t\t\t\t\t
\t\t\t\t\tC58C\t\t\t\t\t\t\t
\t\t\t\t\tC59C\t\tD07000\t\t\t\t\t
\t\t\t\t\tC50D\t\taté\t\t\t\t\t
\t\t\t\t\tC51D\t\tD07999\t\t\t\t\t
\t\t\t\t\tC52D\t\t\t\t\t\t\t
\t\t\t\t\tC53D\t\t\t\t\t\t\t
\t\t\t\t\tC54D\t\t\t\t\t\t\t
\t\t\t\t\tC55D\t\t\t\t\t\t\t
\t\t\t\t\tC56D\t\t\t\t\t\t\t
\t\t\t\t\tC57D\t\t\t\t\t\t\t
\t\t\t\t\tC58D\t\t\t\t\t\t\t
\t\t\t\t\tC59D\t\t\t\t\t\t\t
\t\t\t\t\tdepois de acabar os núemros acima\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t15\tD05000\tD05499\tusar apenas para CSP15 do cn 15\t\t\t\t
\t\t\t\t\t15\tD05500\tD05599\tUsar para LC e CNG no cn 15\t\t\t\t"""


def planilha(caminho: Path, linhas: list[list]) -> Path:
    wb = Workbook()
    ws = wb.active
    for linha in linhas:
        ws.append(linha)
    wb.save(caminho)
    return caminho


def livres_linhas(corrigir_cn11: bool = False) -> list[list]:
    linhas = []
    for linha in LIVRES_TSV.split("\n"):
        celulas = [c if c != "" else None for c in linha.split("\t")]
        celulas = [int(c) if c and c.isdigit() and len(c) == 2 else c for c in celulas]
        linhas.append(celulas)
    if corrigir_cn11:
        linhas[7][1] = "D00999"
    return linhas


class Base(unittest.TestCase):
    def setUp(self):
        self.pasta = Path(tempfile.mkdtemp(prefix="inventarios_"))
        self.db = sqlite3.connect(":memory:")
        self.db.row_factory = sqlite3.Row
        criar_esquema(self.db)

    def tearDown(self):
        self.db.close()
        shutil.rmtree(self.pasta, ignore_errors=True)

    def antigo(self, caminho: Path) -> Path:
        """Arquivo 'pronto' (modificado há mais de 10 s)."""
        t = time.time() - 60
        os.utime(caminho, (t, t))
        return caminho


class TestBasesSimples(Base):
    def test_operadoras_com_csp(self):
        p = planilha(self.pasta / "operadoras_com_csp.xlsx", [
            ["RN1", "Nome Fantasia", "CSP"],
            [55121, "Operadora A", 21], [55112, "Operadora B", 12], [55312, "Operadora B", 12],
            [55999, "Operadora C", 5], [None, None, None]])
        r = carregar(self.db, "operadoras_csp", p)
        self.assertTrue(r["ok"], r["erros"])
        self.assertEqual(r["linhas"], 4)
        self.assertEqual(self.db.execute("SELECT csp FROM inv_operadoras_csp WHERE rn1 = '55999'").fetchone()[0], "05")
        carga = self.db.execute("SELECT * FROM inv_cargas").fetchone()
        self.assertEqual((carga["situacao"], carga["linhas"], carga["arquivo"]), ("ok", 4, "operadoras_com_csp.xlsx"))

    def test_erro_nao_apaga_a_carga_anterior_e_nao_mostra_valores(self):
        ok = planilha(self.pasta / "a.xlsx", [["RN1", "Nome Fantasia", "CSP"], [55121, "Sigilosa SA", 21]])
        carregar(self.db, "operadoras_csp", ok)
        ruim = planilha(self.pasta / "b.xlsx", [["RN1", "Nome Fantasia", "CSP"],
                                                [55121, "Sigilosa SA", 21], [55121, "Outra Sigilosa", 21],
                                                [5512, "Terceira Sigilosa", 99]])
        r = carregar(self.db, "operadoras_csp", ruim)
        self.assertFalse(r["ok"])
        self.assertIn("linhas 2 e 3: RN1 repetido", r["erros"])
        self.assertIn("linha 4, coluna RN1: RN1 deve ter 5 dígitos", r["erros"])
        texto_erros = " ".join(r["erros"])
        for sensivel in ("Sigilosa", "55121", "5512 "):
            self.assertNotIn(sensivel, texto_erros)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM inv_operadoras_csp").fetchone()[0], 1)
        self.assertEqual(self.db.execute("SELECT situacao FROM inv_cargas ORDER BY id DESC").fetchone()[0], "erro")

    def test_coluna_faltando(self):
        p = planilha(self.pasta / "x.xlsx", [["OPERADORA", "CN", "LOCALIDADE", "TIPO", "CODIGO", "rn1"],
                                             ["X", 12, "SJC", "LD15", "C8790000", 55104]])
        r = analisar("rotngin", p)
        self.assertIn("não achei as colunas: ROTNGIN, TIPO DE ROTA", r["erros"][0])
        self.assertIn("Colunas encontradas: OPERADORA, CN, LOCALIDADE, TIPO, CODIGO, rn1", r["erros"][0])

    def test_al_anatel_com_colunas_de_apoio(self):
        p = planilha(self.pasta / "al_anatel.xlsx", [
            ["SIGLA_AL", "AREA_LOCAL", "LOCALIDADE", "SIGLA_CNL", "COD_CNL", None, "SIGLA_CNL", "CN", "AREA_LOCAL"],
            ["PPE", "PRESIDENTE PRUDENTE", "ADAMANTINA", "ADT", 11001, "FALSO", "PPE", 18, "PRESIDENTE PRUDENTE"],
            ["CAS", "CAMPINAS", "AGUAI", "AAI", 11004, "FALSO", "CAS", 19, "CAMPINAS"]])
        r = carregar(self.db, "al_anatel", p)
        self.assertTrue(r["ok"], r["erros"])
        row = self.db.execute("SELECT * FROM inv_al_anatel WHERE cod_cnl = '11001'").fetchone()
        self.assertEqual((row["sigla_cnl"], row["cn"], row["area_local"]), ("ADT", "18", "PRESIDENTE PRUDENTE"))

    def test_rn1_datas_e_csp(self):
        p = planilha(self.pasta / "rn1.xlsx", [
            ["DATA MODIFICAÇÃO", "IDP", "NOM                      ", "TTE", "RN1 (YY)    (CSP SAS)",
             "AÇÃO (TIPO DE MODIFICAÇÃO)", "CSP (OPERADORA)", "ECR", "RN1", "RESP", "existe anexo 5?", "IDP"],
            [datetime(2001, 1, 1), "AAA", "OPERADORA_A", "FIXO2", "05", "Acrescentar", "70 (virtual)", None, 55205, None, "não", "AAA"],
            ["13/02/2001", "BBB", "OPERADORA_B", "MOVEL", 14, None, "-", None, 55314, None, "sim", "BBB"],
            ["data ruim", "CCC", "OPERADORA_C", "FIXO", 47, None, 47, None, "-", None, "não", "CCC"]])
        r = carregar(self.db, "rn1", p)
        self.assertTrue(r["ok"], r["erros"])
        linhas = {x["idp"]: x for x in self.db.execute("SELECT * FROM inv_rn1")}
        self.assertEqual(linhas["AAA"]["data_modificacao"], "2001-01-01")
        self.assertEqual(linhas["BBB"]["data_modificacao"], "2001-02-13")
        self.assertEqual(linhas["AAA"]["rn1_yy"], "05")
        self.assertEqual(linhas["CCC"]["rn1"], "-")                   # opcional fora do padrão: guardado como está
        self.assertEqual(len(r["avisos"]), 2)                         # data ruim e RN1 "-"

    def test_sas_com_anotacoes(self):
        p = planilha(self.pasta / "sas.xlsx", [
            ["CN", "OPERADORA", "LABEL (SAS)", "ROTA", "rn1", None, None, "sas resumido"],
            [11, "Op A", "C000", "LC", 55124, None, 1, "para alocar label sas resumido"],
            [11, "Op A", "C001", "LD15", 55124, None, 2, "com cn + rn1 vc já sabe"],
            [None, None, None, None, None, None, 3, "se existir label alocado usa esses mesmos"],
            [12, "Op B", "C000", "LC", 55737, None, None, None]])
        r = carregar(self.db, "sas_resumido", p)
        self.assertTrue(r["ok"], r["erros"])
        self.assertEqual(r["linhas"], 3)


class TestFaixas(Base):
    def test_layout_atual_aponta_a_faixa_invertida_do_cn11(self):
        p = planilha(self.pasta / "livres.xlsx", livres_linhas())
        r = analisar("livres", p)
        self.assertEqual(r["erros"], ["linha 8, coluna CN 11: faixa invertida (fim menor que o início)"])

    def test_layout_corrigido(self):
        p = planilha(self.pasta / "livres.xlsx", livres_linhas(corrigir_cn11=True))
        r = carregar(self.db, "livres", p)
        self.assertTrue(r["ok"], r["erros"])
        faixa = lambda cn, ini: self.db.execute(  # noqa: E731
            "SELECT * FROM inv_faixas_codigos WHERE cn IS ? AND inicio = ? AND fim IS NOT NULL", (cn, ini)).fetchone()
        self.assertEqual(faixa("12", "D02208")["fim"], "D02299")
        self.assertEqual(faixa("14", "D04000")["fim"], "D04999")
        self.assertEqual(faixa("17", "D07000")["prioridade"], 2)            # depois de acabar os C
        self.assertEqual(faixa(None, "C8791575")["tipo"], "rotngin")
        especiais = self.db.execute("SELECT inicio, fim, uso FROM inv_faixas_codigos WHERE uso IS NOT NULL ORDER BY inicio").fetchall()
        self.assertEqual([tuple(e) for e in especiais], [("D05000", "D05499", "csp15"), ("D05500", "D05599", "lc_cng")])
        self.assertEqual(len(faixas.livres(self.db, "sas_resumido", "15")), 30)   # só os C5x
        # Códigos em uso saem dos livres; a ordem segue a planilha
        self.db.execute("INSERT INTO inv_sas_resumido (cn, operadora, label, rota, rn1) VALUES ('12','X','D02204','LC','55104')")
        self.assertEqual(faixas.livres(self.db, "sas_resumido", "12", limite=3), ["D02205", "D02206", "D02207"])
        self.assertEqual(len(faixas.livres(self.db, "sas_resumido", "12")), 95)   # D02205..D02299
        self.assertEqual(faixas.livres(self.db, "sas_resumido", "17", limite=1), ["C76B"])
        self.assertEqual(faixas.livres(self.db, "sas_resumido", "15", uso="csp15", limite=1), ["D05000"])
        self.db.execute("INSERT INTO inv_rotngin (operadora, cn, localidade, tipo_rota, rotngin, rn1) "
                        "VALUES ('X','12','SJC','LC','C8791573','55104')")
        self.assertEqual(faixas.livres(self.db, "rotngin", "12", limite=2), ["C8791574", "C8791575"])


class TestPasta(Base):
    def test_carrega_so_o_que_mudou(self):
        p = self.antigo(planilha(self.pasta / "operadoras_com_csp.xlsx", [["RN1", "Nome Fantasia", "CSP"], [55121, "A", 21]]))
        self.assertEqual(len(carregar_alterados(self.db, self.pasta)), 1)
        self.assertEqual(carregar_alterados(self.db, self.pasta), [])           # mesmo arquivo: não relê
        planilha(p, [["RN1", "Nome Fantasia", "CSP"], [55121, "A", 21], [55112, "B", 12]])
        self.assertEqual(carregar_alterados(self.db, self.pasta), [])           # acabou de mudar: espera
        self.antigo(p)
        r = carregar_alterados(self.db, self.pasta)
        self.assertEqual((len(r), r[0]["linhas"]), (1, 2))

    def test_relatorio_sem_valores(self):
        self.antigo(planilha(self.pasta / "operadoras_com_csp.xlsx",
                             [["RN1", "Nome Fantasia", "CSP"], [55121, "Nome Sigiloso", 21]]))
        rel = {i["base"]: i for i in relatorio(self.db, self.pasta)}
        item = rel["operadoras_csp"]
        self.assertTrue(item["presente"])
        self.assertEqual(item["linhas"], 1)
        self.assertEqual(item["estrutura"]["linha_cabecalho"], 1)
        self.assertNotIn("Sigiloso", repr(item))
        self.assertFalse(rel["rn1"]["presente"])


if __name__ == "__main__":
    unittest.main()
