# Repaginada visual do PTI Automatizado

Aplicação do sistema visual e de movimento da apresentação "Interconexão IP de
Voz" (prompt `prompt-repaginada-pti-automatizado.md`). O estado anterior está
no branch `main`; o trabalho, no branch `repaginada-visual`.

## 1. Inventário (antes)

**Rotas Flask (28, inalteradas):**

| Método | Rota | Endpoint |
|---|---|---|
| GET | `/` | central.index |
| GET, POST | `/login` | auth.login, auth.login_post |
| GET | `/logout` | auth.logout |
| GET, POST | `/admin_login` | auth.admin_login, auth.admin_login_post |
| GET, POST | `/register` | auth.register, auth.register_post |
| GET | `/central_atacado`, `/central_engenharia` | central.* |
| GET | `/atacado_formularios` | atacado.form_list |
| GET, POST | `/atacado_formularios/new` | atacado.form_new, atacado.form_create |
| GET, POST | `/atacado_formularios/<id>` | atacado.form_edit, atacado.form_update |
| POST | `/atacado_formularios/<id>/new_version`, `/delete` | atacado.* |
| GET | `/engenharia_formularios` | engenharia.form_list |
| GET, POST | `/engenharia_formularios/<id>` | engenharia.form_view |
| POST | `/engenharia_formularios/<id>/validar`, `/reprovar`, `/importar_parametros` | engenharia.* |
| GET | `/formularios/<id>/excel_index` (gera o PTI e volta à lista) | engenharia.exportar_excel |
| GET | `/excel_download` (send_file) | engenharia.excel_download |
| GET | `/api/cns`, `/api/operadoras`, `/api/sbc/sugestoes`, `/api/siprouter/query` | api.* |

**Templates:** `base.html` e 8 herdeiros (login, admin_login, register,
central_atacado, central_engenharia, atacado_formularios,
engenharia_formularios, formulario_atacado).

**Estáticos e bibliotecas de UI:** só `static/logo.jpg`. Todo o CSS e o JS
ficavam inline nos templates. Bootstrap 5.3.3 (CSS) e Bootstrap Icons 1.11.3
por CDN; fonte Inter pelo Google Fonts.

**Componentes repetidos:** barra superior com "Voltar"; botões `.btn-p`,
`.btn-o`, `.btn-g`; campos `.v-input`; cartões `.card` com sombra; selos de
status coloridos `.badge-s`; tabela `.v-table`; mensagens `.flash-msg`
(sumiam em 3 s); estados vazios `.empty`; pílulas; diálogos nativos
`confirm()`/`alert()`; download do Excel em duas etapas (gerar → baixar).

**Problemas visuais e de usabilidade encontrados:**

- degradês, brilho animado ("shimmer"), sombras e fundos com transparência;
- status distinguidos só por cor (verde, amarelo, vermelho, azul);
- muito texto abaixo de 14 px (rótulos de .68–.78rem);
- página 404 crua do Flask;
- tabela das listas cortada no celular (ações invisíveis);
- confirmações em diálogos nativos, sem estilo e sem contexto;
- sem link para o conteúdo, sem controle de pausa, foco inconsistente;
- fontes, CSS e ícones carregados de CDNs (a aplicação roda em rede interna).

Capturas: `docs/repaginada/capturas/antes/` e `depois/` (fora do git).

## 2. Mapa de padrões

| Tela | Rota | Padrão | Entrada | Ciclo | Ambiente | Estado | Leitura | Atividade |
|---|---|---|---|---|---|---|---|---|
| Login | `/login` | Login | completa, título palavra por palavra | — | rede | sim | tema da barra, parallax | botão Entrar |
| Painel do Atacado | `/central_atacado` | Painel inicial | completa | cartões de módulo | rede, indicadores | sim | progresso, parallax, tema | — |
| Painel da Engenharia | `/central_engenharia` | Painel inicial | completa | cartões de módulo | rede, indicadores | sim | progresso, parallax, tema | — |
| Meus Pré-PTIs | `/atacado_formularios` | Lista | curta | — | rota lenta no estado vazio grande | sim | progresso em páginas longas | Nova versão; Excluir (modal) |
| Validação de Pré-PTIs | `/engenharia_formularios` | Lista | curta (estática ao voltar da geração) | — | rota lenta no estado vazio grande | sim | progresso | Aprovar, Reprovar (modal), Gerar PTI |
| Pré-PTI (novo e edição) | `/atacado_formularios/new`, `/<id>` | Formulário | curta (cabeçalho e 3 primeiros grupos) | — | — | sim | progresso | Finalizar, Salvar rascunho |
| Validar Pré-PTI | `/engenharia_formularios/<id>` | Formulário · Detalhe · Consulta (SBC) | curta | — | — | sim | progresso | Salvar validação, Importar, consulta de SBC (barra no campo e na barra superior) |
| Código de administrador | `/admin_login` | Formulário | curta | — | — | sim | — | Entrar |
| Novo usuário | `/register` | Formulário | curta | — | — | sim | — | Criar usuário |
| Erro 404 e 500 | qualquer | Página de erro | completa | — | rede interrompida | sim | tema, parallax | — |

Com mensagem flash, toda tela nasce pronta (`data-motion="static"`); só a
mensagem tem entrada própria.

## 3. Log de decisões

| Decisão | Motivo | Alternativa descartada |
|---|---|---|
| Repositório git criado, com o estado anterior no `main` e o trabalho no branch `repaginada-visual` | O projeto não tinha versionamento e o prompt pede commits pequenos; o `main` serve de "antes" para comparação e reversão | Trabalhar sem histórico |
| Banco real (`instance/`), planilhas de medição e configuração local fora do git | Dados reais | Versionar tudo |
| Capturas fora do git | 264 imagens pesariam o repositório no OneDrive | Versionar as imagens |
| Pacote `ui/` na raiz (`ui/icons.py`, `ui/templating.py`) | O projeto não tem pacote `app/`; os módulos ficam na raiz | Reestruturar o projeto |
| WOFF2 gerados do Inter 4.1 (TTF estáticos) com `pyftsubset`, instalado em pasta temporária | Subconjunto latino com os recursos pedidos, sem tocar no Python global | WOFF2 completos (~110 KB cada) |
| Ícones copiados do tarball de `lucide-static@1.52.0` no registro npm | Node/npm não estão instalados | CDN |
| `legacy.css` temporário durante a migração, removido no fim junto com o Bootstrap | A aplicação funcionou entre um commit e outro | Migrar tudo num commit só |
| Rodapé sem número de versão | O backend não tem versão da aplicação (só versões de cada PTI) | Inventar um número |
| Mensagens do servidor ficam até serem fechadas (antes sumiam em 3 s) | Comportamento definido no prompt; notificações do cliente fecham em 6 s | Manter os 3 s |
| `confirm()`/`alert()` trocados por modal `<dialog>` e notificações | Componentes 9 e 14; o modal entrega a resposta no clique porque o evento `close` pode ser adiado com a aba oculta | Diálogos nativos |
| Status do PTI e saúde do SBC por ícone, texto e peso | Uma cor de destaque; sem verde, amarelo ou vermelho | Manter as cores |
| Chevron dos selects por imagem de fundo com o desenho do Lucide | Os selects das tabelas são criados em JS, sem contêiner para o ícone sobreposto; o resultado é idêntico | Envolver cada select num contêiner |
| Tabelas de entrada com layout automático, respiro de 8 px e campos de 48 px | Cabem em 1366 px sem rolagem lateral; até 720 px viram blocos com rótulos | Rolagem lateral no notebook |
| Campos com limite de dígitos compactos (RN1 e ASN até 168 px; EOT e Mask 96 px) | Pedido permanente do usuário | Ocupar 4 ou 6 colunas inteiras |
| Números das seções mantidos no rótulo de grupo ("3 · Escopo") | O usuário se refere às seções pelo número | Tirar os números |
| Busca do painel numa linha própria, abaixo dos módulos | O cartão de módulo é um link e não pode conter campo | Cartão com formulário dentro |
| Indicadores com 3 métricas reais diferentes das da faixa de prova | Não repetir os números da abertura | Omitir a faixa de indicadores |
| Indicadores sem representação gráfica | Nenhuma das três (grade, convergência, anel) é mais verdadeira que o número para estes dados | Enfeitar |
| Login: rede sob o texto de apoio, na coluna esquerda | Ao fundo, os rótulos ficavam cortados pelo cartão; acima, o texto do SVG ficava abaixo de 14 px e a faixa não cabia em 1366 × 768 | Posição literal (acima ou ao fundo) |
| Login: lista de recursos removida e apoio sem citar o SipRouter | O padrão de login tem só eyebrow, nome e apoio; o SipRouter foi desativado | Manter a lista |
| "Voltar" substituído pela navegação por perfil | Os links da barra cobrem o caminho de volta | Manter os dois |
| Logo + "AUTOMATIZADO" mantidos como nome da aplicação | Manter o nome que a aplicação exibe; o logo é ativo de marca pedido pelo usuário | Só texto |
| Linha nova: id guardado na sessão pelas rotas que criam ou alteram, lido uma vez pela lista | O redirecionamento não traz o id | Parâmetro na URL |
| Formulário: resumo de erros no topo com links e campos com `aria-invalid`, sem mensagem embaixo de cada célula | Mensagem por célula quebraria as tabelas | Mensagem por campo em todos |
| Botões da barra de ações como `submit` do formulário (atributo `form`) | O envio carrega o botão clicado e liga o estado ocupado | `requestSubmit()` sem botão |
| Geração do PTI (GET que volta para a lista) com `data-busy` nativo; "Baixar Excel" (`send_file`) como link simples | Regra do prompt para cada tipo de rota | Interceptar com `fetch` |
| Geocodificação (OpenStreetMap) mantida | É dado de negócio, disparado só ao sair do campo de endereço | Remover a integração |
| Dicas de sigla só para CSP e CNG | Únicas com definição no glossário da apresentação; ASN, CAPS e TMR não têm fonte no código | Inventar definições |
| Páginas de erro 404 e 500 com `errorhandler` | Padrão de tela do prompt; status mantidos | Página padrão do Flask |
| Pausa e tooltip usados como especificado; o clique em pausar antes de o motor ligar não tem efeito | Código do apêndice C copiado como está | Ligar o botão antes das fontes |
| `html-validate` substituído por verificador em Python (`tools/qa/html_check.py`) | Node não instalado | Pular a verificação |
| `docker build`/`docker run` não executados | Docker e Dockerfile ausentes nesta cópia | — |

## 4. Controle de qualidade

Ver `tools/qa/README.md` para rodar. Resultados na resposta final da tarefa e
em `tools/qa/saida/verificacoes.json` (gerado, fora do git).
